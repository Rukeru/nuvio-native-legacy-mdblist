using System;
using System.IO;
using System.Text;

namespace NuvioTpk
{
    // Inspect exported ELF data before dlopen can execute any native constructors.
    // This is a compatibility guard; release SHA-256 is still checked by NvCarga.
    static class MdbListChannel
    {
        const string Symbol = "nv_mdblist_update_contract_v1";
        const string Contract = "nuvio-mdblist-tracking/1\0";
        static readonly byte[] NameBytes = Encoding.ASCII.GetBytes(Symbol + "\0");
        static readonly byte[] ContractBytes = Encoding.ASCII.GetBytes(Contract);

        public static string ShellId(string resourceDir)
        {
            try {
                string id = File.ReadAllText(Path.Combine(resourceDir, "mdblist-shell.sha256")).Trim();
                if (id.Length != 64) return null;
                foreach (char c in id) if (!(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f')) return null;
                return id;
            } catch { return null; }
        }
        public static bool CompatibleFile(string file, string shellContract = null)
        {
            try { using (var stream = File.OpenRead(file)) return Compatible(stream, shellContract); }
            catch { return false; }
        }
        public static bool Compatible(byte[] data, string shellContract = null)
        {
            if (data == null) return false;
            using (var stream = new MemoryStream(data, false)) return Compatible(stream, shellContract);
        }
        static bool Range(Stream s, long offset, long count) => offset >= 0 && count >= 0 && offset <= s.Length && count <= s.Length - offset;
        static byte[] Bytes(BinaryReader r, long offset, int count)
        {
            if (!Range(r.BaseStream, offset, count)) throw new InvalidDataException();
            r.BaseStream.Position = offset;
            byte[] data = r.ReadBytes(count);
            if (data.Length != count) throw new EndOfStreamException();
            return data;
        }
        static uint U32(byte[] b, int i) => (uint)b[i] | (uint)b[i + 1] << 8 | (uint)b[i + 2] << 16 | (uint)b[i + 3] << 24;
        static int U16(byte[] b, int i) => b[i] | b[i + 1] << 8;
        static bool Equal(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }
        static bool Compatible(Stream stream, string shellContract)
        {
            if (!HasExport(stream, NameBytes, ContractBytes)) return false;
            return shellContract == null || HasExport(stream,
                Encoding.ASCII.GetBytes("nv_mdblist_shell_contract_v1\0"),
                Encoding.ASCII.GetBytes(shellContract + "\0"));
        }
        static bool HasExport(Stream stream, byte[] nameBytes, byte[] contractBytes)
        {
            try
            {
                using (var r = new BinaryReader(stream, Encoding.UTF8, true))
                {
                    byte[] h = Bytes(r, 0, 52);
                    if (h[0] != 0x7f || h[1] != 'E' || h[2] != 'L' || h[3] != 'F' || h[4] != 1 || h[5] != 1 || h[6] != 1) return false;
                    if (U16(h, 16) != 3 || U16(h, 18) != 40 || (U32(h, 36) & 0x400) != 0) return false;
                    long phoff = U32(h, 28), shoff = U32(h, 32);
                    int phsize = U16(h, 42), phcount = U16(h, 44), shsize = U16(h, 46), shcount = U16(h, 48);
                    if (phsize < 32 || shsize < 40 || phcount == 0 || phcount > 4096 || shcount == 0 || shcount > 4096) return false;
                    if (!Range(stream, phoff, (long)phsize * phcount) || !Range(stream, shoff, (long)shsize * shcount)) return false;
                    for (int section = 0; section < shcount; section++)
                    {
                        byte[] sh = Bytes(r, shoff + (long)section * shsize, 40);
                        if (U32(sh, 4) != 11) continue; // SHT_DYNSYM
                        long offset = U32(sh, 16), size = U32(sh, 20), entry = U32(sh, 36);
                        uint link = U32(sh, 24);
                        if (entry < 16 || size % entry != 0 || size / entry > 1000000 || link >= shcount || !Range(stream, offset, size)) return false;
                        byte[] strings = Bytes(r, shoff + (long)link * shsize, 40);
                        long stringOffset = U32(strings, 16), stringSize = U32(strings, 20);
                        if (U32(strings, 4) != 3 || !Range(stream, stringOffset, stringSize)) return false;
                        for (long symbol = 0; symbol < size; symbol += entry)
                        {
                            byte[] sym = Bytes(r, offset + symbol, 16);
                            long name = U32(sym, 0), address = U32(sym, 4);
                            if (sym[12] >> 4 != 1 || (sym[12] & 15) != 1 || (sym[13] & 3) != 0 || U16(sym, 14) == 0) continue;
                            if (name > stringSize - nameBytes.Length || !Equal(Bytes(r, stringOffset + name, nameBytes.Length), nameBytes)) continue;
                            if (U32(sym, 8) != contractBytes.Length) return false;
                            for (int p = 0; p < phcount; p++)
                            {
                                byte[] ph = Bytes(r, phoff + (long)p * phsize, 32);
                                if (U32(ph, 0) != 1) continue;
                                long file = U32(ph, 4), start = U32(ph, 8), length = U32(ph, 16);
                                if (address >= start && address - start <= length - contractBytes.Length)
                                    return Equal(Bytes(r, file + address - start, contractBytes.Length), contractBytes);
                            }
                            return false;
                        }
                    }
                }
            }
            catch { return false; }
            return false;
        }
    }
}
