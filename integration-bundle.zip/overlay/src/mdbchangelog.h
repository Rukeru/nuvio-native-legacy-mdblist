#ifndef NV_MDB_CHANGELOG_H
#define NV_MDB_CHANGELOG_H
#include <SDL2/SDL.h>
/* Main-thread only; one private marker per installed version, no network. */
void mdbchangelog_primeira_vez(void);
void mdbchangelog_abrir(void);
int mdbchangelog_aberto(void);
int mdbchangelog_paginas(void);
void mdbchangelog_evento(const SDL_Event *e);
void mdbchangelog_desenhar(void);
#endif
