#include "mdblistscrobble.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

int mdblist_corpo(char *dst, size_t n, const char *id, double pct) {
  const char *p, *number;
  char base[64], ids[100];
  int season = 0, episode = 0, used = 0, count, tmdb = 0, tv = 0, tvdb = 0;
  size_t len;
  if (dst && n) dst[0] = 0;
  if (!dst || !n || !id || !isfinite(pct)) return 0;
  if (!strncmp(id, "tt", 2)) number = id + 2;
  else if (!strncmp(id, "tmdb:m", 6) || !strncmp(id, "tmdb:t", 6)) {
    tmdb = 1; tv = id[5] == 't'; number = id + 6;
    if (*number == '0') return 0;
  } else if (!strncmp(id,"tvdb:t",6)) { tmdb=tv=tvdb=1;number=id+6;if(*number=='0')return 0; } else return 0;
  p = number;
  if (*p < '0' || *p > '9') return 0;
  while (*p >= '0' && *p <= '9') p++;
  len = (size_t)(p - (tmdb ? number : id));
  if (len >= sizeof base) return 0;
  if (tmdb && len > 10) return 0;
  memcpy(base, tmdb ? number : id, len); base[len] = 0;
  if (tmdb && ((tv && !*p) || (!tv && *p))) return 0;
  if (*p) {
    /* Limit field width before sscanf, avoiding integer overflow and truncation. */
    const char *q = p + 1;
    int digits = 0;
    if (*p != ':') return 0;
    while (*q >= '0' && *q <= '9') { q++; digits++; }
    if (!digits || digits > 4 || *q++ != ':') return 0;
    digits = 0;
    while (*q >= '0' && *q <= '9') { q++; digits++; }
    if (!digits || digits > 4 || *q) return 0;
    if (sscanf(p, ":%4d:%4d%n", &season, &episode, &used) != 2 ||
        p[used] || season < 0 || episode <= 0) return 0;
  }
  if (pct < 0) pct = 0;
  if (pct > 100) pct = 100;
  /* Formatting 79.999 as 80.00 must not cross the server's watched boundary. */
  if (pct < 80 && pct > 79.99) pct = 79.99;
  if (tmdb) snprintf(ids, sizeof ids, "\"%s\":%s", tvdb?"tvdb":"tmdb", base);
  else snprintf(ids, sizeof ids, "\"imdb\":\"%s\"", base);
  if (*p)
    count = snprintf(dst, n, "{\"show\":{\"ids\":{%s},"
                     "\"season\":%d,\"episode\":%d},\"progress\":%.2f}", ids, season, episode, pct);
  else
    count = snprintf(dst, n, "{\"movie\":{\"ids\":{%s}},\"progress\":%.2f}", ids, pct);
  if (count < 0 || (size_t)count >= n) { dst[0] = 0; return 0; }
  /* JSON decimal separator must remain '.', even under a non-C numeric locale. */
  p = strrchr(dst, ':');
  if (p) { char *comma = strchr((char *)p, ','); if (comma) *comma = '.'; }
  return 1;
}

int mdblist_decidir(MdbScrobbleEstado *s, int evento, const char *id) {
  int same;
  if (!s || !id || !*id || strlen(id) >= sizeof s->id) return SCR_NADA;
  same = !strcmp(s->id, id);
  if (evento == SCR_EV_TOCANDO) {
    if (same && s->fase == SCR_START) return SCR_NADA;
    snprintf(s->id, sizeof s->id, "%s", id); s->fase = SCR_START;
    return SCR_START;
  }
  if (evento == SCR_EV_PAUSOU) {
    if (!same || s->fase != SCR_START) return SCR_NADA;
    s->fase = SCR_PAUSE;
    return SCR_PAUSE;
  }
  if (evento == SCR_EV_SAIU) {
    if (same && s->fase == SCR_STOP) return SCR_NADA;
    snprintf(s->id, sizeof s->id, "%s", id); s->fase = SCR_STOP;
    /* MDBList stop saves progress below 80%, marks watched at >=80%. */
    return SCR_STOP;
  }
  return SCR_NADA;
}
