#ifndef NV_MDB_LIBRARY_H
#define NV_MDB_LIBRARY_H
#include "catalogo.h"
/* Reads run on discovery's worker. NULL returns the refreshed count; a
   subsequent bounded copy uses that snapshot. No network on the UI thread. */
int mdb_library_watchlist(CatItem *out,int max);
unsigned mdb_library_save(const char *id,const char *type,int add);
unsigned mdb_library_clear(const char *id);
int mdb_library_result(unsigned serial); /* 1 pending, 2 confirmed, 3 failed */
int mdb_library_connected(void);
void mdb_library_tick(void);
void mdb_library_history_tick(void); /* main-thread snapshot handoff only */
const char *mdb_library_status(void);
/* Consume on the main thread; success/failure text never contains secrets. */
const char *mdb_library_notice(int *refresh);
int mdb_library_continue(CatItem *out,int max);
int mdb_library_next(const char *id);
#endif
