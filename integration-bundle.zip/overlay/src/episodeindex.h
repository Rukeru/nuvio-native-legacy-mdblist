#ifndef NV_EPISODEINDEX_H
#define NV_EPISODEINDEX_H
#define EP_INDEX_MAX 1200
typedef struct {
  int valid, item, total, season, count;
  unsigned revision;
  int indices[EP_INDEX_MAX];
} EpisodeIndex;
void episode_index_prepare(EpisodeIndex *,int,unsigned,int,int,int (*)(void *,int),void *);
#endif
