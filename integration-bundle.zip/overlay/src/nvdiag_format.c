#include "nvdiag.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

/* Kept in sync with private-diagnostics/ingestion.mjs; cross-language fixture
 * validates every event against the independent server schema. */
static const struct { const char *code, *a, *b; int min_a, max_a, max_b; } schema[] = {
 {"manual_report","count",NULL,1,100000,0},
 {"previous_session_ended","count",NULL,1,100000,0},
 {"sync_failed","http_status","profile_slot",0,599,10},
 {"sync_cached","profile_slot","age_minutes",0,10,43200},
 {"sync_stale","profile_slot","age_minutes",0,10,43200},
 {"manifest_failed","http_status","attempt",0,599,8},
 {"mdblist_failed","http_status","attempt",0,599,8},
 {"mdblist_auth","http_status",NULL,0,599,0},
 {"trakt_failed","http_status","attempt",0,599,8},
 {"tracking_retry","attempt","count",0,8,100000},
 {"tracking_duplicate","count",NULL,1,100000,0},
 {"account_refresh_failed","http_status",NULL,0,599,0},
 {"playback_init","error_code",NULL,0,999,0},
 {"playback_decoder","error_code",NULL,0,999,0},
 {"playback_interrupted","error_code",NULL,0,999,0},
 {"performance_slow","fps","frame_ms",0,240,10000},
 {"performance_memory","memory_mb",NULL,0,32768,0},
 {"sync_slow","elapsed_ms",NULL,0,300000,0}
};
_Static_assert(sizeof schema / sizeof *schema == NVD_EVENT_COUNT, "diagnostic schema drift");
int nvdiag_hex_valid(const char *s, size_t n) {
 size_t i; if (!s || strlen(s)!=n) return 0;
 for(i=0;i<n;i++) if(!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f')))return 0;
 return 1;
}
int nvdiag_uuid_valid(const char *s) {
 size_t i; char hex[33]; int k=0;
 if(!s||strlen(s)!=36||s[14]!='4'||!strchr("89ab",s[19]))return 0;
 for(i=0;i<36;i++) {
  if(i==8||i==13||i==18||i==23) { if(s[i]!='-')return 0; }
  else hex[k++]=s[i];
 }
 hex[k]=0; return nvdiag_hex_valid(hex,32);
}
static int version_valid(const char *s) {
 int parts=0,digits=0;
 for(;*s;s++) {
  if(*s=='.') { if(!digits||digits>(parts?6:3)||++parts>3)return 0; digits=0; }
  else if(*s<'0'||*s>'9'||++digits>6)return 0;
 }
 return parts>=2&&parts<=3&&digits>0;
}
int nvdiag_event_valid(NvDiagEvent e) {
 if(e.code<0||e.code>=NVD_EVENT_COUNT)return 0;
 if(e.a<schema[e.code].min_a||e.a>schema[e.code].max_a||e.b<0||e.b>schema[e.code].max_b)return 0;
 if(!strcmp(schema[e.code].a,"http_status")&&e.a>0&&e.a<100)return 0;
 if(e.code==NVD_RETRY && !e.b)return 0;
 return 1;
}
static int append(char **p,size_t *left,const char *fmt,...) {
 int n;va_list ap;va_start(ap,fmt);n=vsnprintf(*p,*left,fmt,ap);va_end(ap);
 if(n<0||(size_t)n>=*left)return 0;
 *p+=n;*left-=(size_t)n;return 1;
}
int nvdiag_report_json(const NvDiagReport *r,const char *platform,char *out,size_t cap) {
 int i; char *p=out;size_t left=cap;
 if(!out||!cap)return 0;out[0]=0;
 if(!r||!platform||(strcmp(platform,"tizen")&&strcmp(platform,"webos"))||
    !nvdiag_uuid_valid(r->id)||!version_valid(r->version)||!nvdiag_hex_valid(r->build,40)||
    r->n<1||r->n>NVD_EVENTS)return 0;
 for(i=0;i<r->n;i++)if(!nvdiag_event_valid(r->events[i]))return 0;
 if(!append(&p,&left,"{\"version\":1,\"report_id\":\"%s\",\"platform\":\"%s\",\"app_version\":\"%s\",\"build_id\":\"%s\",\"events\":[",r->id,platform,r->version,r->build))goto fail;
 for(i=0;i<r->n;i++) {
  NvDiagEvent e=r->events[i];
  if(!append(&p,&left,"%s{\"code\":\"%s\",\"context\":{\"%s\":%d",i?",":"",schema[e.code].code,schema[e.code].a,e.a))goto fail;
  if(schema[e.code].b&&!append(&p,&left,",\"%s\":%d",schema[e.code].b,e.b))goto fail;
  if(!append(&p,&left,"}}"))goto fail;
 }
 if(!append(&p,&left,"]}"))goto fail;
 return 1;
fail: out[0]=0;return 0;
}
unsigned nvdiag_backoff(int attempts,int http) {
 unsigned n=attempts<1?1:attempts>8?8:(unsigned)attempts;
 if(http==429)return 3600; /* conservative: covers both service Retry-After values */
 return 30u << (n-1); /* 30 seconds to 64 minutes, bounded attempts */
}
