#ifndef NV_MDBLISTSCROBBLE_H
#define NV_MDBLISTSCROBBLE_H
#include <stddef.h>
#include "traktscrobble.h" /* shared player events only; MDBList has its own rules */

typedef struct { char id[64]; int fase; } MdbScrobbleEstado;
/* IMDb IDs, typed tmdb:m123 / tmdb:t123:season:episode, or known TVDB show
   IDs tvdb:t123:season:episode. The player does not invent missing IDs.
   Episodes use the SHOW ID. Season zero is supported; bare TMDB shows rejected. */
int mdblist_corpo(char *dst, size_t n, const char *id, double pct);
int mdblist_decidir(MdbScrobbleEstado *s, int evento, const char *id);
#endif
