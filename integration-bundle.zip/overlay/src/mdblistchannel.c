#include "mdblistchannel.h"
#include <string.h>
#ifdef NV_TPK
/* The managed host checks this exported data before loading a staged ELF. */
__attribute__((visibility("default"), used))
const char nv_mdblist_update_contract_v1[] = NV_MDBLIST_CONTRACT;
__attribute__((visibility("default"), used))
const char nv_mdblist_shell_contract_v1[] = NV_MDBLIST_SHELL_ID;
#endif
int mdblist_channel_asset(const char *url) {
  const char *tag, *name;
  size_t n, suffix = strlen(NV_MDBLIST_SO_SUFFIX);
  if (!url || strncmp(url, NV_MDBLIST_DOWNLOAD_PREFIX, strlen(NV_MDBLIST_DOWNLOAD_PREFIX))) return 0;
  tag = url + strlen(NV_MDBLIST_DOWNLOAD_PREFIX);
  name = strchr(tag, '/');
  if (!name || name == tag || !name[1] || strchr(name + 1, '/')) return 0;
  name++;
  n = strlen(name);
  return !strncmp(name, "libnuvio-", 9) && n > 9 + suffix &&
         !strcmp(name + n - suffix, NV_MDBLIST_SO_SUFFIX);
}
