#include "mdbwatched.h"
#include "mdbformat.h"
#include "js.h"
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static const char *arrayFirst(const char *a) {
 a++;while(isspace((unsigned char)*a))a++;return *a==']'?NULL:a;
}
static const char *arrayNext(const char *f) {
 if(!f)return NULL;while(isspace((unsigned char)*f))f++;
 if(*f==']')return NULL;
 if(*f==','){f++;while(isspace((unsigned char)*f))f++;}
 return f;
}

static int imdb(const char *obj, char *out, unsigned size) {
 const char *end=obj?js_fim(obj):NULL;
 const char *ids=end?mdb_object(obj,end,"ids"):NULL;
 if(!ids||!mdb_text(ids,js_fim(ids),"imdb",out,size)||strncmp(out,"tt",2))return 0;
 const char *p=out+2;if(!*p)return 0;
 for(;*p;p++)if(!isdigit((unsigned char)*p))return 0;
 return 1;
}
static long long watchedAt(const char *p,const char *f) {
 char date[64];
 return (mdb_text(p,f,"last_watched_at",date,sizeof date)||mdb_text(p,f,"watched_at",date,sizeof date))?js_ms_iso(date):0;
}
int mdb_watched_page(const char *json,ContaVisto *out,int max,
                     char *cursor,unsigned size,int *more) {
 while(json&&isspace((unsigned char)*json))json++;
 const char *end=json?js_fim(json):NULL;
 if(!end||*json!='{'||end==json||end[-1]!='}'||!size)return -1;
 cursor[0]=0;*more=0;int n=0,recognized=0;
 const char *keys[]={"movies","episodes","shows","seasons"};
 for(int kind=0;kind<4;kind++) {
  const char *a=mdb_prop(json,end,keys[kind]);if(!a)continue;
  recognized=1;const char *ae=js_fim(a);
  if(*a!='['||!ae||ae>end||ae[-1]!=']')return -1;
  for(const char *p=arrayFirst(a);p;p=arrayNext(js_fim(p))) {
   const char *f=js_fim(p);if(*p!='{'||!f||f>ae)return -1;
   if(kind==2) {
    /* Desktop 0.1.29 also accepts Trakt-style nested watched episodes.
       Each episode needs its own positive timestamp; no season expansion. */
    ContaVisto v={0};strcpy(v.tipo,"series");
    const char *show=mdb_object(p,f,"show"),*seasons=mdb_prop(p,f,"seasons");
    if(!seasons||!imdb(show,v.id,sizeof v.id))continue;
    const char *sf=js_fim(seasons);if(*seasons!='['||!sf||sf>f||sf[-1]!=']')return -1;
    for(const char *s=arrayFirst(seasons);s;s=arrayNext(js_fim(s))) {
     const char *se=js_fim(s);if(*s!='{'||!se||se>sf)return -1;
     double t=mdb_number(s,se,"number",-1);if(t<0)t=mdb_number(s,se,"season",-1);
     const char *eps=mdb_prop(s,se,"episodes");if(!eps)continue;
     const char *ef=js_fim(eps);if(t<0||t>999||floor(t)!=t||*eps!='['||!ef||ef>se||ef[-1]!=']')return -1;
     for(const char *ep=arrayFirst(eps);ep;ep=arrayNext(js_fim(ep))) {
      const char *ee=js_fim(ep);if(*ep!='{'||!ee||ee>ef)return -1;
      v.vistoMs=watchedAt(ep,ee);if(v.vistoMs<=0)continue;
      double e=mdb_number(ep,ee,"number",-1);if(e<0)e=mdb_number(ep,ee,"episode",-1);
      if(e<1||e>9999||floor(e)!=e||n>=max)return -1;
      v.temporada=(int)t;v.episodio=(int)e;out[n++]=v;
     }
    }
    continue;
   }
   if(kind==3)continue; /* aggregate activity is not completion */
   long long ms=watchedAt(p,f);
   if(ms<=0)continue; /* removed/null entries do not count as watched */
   ContaVisto v={0};v.vistoMs=ms;
   const char *media=mdb_object(p,f,kind?"episode":"movie");if(!media)return -1;
   if(kind) {
    const char *me=js_fim(media),*show=mdb_object(media,me,"show");
    if(!show)show=mdb_object(p,f,"show"); /* modern sibling envelope */
    if(!imdb(show,v.id,sizeof v.id))continue;
    double t=mdb_number(media,me,"season",-1),e=mdb_number(media,me,"number",-1);
    if(e<0)e=mdb_number(media,me,"episode",-1);
    if(t<0||t>999||e<1||e>9999||floor(t)!=t||floor(e)!=e)return -1;
    v.temporada=(int)t;v.episodio=(int)e;strcpy(v.tipo,"series");
   }else {if(!imdb(media,v.id,sizeof v.id))continue;strcpy(v.tipo,"movie");}
   if(n>=max)return -1;out[n++]=v;
  }
 }
 if(!recognized)return -1;
 const char *pg=mdb_object(json,end,"pagination"),*pe=pg?js_fim(pg):NULL;
 const char *next=mdb_prop(json,end,"next_cursor");
 if(!next&&pg)next=mdb_prop(pg,pe,"next_cursor");
 if(next&&strncmp(next,"null",4)) {
  /* Reject truncated cursors rather than repeat/drop a page. */
  const char *ne=next+1;
  for(;ne<end&&*ne!='"';ne++)if(*ne=='\\'&&ne+1<end)ne++;
  if(*next!='"'||ne>=end||(unsigned)(ne-next)>=size||!js_cadeia(next,cursor,size))return -1;
 }
 if(pg) {
  const char *hm=mdb_prop(pg,pe,"has_more");
  if(hm){if(!strncmp(hm,"true",4))*more=1;else if(strncmp(hm,"false",5))return -1;}
  else if(!next) {
   double total=mdb_number(pg,pe,"total",-1),offset=mdb_number(pg,pe,"offset",0),limit=mdb_number(pg,pe,"limit",1000);
   if(total>=0&&offset+limit<total)*more=1;
  }
 }
 if(cursor[0])*more=1;
 return n;
}
