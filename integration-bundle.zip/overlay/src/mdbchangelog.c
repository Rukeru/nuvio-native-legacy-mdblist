#include "mdbchangelog.h"
#include "mdbchangelog_notes.h"
#include "ajustes.h"
#include "dados.h"
#include "gfx.h"
#include "idioma.h"
#include "layout.h"
#include "plrui.h"
#include "text.h"
#define NV_ESCALA_TELA_ATIVA
#include "escala.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef NV_VERSAO
#define NV_VERSAO "dev"
#endif
#define SEEN "mdblist-changelog-seen.txt"
#define COUNT ((int)(sizeof MDB_CHANGES / sizeof *MDB_CHANGES))
#define PAGES ((COUNT + 2) / 3)
static int checked, opened, page;

int mdbchangelog_aberto(void) { return opened; }
int mdbchangelog_paginas(void) { return PAGES; }
void mdbchangelog_abrir(void) { opened = 1; page = 0; }
void mdbchangelog_primeira_vez(void) {
  char *seen;
  if (checked) return;
  checked = 1;
  if (!strcmp(NV_VERSAO, "dev")) return;
  seen = dados_ler(SEEN);
  if (!seen || strcmp(seen, NV_VERSAO)) mdbchangelog_abrir();
  free(seen);
}
static void close_notes(void) {
  opened = 0;
  /* A failed save retries next launch; it never interrupts the current session. */
  dados_gravar(SEEN, NV_VERSAO);
}
void mdbchangelog_evento(const SDL_Event *e) {
  SDL_Keycode k;
  if (!opened || e->type != SDL_KEYDOWN || e->key.repeat) return;
  k = e->key.keysym.sym;
  if (k == SDLK_RIGHT || k == SDLK_DOWN) { if (page + 1 < PAGES) page++; }
  else if (k == SDLK_LEFT || k == SDLK_UP) { if (page > 0) page--; }
  else if (k == SDLK_RETURN || k == SDLK_KP_ENTER || k == SDLK_SPACE ||
           k == SDLK_AC_BACK || k == SDLK_ESCAPE || k == SDLK_BACKSPACE ||
           k == SDLK_DELETE || e->key.keysym.scancode == NV_SCANCODE_BACK) close_notes();
}
static void line(TxtEstilo style, const char *s, float x, float y, float width, int muted) {
  TxtLinha l = txt_linha_corta(style, s, muted ? 180 : 245, muted ? 189 : 246,
                              muted ? 204 : 250, 255, width);
  txt_desenhar(l, x, y);
}
void mdbchangelog_desenhar(void) {
  float r, g, b;
  char version[96], pages[96];
  if (!opened) return;
  ESCALA_SE_COUBER_INI(1320, 900);
  float x = (NV_TELA_W - 1320) * .5f, y = (NV_TELA_H - 900) * .5f;
  ajustes_acento(&r, &g, &b);
  gfx_cor((GfxRect){0, 0, NV_TELA_W, NV_TELA_H}, 0, .025f, .035f, .060f, 1);
  gfx_cor((GfxRect){x, y, 1320, 900}, 32.0f / 900, .065f, .080f, .115f, 1);
  gfx_anel((GfxRect){x, y, 1320, 900}, 32.0f / 900, 1, 1, 1, 1, .12f);
  gfx_cor((GfxRect){x + 56, y + 54, 7, 126}, .04f, r, g, b, 1);
  line(TXT_TITULO1, i18n("What's new"), x + 90, y + 56, 1120, 0);
  snprintf(version, sizeof version, i18n("Version %s is installed"), NV_VERSAO);
  line(TXT_CALLOUT, version, x + 92, y + 152, 1100, 1);
  for (int row = 0; row < 3; row++) {
    int n = page * 3 + row;
    if (n >= COUNT) break;
    float cy = y + 226 + row * 172;
    gfx_cor((GfxRect){x + 56, cy, 1208, 152}, 20.0f / 152, .105f, .128f, .174f, 1);
    gfx_cor((GfxRect){x + 80, cy + 26, 10, 10}, .5f, r, g, b, 1);
    line(TXT_HEADLINE, i18n(MDB_CHANGES[n].title), x + 110, cy + 22, 1110, 0);
    txt_bloco_corta(TXT_BODY, i18n(MDB_CHANGES[n].body), 192, 201, 218,
                    x + 110, cy + 64, 1100, 32, 1, 2);
  }
  if (PAGES > 1) {
    snprintf(pages, sizeof pages, i18n("%d / %d   ·   Left / right for more"), page + 1, PAGES);
    line(TXT_CAPTION, pages, x + 56, y + 772, 800, 1);
  } else line(TXT_CAPTION, i18n("Reopen from Settings > About & help"), x + 56, y + 772, 800, 1);
  /* Accents can be white or very pale: keep the selected button readable. */
  gfx_cor((GfxRect){x + 1004, y + 762, 260, 72}, .25f, .16f, .20f, .30f, 1);
  gfx_anel((GfxRect){x + 996, y + 754, 276, 88}, .25f, 3, 1, 1, 1, .9f);
  line(TXT_HEADLINE, i18n("OK · Got it"), x + 1032, y + 783, 210, 0);
  ESCALA_SE_COUBER_FIM();
}
