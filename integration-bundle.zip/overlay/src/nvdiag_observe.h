/* Optional observer for independently linkable playback/account modules.
 * Production links the real provider through the strong Settings/init API.
 * Standalone upstream component fixtures need no diagnostic network/storage.
 * Dedicated diagnostics fixtures exercise the real observer and worker. */
#ifndef NV_DIAG_OBSERVE_H
#define NV_DIAG_OBSERVE_H
#include "nvdiag.h"
#ifdef __APPLE__
#define NVD_OPTIONAL __attribute__((weak_import))
#else
#define NVD_OPTIONAL __attribute__((weak))
#endif
extern void nvdiag_observe(int code,int a,int b) NVD_OPTIONAL;
#define NVD_NOTE(code,a,b) do { if(nvdiag_observe)nvdiag_observe((code),(a),(b)); } while(0)
#endif
