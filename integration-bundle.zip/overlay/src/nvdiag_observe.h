/* Optional observer for independently linkable playback/account modules.
 * Production links the real provider through the strong Settings/init API.
 * Standalone upstream component fixtures need no diagnostic network/storage.
 * Dedicated diagnostics fixtures exercise the real observer and worker. */
#ifndef NV_DIAG_OBSERVE_H
#define NV_DIAG_OBSERVE_H
#include "nvdiag.h"
#ifdef __APPLE__
#define NVD_OPTIONAL __attribute__((weak))
#else
#define NVD_OPTIONAL __attribute__((weak))
#endif
#ifdef __APPLE__
/* Mach-O requires a link-time definition even for an absent weak import.
 * The real provider is strong and overrides this independently linked fallback. */
NVD_OPTIONAL void nvdiag_observe(int code,int a,int b) { (void)code;(void)a;(void)b; }
#else
extern void nvdiag_observe(int code,int a,int b) NVD_OPTIONAL;
#endif
#define NVD_NOTE(code,a,b) do { if(nvdiag_observe)nvdiag_observe((code),(a),(b)); } while(0)
#endif
