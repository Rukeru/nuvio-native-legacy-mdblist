#include "mdblist.h"
#include "mdblistscrobble.h"
#include "rede.h"
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdatomic.h>

/* FIFO, rather than Trakt's single pending slot: a new episode's start must
   never overwrite the preceding episode's stop. Credentials are copied at
   dispatch and queued work is invalidated on key/profile/consent changes. */
#define MDB_QUEUE 32
typedef struct { int acao, tentativas; char id[64]; double pct; } MdbPedido;
static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
static MdbPedido fila[MDB_QUEUE];
static int inicio, quantidade, fioVivo, ligado, perfil, bloqueado, ultimoHttp;
static unsigned geracao;
static atomic_uint contaGeracao;
unsigned mdblist_geracao_conta(void) { return atomic_load(&contaGeracao); }
static time_t retentar, ultimoStart;
static char chave[80];
static MdbScrobbleEstado estado;
static int limiar=85;
static char completed[64];
void mdblist_limiar(int percent) { pthread_mutex_lock(&trava); limiar=percent<80?80:percent>100?100:percent; pthread_mutex_unlock(&trava); }

static void invalidar(void) {
  inicio = quantidade = bloqueado = ultimoHttp = 0;
  retentar = ultimoStart = 0; geracao++;
  memset(&estado, 0, sizeof estado); completed[0]=0;
}

void mdblist_definir_chave(const char *nova) {
  char valor[80];
  size_t i, len = nova ? strlen(nova) : 0;
  valor[0] = 0;
  /* Keys from preferences are URL-safe. Reject malformed/truncated values;
     never permit URL/header injection or silently use a partial secret. */
  if (len && len < sizeof valor) {
    for (i = 0; i < len; i++)
      if (!((nova[i] >= 'a' && nova[i] <= 'z') || (nova[i] >= 'A' && nova[i] <= 'Z') ||
            (nova[i] >= '0' && nova[i] <= '9') || nova[i] == '-' || nova[i] == '_')) break;
    if (i == len) memcpy(valor, nova, len + 1);
  }
  pthread_mutex_lock(&trava);
  if (strcmp(chave, valor)) { snprintf(chave, sizeof chave, "%s", valor); invalidar(); contaGeracao++; }
  pthread_mutex_unlock(&trava);
}

static void *trabalhar(void *u) {
  (void)u;
  for (;;) {
    MdbPedido pedido;
    unsigned gen;
    char key[80], url[200], corpo[320], *r;
    int status = 0;
    const char *cab[] = { "Content-Type: application/json", NULL };
    pthread_mutex_lock(&trava);
    if (!ligado || !chave[0] || bloqueado || !quantidade || time(NULL) < retentar) {
      fioVivo = 0; pthread_mutex_unlock(&trava); return NULL;
    }
    pedido = fila[inicio]; gen = geracao;
    int threshold=limiar;
    snprintf(key, sizeof key, "%s", chave);
    pthread_mutex_unlock(&trava);
    double remote=pedido.pct;
    if ((pedido.acao==SCR_PAUSE||pedido.acao==SCR_STOP) && remote<threshold && remote>=80) remote=79.99;
    mdblist_corpo(corpo, sizeof corpo, pedido.id, remote);
    snprintf(url, sizeof url, "https://api.mdblist.com/scrobble/%s?apikey=%s",
             scrobble_nome(pedido.acao), key);
    r = rede_postar_st(url, 15, cab, corpo, &status);
    /* Neither URL/key nor response body is logged: API errors can echo input. */
    printf("[mdblist] %s %.2f%% -> HTTP %d\n", scrobble_nome(pedido.acao), remote, status);
    fflush(stdout);
    free(r);
    memset(key, 0, sizeof key);
    pthread_mutex_lock(&trava);
    if (gen == geracao) {
      ultimoHttp = status;
      if (status == 401 || status == 403) {
        bloqueado = 1; quantidade = 0; /* resume only after credentials change */
      } else if (status == 429) {
        /* rede_postar_st does not expose Retry-After. Conservatively wait for
           the next daily reset (UTC), satisfying either documented quota.
           Keep the FIFO and show the reason in settings; do not hammer it. */
        time_t now = time(NULL);
        retentar = now + (86400 - now % 86400);
      } else if ((status == 0 || status >= 500) && fila[inicio].tentativas < 2) {
        fila[inicio].tentativas++;
        retentar = time(NULL) + (fila[inicio].tentativas == 1 ? 30 : 120);
      } else {
        inicio = (inicio + 1) % MDB_QUEUE; quantidade--; retentar = 0;
      }
    }
    pthread_mutex_unlock(&trava);
  }
}

static void iniciarFio(void) { /* trava held */
  pthread_t t;
  if (fioVivo || !ligado || !chave[0] || bloqueado || !quantidade || time(NULL) < retentar) return;
  fioVivo = 1;
  if (pthread_create(&t, NULL, trabalhar, NULL)) {
    fioVivo = 0; ultimoHttp = 0; retentar = time(NULL) + 30;
  } else pthread_detach(t);
}

void mdblist_atualizar(int novoLigado, int novoPerfil) {
  pthread_mutex_lock(&trava);
  novoLigado = !!novoLigado;
  if (ligado != novoLigado || perfil != novoPerfil) {
    if (perfil != novoPerfil) contaGeracao++;
    invalidar(); ligado = novoLigado; perfil = novoPerfil;
  }
  iniciarFio();
  pthread_mutex_unlock(&trava);
}

int mdblist_credencial(char *dst, size_t n, unsigned *generation) {
  int ok;
  pthread_mutex_lock(&trava);
  ok=chave[0] && n>strlen(chave);
  if (n) snprintf(dst,n,"%s",ok?chave:"");
  if (generation) *generation=contaGeracao;
  pthread_mutex_unlock(&trava);
  return ok;
}

int mdblist_scrobble(int evento, const char *id, double posSeg, double durSeg) {
  char corpo[320];
  MdbScrobbleEstado novo;
  MdbPedido *p;
  int acao;
  double pct;
  /* Mirror the player's guards, including provider error clips and live TV.
     Only canonical IMDb/typed TMDB IDs are accepted; personal-server IDs,
     bare series and unresolved anime/provider IDs are not guessed. */
  if (!isfinite(posSeg) || !isfinite(durSeg) || durSeg < 120) return SCR_NADA;
  pct = posSeg / durSeg * 100;
  if (!mdblist_corpo(corpo, sizeof corpo, id, pct)) return SCR_NADA;
  if (pct < 0) pct = 0;
  if (pct > 100) pct = 100;
  pthread_mutex_lock(&trava);
  if (!ligado || !chave[0] || bloqueado || quantidade == MDB_QUEUE) {
    pthread_mutex_unlock(&trava); return SCR_NADA;
  }
  if (!strcmp(completed,id)) {
    if(evento==SCR_EV_TOCANDO && pct<1)completed[0]=0; /* explicit fresh replay */
    else { pthread_mutex_unlock(&trava); return SCR_NADA; }
  }
  novo = estado;
  acao = mdblist_decidir(&novo, evento, id);
  if(evento==SCR_EV_TOCANDO && pct>=limiar) { acao=SCR_STOP; snprintf(novo.id,sizeof novo.id,"%s",id);novo.fase=SCR_STOP; }
  /* Refresh actual progress after seeks and keep the server runtime estimate
     current, at most once a minute. Do not accumulate refreshes while offline. */
  if (acao == SCR_NADA && evento == SCR_EV_TOCANDO && !quantidade && !retentar &&
      time(NULL) - ultimoStart >= 60) acao = SCR_START;
  if (acao != SCR_NADA) {
    estado = novo;
    if((acao==SCR_PAUSE||acao==SCR_STOP)&&pct>=limiar)snprintf(completed,sizeof completed,"%s",id);
    else if(strcmp(completed,id))completed[0]=0;
    if (acao == SCR_START) ultimoStart = time(NULL);
    p = &fila[(inicio + quantidade++) % MDB_QUEUE];
    p->acao = acao; p->pct = pct; p->tentativas = 0;
    snprintf(p->id, sizeof p->id, "%s", id);
    iniciarFio();
  }
  pthread_mutex_unlock(&trava);
  return acao;
}

const char *mdblist_estado(void) {
  const char *r;
  pthread_mutex_lock(&trava);
  r = !ligado ? "Desligado" : !chave[0] ? "Chave ausente" : bloqueado ? "Chave recusada" :
      ultimoHttp == 429 ? "Limite da API atingido" : retentar ? "Aguardando nova tentativa" :
      ultimoHttp >= 400 ? "Falha no envio" : quantidade ? "Enviando" : "Pronto para rastrear";
  pthread_mutex_unlock(&trava);
  return r;
}
