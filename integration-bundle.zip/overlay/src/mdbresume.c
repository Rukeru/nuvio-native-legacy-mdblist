#include "mdbresume.h"
#include <math.h>
int mdb_resume_apply(MdbItem *item,double pos,double duration,long long updated,int completed) {
 if(!isfinite(pos)||!isfinite(duration)||pos<0||duration<60||pos>duration||duration>604800)return 0;
 double percent=100*pos/duration;
 if(percent>=completed)return -1;
 if(percent<1&&!item->next)return -1;
 item->progress=percent<1?0:percent;item->runtime=(int)(duration/60+0.5);
 item->updated=updated;return 1;
}
