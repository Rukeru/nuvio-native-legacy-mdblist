/* Local-build fallback. Automatic builds replace this with their release notes. */
static const struct { const char *title, *body; } MDB_CHANGES[] = {
  { "Your watched history", "Watched movies and episodes from Nuvio and MDBList now appear on your TV, including older watches." },
  { "A smoother TV experience", "The recent Home and season-progress performance improvements are included." },
  { "What changed, at a glance", "A short changelog appears after updates. Reopen it any time from Settings > About & help > What's new." },
  { "Official Nuvio features", "Includes the features and fixes from the official Nuvio 2.0.2 release." }
};
