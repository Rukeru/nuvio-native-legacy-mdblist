#include "mdbformat.h"
#include "js.h"
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <limits.h>
const char *mdb_prop(const char *p,const char *end,const char *key) {
 if(!p||!end||p>=end||*p!='{')return NULL;
 int depth=0;size_t n=strlen(key);
 while(p<end) {
  if(*p=='"') {const char *start=++p;while(p<end&&*p!='"'){if(*p=='\\'&&p+1<end)p++;p++;}
   if(p>=end)return NULL;const char *value=p+1;while(value<end&&isspace((unsigned char)*value))value++;
   if(depth==1&&(size_t)(p-start)==n&&!memcmp(start,key,n)&&value<end&&*value==':') {value++;while(value<end&&isspace((unsigned char)*value))value++;return value<end?value:NULL;}
  }else if(*p=='{'||*p=='[')depth++;else if(*p=='}'||*p==']'){if(--depth==0)break;}p++;
 }return NULL;
}
const char *mdb_object(const char *obj,const char *end,const char *key) {
 const char *p=mdb_prop(obj,end,key),*f;
 return p&&*p=='{'&&(f=js_fim(p))&&f<=end?p:NULL;
}
double mdb_number(const char *obj,const char *end,const char *key,double fallback) {
 const char *p=mdb_prop(obj,end,key);char *tail;double value;
 if(!p||(!isdigit((unsigned char)*p)&&*p!='-'))return fallback;
 value=strtod(p,&tail);while(tail<end&&isspace((unsigned char)*tail))tail++;
 return isfinite(value)&&tail<end&&(*tail==','||*tail=='}'||*tail==']')?value:fallback;
}
int mdb_text(const char *obj,const char *end,const char *key,char *out,size_t n) {
 const char *p=mdb_prop(obj,end,key);if(n)out[0]=0;
 return p&&*p=='"'&&js_cadeia(p,out,n);
}
static int digits(const char *p) {int n=0;while(isdigit((unsigned char)*p)){p++;n++;}return n&&!*p;}
static int identity(const char *p,const char *end,int show,char *out,size_t n) {
 const char *ids=mdb_object(p,end,"ids");char imdb[64]="";double tmdb=0;
 if(ids) {const char *f=js_fim(ids);mdb_text(ids,f,"imdb",imdb,sizeof imdb);tmdb=mdb_number(ids,f,"tmdb",0);}
 if(!imdb[0])mdb_text(p,end,"imdb_id",imdb,sizeof imdb);
 if(!strncmp(imdb,"tt",2)&&digits(imdb+2)) {snprintf(out,n,"%s",imdb);return 1;}
 /* A bare id may belong to MDBList, an episode or a playback session.
    Only a named external identifier is safe to turn into a TMDB key. */
 if(tmdb>=1&&tmdb<=INT_MAX&&floor(tmdb)==tmdb){snprintf(out,n,"tmdb:%c%d",show?'t':'m',(int)tmdb);return 1;}
 return 0;
}
static long long stamp(const char *p,const char *end,const char *key) {char s[64];return mdb_text(p,end,key,s,sizeof s)?js_ms_iso(s):0;}
static void metadata(const char *p,const char *end,MdbItem *out,int show) {
 memset(out,0,sizeof *out);snprintf(out->type,sizeof out->type,"%s",show?"series":"movie");
 identity(p,end,show,out->id,sizeof out->id);mdb_text(p,end,"title",out->title,sizeof out->title);
 mdb_text(p,end,"poster",out->poster,sizeof out->poster);
 double runtime=mdb_number(p,end,"runtime",0);if(runtime>0&&runtime<=10080)out->runtime=(int)runtime;
}
int mdb_watchlist_body(char *out,size_t n,const char *id,const char *type) {
 int show=type&&!strcmp(type,"series"),written;if(!out||!n)return 0;out[0]=0;
 if(!id||!type||(!show&&strcmp(type,"movie")))return 0;
 if(!strncmp(id,"tt",2)&&digits(id+2))written=snprintf(out,n,"{\"%s\":[{\"ids\":{\"imdb\":\"%s\"}}]}",show?"shows":"movies",id);
 else if(!strncmp(id,show?"tmdb:t":"tmdb:m",6)&&digits(id+6)&&id[6]!='0'&&strlen(id+6)<=10&&strtoull(id+6,NULL,10)<=INT_MAX)written=snprintf(out,n,"{\"%s\":[{\"ids\":{\"tmdb\":%s}}]}",show?"shows":"movies",id+6);
 else return 0;
 return written>0&&(size_t)written<n;
}
static int cursorOf(const char *json,const char *end,char *cursor,size_t n) {
 const char *pagination=mdb_object(json,end,"pagination");
 cursor[0]=0;
 if(mdb_prop(json,end,"next_cursor"))return mdb_text(json,end,"next_cursor",cursor,n)||!strncmp(mdb_prop(json,end,"next_cursor"),"null",4);
 if(pagination&&mdb_prop(pagination,js_fim(pagination),"next_cursor"))return mdb_text(pagination,js_fim(pagination),"next_cursor",cursor,n)||!strncmp(mdb_prop(pagination,js_fim(pagination),"next_cursor"),"null",4);
 return 1;
}
int mdb_parse_watchlist(const char *json,MdbItem *out,int max,char *cursor,size_t size) {
 const char *end=json?js_fim(json):NULL;if(!end||*json!='{'||end==json||end[-1]!='}')return -1;
 if(!mdb_prop(json,end,"movies")&&!mdb_prop(json,end,"shows"))return -1;
 int count=0;
 for(int show=0;show<2;show++) {
  const char *a=mdb_prop(json,end,show?"shows":"movies");if(!a||*a!='[')continue;
  const char *p=a+1;while(p<end&&isspace((unsigned char)*p))p++;
  while(p&&*p=='{'&&count<max){const char *f=js_fim(p);if(!f||f>end)return -1;MdbItem item;metadata(p,f,&item,show);if(item.id[0])out[count++]=item;p=js_prox(f);}
 }
 return cursorOf(json,end,cursor,size)?count:-1;
}
/* Nested show/episode objects are required; episode-level IDs can never
   masquerade as a show's identity. Unknown numbering is omitted. */
static int episodeIdentity(const char *p,const char *end,MdbItem *item,const char *episodeKey) {
 const char *show=mdb_object(p,end,"show"),*ep=mdb_object(p,end,episodeKey);
 if(!show&&ep)show=mdb_object(ep,js_fim(ep),"show");
 if(!show||!ep)return 0;metadata(show,js_fim(show),item,1);if(!item->id[0])return 0;
 double season=mdb_number(ep,js_fim(ep),"season",-1),number=mdb_number(ep,js_fim(ep),"number",-1);
 if(season<0||season>999||number<1||number>9999||floor(season)!=season||floor(number)!=number)return 0;
 item->season=(int)season;item->episode=(int)number;
 double runtime=mdb_number(ep,js_fim(ep),"runtime",0);if(runtime>0&&runtime<=10080)item->runtime=(int)runtime;
 item->air=stamp(ep,js_fim(ep),"air_date");
 return 1;
}
int mdb_parse_playback(const char *json,MdbItem *out,int max) {
 while(json&&isspace((unsigned char)*json))json++;
 const char *rootEnd=json?js_fim(json):NULL;
 const char *p=json?js_raiz_array(json):NULL;if(!json||*json!='['||!rootEnd||rootEnd==json||rootEnd[-1]!=']')return -1;
 int count=0;
 while(p&&*p=='{'&&count<max) {
  const char *end=js_fim(p);if(!end)return -1;MdbItem item;char type[16];
  double progress=mdb_number(p,end,"progress",-1);
  if(!mdb_text(p,end,"type",type,sizeof type)||progress<=0||progress>=80){p=js_prox(end);continue;}
  if(!strcmp(type,"episode")){if(!episodeIdentity(p,end,&item,"episode")){p=js_prox(end);continue;}}
  else if(!strcmp(type,"movie")){const char *movie=mdb_object(p,end,"movie");if(!movie){p=js_prox(end);continue;}metadata(movie,js_fim(movie),&item,0);}
  else {p=js_prox(end);continue;}
  if(item.id[0]) {
   item.progress=progress;item.updated=stamp(p,end,"paused_at");if(!item.updated)item.updated=stamp(p,end,"updated_at");item.expires=stamp(p,end,"expires_at");
   double runtime=mdb_number(p,end,"runtime",0);if(runtime>0&&runtime<=10080)item.runtime=(int)runtime;
   out[count++]=item;
  }p=js_prox(end);
 }return count;
}
int mdb_parse_next(const char *json,MdbItem *out,int max,int *more) {
 const char *end=json?js_fim(json):NULL,*a=end?mdb_prop(json,end,"items"):NULL;
 if(!a||*a!='['||end==json||end[-1]!='}')return -1;const char *v=mdb_prop(json,end,"has_more");*more=v&&!strncmp(v,"true",4);
 const char *p=a+1;while(p<end&&isspace((unsigned char)*p))p++;int count=0;
 while(p&&*p=='{'&&count<max) {const char *f=js_fim(p);if(!f||f>end)return -1;MdbItem item;
  if(episodeIdentity(p,f,&item,"next_episode")) {item.next=1;item.updated=stamp(p,f,"last_watched_at");out[count++]=item;}
  p=js_prox(f);
 }return count;
}
int mdb_filter_watched(const char *json,MdbItem *items,int n,char *cursor,size_t size) {
 const char *end=json?js_fim(json):NULL;if(!end||*json!='{'||end==json||end[-1]!='}')return -1;
 if(!mdb_prop(json,end,"movies")&&!mdb_prop(json,end,"episodes")&&!mdb_prop(json,end,"shows")&&!mdb_prop(json,end,"seasons"))return -1;
 for(int show=0;show<2;show++) {
  const char *a=mdb_prop(json,end,show?"episodes":"movies");if(!a||*a!='[')continue;
  const char *p=a+1;while(p<end&&isspace((unsigned char)*p))p++;
  while(p&&*p=='{') {const char *f=js_fim(p);if(!f||f>end)return -1;MdbItem watched={0};
   if(show)episodeIdentity(p,f,&watched,"episode");else {const char *movie=mdb_object(p,f,"movie");if(movie)metadata(movie,js_fim(movie),&watched,0);}
   long long at=stamp(p,f,"last_watched_at");if(!at)at=stamp(p,f,"watched_at");
   if(watched.id[0]&&at>0)for(int i=0;i<n;i++)if(!strcmp(watched.id,items[i].id)&&watched.season==items[i].season&&watched.episode==items[i].episode&&at>=items[i].updated)items[i].id[0]=0;
   p=js_prox(f);
  }
 }
 if(!cursorOf(json,end,cursor,size))return -1;
 int count=0;for(int i=0;i<n;i++)if(items[i].id[0])items[count++]=items[i];return count;
}
