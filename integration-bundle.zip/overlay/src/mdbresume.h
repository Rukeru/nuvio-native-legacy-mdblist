#ifndef NV_MDB_RESUME_H
#define NV_MDB_RESUME_H
#include "mdbformat.h"
/* -1 local complete/not resumable, 1 precise local selected, 0 no valid local. */
int mdb_resume_apply(MdbItem *item,double pos,double duration,long long updated,int completed);
#endif
