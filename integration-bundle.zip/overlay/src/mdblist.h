#ifndef NV_MDBLIST_H
#define NV_MDBLIST_H
#include <stddef.h>
/* Snapshot for the independent library provider. Never returns a live key
   pointer; generation changes on account/profile changes, not consent. */
int mdblist_credencial(char *dst, size_t n, unsigned *generation);
// Read-only generation for render snapshots; no key copy or tracker mutex.
unsigned mdblist_geracao_conta(void);
/* Playback writes only. Ratings and their master switch remain in extras.c. */
void mdblist_definir_chave(const char *chave);
/* Main loop: apply profile/consent changes and service deferred retries. */
void mdblist_atualizar(int ligado, int perfil);
void mdblist_limiar(int percent);
int mdblist_scrobble(int evento, const char *id, double posSeg, double durSeg);
const char *mdblist_estado(void); /* Portuguese i18n key, no credential material */
#endif
