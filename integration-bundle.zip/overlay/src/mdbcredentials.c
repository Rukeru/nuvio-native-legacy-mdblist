#include "mdbcredentials.h"
#include "dados.h"
#include "sessao.h"
#include "perfis.h"
#include "sync.h"
#include "extras.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
static char owner[80],key[80];
static int profile=-1,pending,pushState,storageError;
static unsigned revision;
static int valid(const char *v) {
  if(!v||strlen(v)>=sizeof key)return 0;
  for(;*v;v++)if(!((*v>='a'&&*v<='z')||(*v>='A'&&*v<='Z')||(*v>='0'&&*v<='9')||*v=='_'||*v=='-'))return 0;
  return 1;
}
static int persist(void) { /* mutex held, never stores a token or response */
  char name[64],body[200];snprintf(name,sizeof name,"mdblist-p%d.txt",profile);
  snprintf(body,sizeof body,"%s\n%d\n%s\n",owner,pending,key);
  storageError=!dados_gravar_privado(name,body);return !storageError;
}
void mdb_credentials_scope(void) {
  const char *uid=sessao_logada()?sessao_usuario():"local";int p=perfis_ativo();
  pthread_mutex_lock(&mutex);
  if(profile!=p||strcmp(owner,uid)) {
    snprintf(owner,sizeof owner,"%s",uid);profile=p;revision++;pending=pushState=storageError=0;key[0]=0;
    char name[64];snprintf(name,sizeof name,"mdblist-p%d.txt",p);
    char *saved=dados_ler(name);
    if(saved) {
      size_t savedSize=strlen(saved);
      char *a=strchr(saved,'\n'),*b=a?strchr(a+1,'\n'):NULL,*c=b?strchr(b+1,'\n'):NULL;
      if(a&&b&&c){*a=*b=*c=0;if(!strcmp(saved,owner)&&valid(b+1)){snprintf(key,sizeof key,"%s",b+1);pending=!strcmp(a+1,"1");}}
      memset(saved,0,savedSize);free(saved);
    }
    extras_definir_chave(key); /* clear the previous profile even if no replacement exists */
  }
  pthread_mutex_unlock(&mutex);
}
int mdb_credentials_manual(const char *v) {
  if(!valid(v))return 0;mdb_credentials_scope();pthread_mutex_lock(&mutex);
  char old[80];snprintf(old,sizeof old,"%s",key);int oldPending=pending;
  snprintf(key,sizeof key,"%s",v);pending=1;pushState=0;revision++;
  int ok=persist();
  if(ok)extras_definir_chave(key);else{snprintf(key,sizeof key,"%s",old);pending=oldPending;}
  memset(old,0,sizeof old);pthread_mutex_unlock(&mutex);return ok;
}
void mdb_credentials_import(const char *v) {
  if(!valid(v))return;mdb_credentials_scope();pthread_mutex_lock(&mutex);
  /* A locally edited key/removal wins until its account write is acknowledged. */
  if(!pending){snprintf(key,sizeof key,"%s",v);revision++;persist();extras_definir_chave(key);}
  pthread_mutex_unlock(&mutex);
}
void mdb_credentials_push(void) {
  char body[120],targetOwner[80];unsigned gen;int targetProfile;
  pthread_mutex_lock(&mutex);
  if(!pending||!sessao_logada()||strcmp(owner,sessao_usuario())||profile!=perfis_ativo()||pushState<0){pthread_mutex_unlock(&mutex);return;}
  gen=revision;targetProfile=profile;snprintf(targetOwner,sizeof targetOwner,"%s",owner);snprintf(body,sizeof body,"{\"api_key\":\"%s\"}",key);pthread_mutex_unlock(&mutex);
  int ok=sync_empurrar_credencial_perfil("mdblist",body,targetProfile,targetOwner);memset(body,0,sizeof body);
  pthread_mutex_lock(&mutex);
  if(gen==revision){pushState=ok;if(ok==1){pending=0;persist();}}
  pthread_mutex_unlock(&mutex);
}
const char *mdb_credentials_status(void) {
  const char *s;pthread_mutex_lock(&mutex);
  s=storageError?"MDBList key could not be saved":pushState<0?"MDBList account sync rejected; local key retained":pending?"MDBList saved locally; account sync pending":key[0]?"MDBList key saved":"MDBList disconnected";
  pthread_mutex_unlock(&mutex);return s;
}
void mdb_credentials_forget(void) {
  pthread_mutex_lock(&mutex);char name[64];for(int i=0;i<=32;i++){snprintf(name,sizeof name,"mdblist-p%d.txt",i);dados_apagar(name);}
  memset(key,0,sizeof key);owner[0]=0;profile=-1;pending=pushState=storageError=0;revision++;
  pthread_mutex_unlock(&mutex);
}
