#include "episodeindex.h"
void episode_index_prepare(EpisodeIndex *v,int item,unsigned revision,int total,
                           int season,int (*read)(void *,int),void *ctx) {
  if(total<0)total=0;
  if(total>EP_INDEX_MAX)total=EP_INDEX_MAX;
  if(v->valid&&v->item==item&&v->revision==revision&&v->total==total&&v->season==season)return;
  v->valid=1;v->item=item;v->revision=revision;v->total=total;v->season=season;v->count=0;
  for(int i=0;i<total;i++)if(season<0||read(ctx,i)==season)v->indices[v->count++]=i;
}
