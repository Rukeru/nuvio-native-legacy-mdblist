/* Bounded private telemetry. This worker owns ALL disk and network operations.
 * UI APIs only copy small typed data under a mutex. No raw-log input exists. */
#include "nvdiag.h"
#include "nvdiag_build.h"
#include "dados.h"
#include "rede.h"
#include "js.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#ifndef NV_VERSAO
#define NV_VERSAO "dev"
#endif
#ifndef NV_DIAG_URL
#define NV_DIAG_URL "https://nuvio-diagnostics-api.rukeru23.workers.dev"
#endif
#if defined(NV_TPK) || defined(__EMSCRIPTEN__)
#define PLATFORM "tizen"
#else
#define PLATFORM "webos"
#endif
#define CREDENTIALS "private-diag-device-v1.txt"
#define PENDING "private-diag-enrollment-v1.txt"
#define CONSENT "private-diag-consent-v1.txt"
#define QUEUE "private-diag-queue-v1.txt"
#define RECEIPT "private-diag-receipt-v1.txt"
static pthread_mutex_t mu=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cv=PTHREAD_COND_INITIALIZER;
static pthread_t thread;
static int started, stopping, prepare, send_requested, consent_dirty, active_automatic;
static NvDiagStatus status;
static NvDiagEvent events[NVD_EVENTS];
static int event_count, events_dirty;
static NvDiagReport preview, requested_report, queue[NVD_QUEUE];
static char preview_json[NVD_PAYLOAD], pair_code[33], manual_id[37];
/* Worker-only secrets: never exposed by status, preview, log or account sync. */
static char installation[37], secret[65];
static time_t last_auto, last_upload;

static int cancelled(void *unused) {
 int stop;(void)unused;
 pthread_mutex_lock(&mu);stop=stopping||(active_automatic&&!status.consent);pthread_mutex_unlock(&mu);return stop;
}
static char *post(const char *url,const char *const *headers,const char *body,int *http) {
 RedePedido request={0};RedeResposta response={0};char *out=NULL;
 request.metodo="POST";request.url=url;request.cabecalhos=headers;
 request.corpo=body;request.n_corpo=strlen(body);request.prazo_ms=10000;
 request.max_bytes=4096;request.max_cabecalhos=4096;
 request.seguir=0;request.tls_pessoal=0;request.parar=cancelled;
 /* The bounded native transport verifies TLS and forbids redirects here. */
 if(rede_pedir(&request,&response)&&response.erro==REDE_OK) {
  *http=response.status;out=response.corpo;response.corpo=NULL;
 } else *http=0;
 rede_resposta_limpar(&response);return out;
}

static int bounded_read(const char *name,char *out,size_t cap) {
 char path[1024]; FILE *f; size_t n; int extra;
 if(!dados_caminho(path,sizeof path,name)||(f=fopen(path,"rb"))==NULL)return 0;
 n=fread(out,1,cap-1,f);extra=fgetc(f);fclose(f);out[n]=0;
 if(extra!=EOF||memchr(out,0,n)) { out[0]=0;return 0; }
 return 1;
}
static int random_hex(char *out,size_t bytes) {
 unsigned char buf[32];FILE *f;size_t n,i;
 if(bytes>sizeof buf||(f=fopen("/dev/urandom","rb"))==NULL)return 0;
 n=fread(buf,1,bytes,f);fclose(f);if(n!=bytes)return 0;
 for(i=0;i<bytes;i++)snprintf(out+2*i,3,"%02x",buf[i]);
 memset(buf,0,sizeof buf);return 1;
}
static int uuid(char out[37]) {
 char hex[33]; if(!random_hex(hex,16))return 0;
 hex[12]='4';hex[16]="89ab"[(unsigned char)hex[16]&3];
 snprintf(out,37,"%.8s-%.4s-%.4s-%.4s-%.12s",hex,hex+8,hex+12,hex+16,hex+20);
 return nvdiag_uuid_valid(out);
}
static int snapshot(NvDiagReport *r,int automatic) {
 memset(r,0,sizeof *r);if(!uuid(r->id))return 0;
 snprintf(r->version,sizeof r->version,"%s",NV_VERSAO);
 snprintf(r->build,sizeof r->build,"%s",NV_DIAG_BUILD);
 r->created=time(NULL);r->automatic=automatic;
 pthread_mutex_lock(&mu);
 r->n=event_count;memcpy(r->events,events,sizeof events);
 pthread_mutex_unlock(&mu);
 if(!r->n)r->events[r->n++]=(NvDiagEvent){NVD_MANUAL,1,0};
 return 1;
}
/* Typed, bounded queue on disk; never replay persisted arbitrary JSON. */
static int save_queue(void) {
 char text[32768];size_t used=0;int i,j,n;
 for(i=0;i<status.queued;i++) {
  NvDiagReport *r=&queue[i];
  n=snprintf(text+used,sizeof text-used,"R %s %s %s %d %d %d %lld %lld\n",r->id,r->version,r->build,
    r->n,r->automatic,r->attempts,(long long)r->created,(long long)r->next);
  if(n<0||(size_t)n>=sizeof text-used)return 0;
  used+=(size_t)n;
  for(j=0;j<r->n;j++) {
   NvDiagEvent e=r->events[j];
   n=snprintf(text+used,sizeof text-used,"E %d %d %d\n",e.code,e.a,e.b);
   if(n<0||(size_t)n>=sizeof text-used)return 0;
   used+=(size_t)n;
  }
 }
 text[used]=0;return dados_gravar_privado(QUEUE,text);
}
static int load_queue(NvDiagReport *loaded,int consent) {
 char text[32768],json[NVD_PAYLOAD],*p,*next; time_t now=time(NULL);
 int count=0;
 if(!bounded_read(QUEUE,text,sizeof text))return 0;
 p=text;
 while(*p&&count<NVD_QUEUE) {
  NvDiagReport r;long long created,scheduled;int consumed=0,i;
  memset(&r,0,sizeof r);next=strchr(p,'\n');if(!next)break;*next=0;
  if(sscanf(p,"R %36s %31s %40s %d %d %d %lld %lld%n",r.id,r.version,r.build,&r.n,&r.automatic,&r.attempts,&created,&scheduled,&consumed)!=8||p[consumed])break;
  if(r.n<1||r.n>NVD_EVENTS||(r.automatic!=0&&r.automatic!=1)||r.attempts<0||r.attempts>8||
     created<0||created>(long long)now||scheduled<0||scheduled>(long long)now+7200)break;
  p=next+1;r.created=(time_t)created;r.next=(time_t)scheduled;
  for(i=0;i<r.n;i++) {
   next=strchr(p,'\n');if(!next)break;*next=0;consumed=0;
   if(sscanf(p,"E %d %d %d%n",&r.events[i].code,&r.events[i].a,&r.events[i].b,&consumed)!=3||p[consumed])break;
   p=next+1;
  }
  if(i!=r.n||!nvdiag_report_json(&r,PLATFORM,json,sizeof json))break;
  if(now-r.created<=14*86400 && (!r.automatic||consent))loaded[count++]=r;
 }
 return count;
}
static void load(void) {
 char text[256],id[37],token[65],extra;long long when;int enabled;
 NvDiagStatus loaded={0};NvDiagReport reports[NVD_QUEUE];
 if(bounded_read(CREDENTIALS,text,sizeof text)&&sscanf(text,"%36s %64s %c",id,token,&extra)==2&&
    nvdiag_uuid_valid(id)&&nvdiag_hex_valid(token,64)) {
  strcpy(installation,id);strcpy(secret,token);loaded.paired=1;
 }
 memset(text,0,sizeof text);memset(token,0,sizeof token);
 if(bounded_read(CONSENT,text,sizeof text)&&sscanf(text,"private-v1 %d %c",&enabled,&extra)==1&&(enabled==0||enabled==1)) {
  loaded.asked=1;loaded.consent=enabled;
 }
 if(bounded_read(RECEIPT,text,sizeof text)&&sscanf(text,"%7s %lld %c",id,&when,&extra)==2&&strlen(id)==6&&strspn(id,"0123456789ABCDEFGHJKMNPQRSTVWXYZ")==6&&when>0) {
  strcpy(loaded.receipt,id);loaded.last_sent=(time_t)when;
 }
 loaded.queued=load_queue(reports,loaded.consent);
 pthread_mutex_lock(&mu);
 /* A consent decision made while disk initialization runs wins. */
 if(consent_dirty){loaded.consent=status.consent;loaded.asked=status.asked;}
 status=loaded;memcpy(queue,reports,(size_t)loaded.queued*sizeof *queue);
 pthread_mutex_unlock(&mu);
}
static void pair(const char *code) {
 char pending[128],old_code[33]="",token[65]="",body[256],id[37]="",extra;
 char *reply=NULL;const char *headers[]={"Content-Type: application/json",NULL};int http=0,ok=0;
 if(bounded_read(PENDING,pending,sizeof pending))sscanf(pending,"%32s %64s %c",old_code,token,&extra);
 if(strcmp(old_code,code)||!nvdiag_hex_valid(token,64)) {
  if(!random_hex(token,32))goto done;
  snprintf(pending,sizeof pending,"%s %s\n",code,token);
  if(!dados_gravar_privado(PENDING,pending))goto done;
 }
 snprintf(body,sizeof body,"{\"code\":\"%s\",\"token\":\"%s\",\"platform\":\"%s\"}",code,token,PLATFORM);
 reply=post(NV_DIAG_URL "/v1/enroll",headers,body,&http);
 if(http==200&&reply&&js_texto_raiz(reply,"installation_id",id,sizeof id)&&nvdiag_uuid_valid(id)) {
  snprintf(pending,sizeof pending,"%s %s\n",id,token);
  if(dados_gravar_privado(CREDENTIALS,pending)) {
   strcpy(installation,id);strcpy(secret,token);dados_apagar(PENDING);ok=1;
  }
 }
done:
 free(reply);memset(token,0,sizeof token);memset(body,0,sizeof body);memset(pending,0,sizeof pending);
 pthread_mutex_lock(&mu);
 if(ok){status.paired=1;status.pairing=2;}else status.pairing=3;
 status.http=http;
 pthread_mutex_unlock(&mu);
}
static void remove_report(int i) {
 memmove(queue+i,queue+i+1,(size_t)(status.queued-i-1)*sizeof *queue);status.queued--;
}
static void upload(int index) {
 NvDiagReport r=queue[index];char json[NVD_PAYLOAD],authorization[160],code[8]="",receipt[64];
 const char *headers[]={authorization,"Content-Type: application/json",NULL};char *reply;int http=0,ok;
 if(!nvdiag_report_json(&r,PLATFORM,json,sizeof json))return;
 pthread_mutex_lock(&mu);
 if(stopping||(r.automatic&&!status.consent)){pthread_mutex_unlock(&mu);return;}
 active_automatic=r.automatic;
 /* The Send action reads attempts under mu; reserve it under the same lock.
  * Disk and HTTPS remain outside the UI mutex. */
 queue[index].attempts++;queue[index].next=time(NULL)+nvdiag_backoff(queue[index].attempts,0);
 pthread_mutex_unlock(&mu);
 /* Persist the attempt before transmission; crashes cannot reset retry caps. */
 if(!save_queue()) {
  pthread_mutex_lock(&mu);active_automatic=0;pthread_mutex_unlock(&mu);return;
 }
 snprintf(authorization,sizeof authorization,"Authorization: Bearer nv1.%s.%s",installation,secret);
 reply=post(NV_DIAG_URL "/v1/diagnostics",headers,json,&http);
 ok=(http==200||http==201)&&reply&&js_texto_raiz(reply,"code",code,sizeof code)&&strlen(code)==6&&strspn(code,"0123456789ABCDEFGHJKMNPQRSTVWXYZ")==6;
 free(reply);memset(authorization,0,sizeof authorization);last_upload=time(NULL);
 pthread_mutex_lock(&mu);
 active_automatic=0;
 if(!r.automatic && !strcmp(r.id,manual_id))status.http=http;
 if(ok) {
  if(!r.automatic && !strcmp(r.id,manual_id)) {
   snprintf(status.receipt,sizeof status.receipt,"%s",code);status.last_sent=last_upload;status.state=2;
  }
  remove_report(index);
 } else {
  if(!r.automatic && !strcmp(r.id,manual_id))status.state=3;
  if(http==401)status.paired=0;
  if(http>=400&&http<500&&http!=429&&http!=401)queue[index].attempts=8;
  queue[index].next=last_upload+nvdiag_backoff(queue[index].attempts,http);
 }
 pthread_mutex_unlock(&mu);
 save_queue();
 if(ok) { snprintf(receipt,sizeof receipt,"%s %lld\n",code,(long long)last_upload);dados_gravar_privado(RECEIPT,receipt); }
}
static void *worker(void *unused) {
 (void)unused;
 /* Init reads outside the mutex; UI sees ready=0 until loading completes. */
 load();
 pthread_mutex_lock(&mu);
 status.ready=NV_DIAG_VERIFIED && nvdiag_hex_valid(NV_DIAG_BUILD,40) && !strcmp(NV_DIAG_URL,"https://nuvio-diagnostics-api.rukeru23.workers.dev");
 pthread_mutex_unlock(&mu);
 for(;;) {
  int do_prepare,do_send,do_consent,enabled,do_auto=0,i,ready,pruned=0;char code[33];time_t now=time(NULL);NvDiagReport r,to_send;
  pthread_mutex_lock(&mu);
  if(stopping){pthread_mutex_unlock(&mu);break;}
  do_prepare=prepare;prepare=0;do_send=send_requested;send_requested=0;
  if(do_send)to_send=requested_report;
  do_consent=consent_dirty;consent_dirty=0;enabled=status.consent;
  strcpy(code,pair_code);memset(pair_code,0,sizeof pair_code);ready=status.ready;
  if(ready&&status.paired&&enabled&&events_dirty&&now-last_auto>=3600&&status.queued<NVD_QUEUE){do_auto=1;events_dirty=0;last_auto=now;}
  pthread_mutex_unlock(&mu);
  if(do_consent) {
   int saved=dados_gravar_privado(CONSENT,enabled?"private-v1 1\n":"private-v1 0\n");
   pthread_mutex_lock(&mu);
   if(!saved){status.consent=0;status.asked=0;enabled=0;}
   if(!enabled)for(i=status.queued-1;i>=0;i--)if(queue[i].automatic)remove_report(i);
   pthread_mutex_unlock(&mu);save_queue();
  }
  if(code[0]&&ready)pair(code);
  memset(code,0,sizeof code);
  if(do_prepare) {
   char json[NVD_PAYLOAD];int ok=snapshot(&r,0)&&nvdiag_report_json(&r,PLATFORM,json,sizeof json);
   pthread_mutex_lock(&mu);
   status.preview_ready=ok;status.state=0;status.http=0;status.receipt[0]=0;
   if(ok){preview=r;strcpy(preview_json,json);}else preview_json[0]=0;
   pthread_mutex_unlock(&mu);
  }
  if(do_send) {
   pthread_mutex_lock(&mu);
   if(status.queued<NVD_QUEUE) {
    int exists=0;for(i=0;i<status.queued;i++)if(!strcmp(queue[i].id,to_send.id))exists=1;
    if(!exists)queue[status.queued++]=to_send;
    if(!strcmp(to_send.id,manual_id))status.state=1;
   }else if(!strcmp(to_send.id,manual_id))status.state=3;
   pthread_mutex_unlock(&mu);save_queue();
  }
  if(do_auto&&snapshot(&r,1)) {
   pthread_mutex_lock(&mu);if(status.consent&&status.queued<NVD_QUEUE)queue[status.queued++]=r;pthread_mutex_unlock(&mu);
   save_queue();
  }
  pthread_mutex_lock(&mu);
  i=-1;
  /* Long-lived sessions retain the same 14-day bound as startup loading. */
  { int j;for(j=status.queued-1;j>=0;j--)if(now-queue[j].created>14*86400){remove_report(j);pruned=1;} }
  if(ready&&status.paired&&now-last_upload>=60) {
   int j;for(j=0;j<status.queued;j++)if(queue[j].attempts<8&&queue[j].next<=now&&(!queue[j].automatic||status.consent)){i=j;break;}
  }
  status.next=i>=0?now:0;
  pthread_mutex_unlock(&mu);
  if(pruned)save_queue();
  if(i>=0)upload(i);
  pthread_mutex_lock(&mu);
  if(!stopping&&!prepare&&!send_requested&&!consent_dirty&&!pair_code[0]) {
   struct timespec deadline;clock_gettime(CLOCK_REALTIME,&deadline);deadline.tv_sec++;
   pthread_cond_timedwait(&cv,&mu,&deadline);
  }
  pthread_mutex_unlock(&mu);
 }
 save_queue();memset(secret,0,sizeof secret);return NULL;
}
void nvdiag_init(void) {
 pthread_mutex_lock(&mu);
 if(!started) {stopping=0;if(pthread_create(&thread,NULL,worker,NULL)==0)started=1;}
 pthread_mutex_unlock(&mu);
}
void nvdiag_shutdown(void) {
 int join;pthread_mutex_lock(&mu);join=started;stopping=1;pthread_cond_signal(&cv);pthread_mutex_unlock(&mu);
 if(join)pthread_join(thread,NULL);
 pthread_mutex_lock(&mu);started=0;pthread_mutex_unlock(&mu);
}
void nvdiag_event(int code,int a,int b) {
 NvDiagEvent e={code,a,b};int i;if(!nvdiag_event_valid(e))return;
 pthread_mutex_lock(&mu);
 for(i=0;i<event_count;i++)if(!memcmp(events+i,&e,sizeof e)){pthread_mutex_unlock(&mu);return;}
 if(event_count==NVD_EVENTS){memmove(events,events+1,(NVD_EVENTS-1)*sizeof *events);event_count--;}
 events[event_count++]=e;events_dirty=1;
 pthread_mutex_unlock(&mu);
}
void nvdiag_observe(int code,int a,int b) { nvdiag_event(code,a,b); }
void nvdiag_performance(unsigned frame_ms,unsigned memory_mb) {
 /* UI-thread accumulator: no lock, allocation, IO or network per frame. */
 static unsigned frames,slow,total,worst;static time_t last;
 frames++;total+=frame_ms;if(frame_ms>33)slow++;if(frame_ms>worst)worst=frame_ms;
 if(frames<600)return;
 if(time(NULL)-last>=3600) {
  if(slow>=120||worst>=250) {nvdiag_event(NVD_SLOW,total?(int)(1000u*frames/total):0,worst>10000?10000:(int)worst);last=time(NULL);}
  if(memory_mb>=512&&memory_mb<=32768){nvdiag_event(NVD_MEMORY,(int)memory_mb,0);last=time(NULL);}
 }
 frames=slow=total=worst=0;
}
void nvdiag_preview(void) {
 pthread_mutex_lock(&mu);prepare=1;status.preview_ready=0;status.state=0;status.http=0;status.receipt[0]=0;
 manual_id[0]=0;preview_json[0]=0;pthread_cond_signal(&cv);pthread_mutex_unlock(&mu);
}
int nvdiag_preview_copy(char *out,size_t cap) {
 int ok;pthread_mutex_lock(&mu);ok=status.preview_ready&&cap>strlen(preview_json);
 if(out&&cap){if(ok)strcpy(out,preview_json);else out[0]=0;}else ok=0;
 pthread_mutex_unlock(&mu);return ok;
}
int nvdiag_send(void) {
 int ok,i;pthread_mutex_lock(&mu);ok=status.ready&&status.paired&&status.preview_ready&&status.queued<NVD_QUEUE&&!send_requested;
 for(i=0;ok&&i<status.queued;i++)if(!strcmp(queue[i].id,preview.id)&&queue[i].attempts>=8)ok=0;
 if(ok){requested_report=preview;strcpy(manual_id,preview.id);send_requested=1;status.state=1;pthread_cond_signal(&cv);}else status.state=3;
 pthread_mutex_unlock(&mu);return ok;
}
void nvdiag_consent(int enabled) {
 pthread_mutex_lock(&mu);status.consent=!!enabled;status.asked=1;consent_dirty=1;pthread_cond_signal(&cv);pthread_mutex_unlock(&mu);
}
int nvdiag_pair(const char *code) {
 int ok=0;if(!nvdiag_hex_valid(code,32))return 0;
 pthread_mutex_lock(&mu);
 if(status.ready&&status.pairing!=1){strcpy(pair_code,code);status.pairing=1;pthread_cond_signal(&cv);ok=1;}
 pthread_mutex_unlock(&mu);return ok;
}
void nvdiag_status(NvDiagStatus *out) {
 if(!out)return;
 pthread_mutex_lock(&mu);*out=status;pthread_mutex_unlock(&mu);
}
