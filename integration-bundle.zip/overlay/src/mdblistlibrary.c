#include "mdblistlibrary.h"
#include "mdbformat.h"
#include "mdblist.h"
#include "mdblistscrobble.h"
#include "rede.h"
#include "js.h"
#include "progresso.h"
#include "ajustes.h"
#include "cwordem.h"
#include "mdbresume.h"
#include "mdbwatched.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define WATCH_MAX 2000
#define CW_MAX 128
#define JOB_MAX 32
typedef struct { unsigned serial,generation; int add,clear,state; char id[64],type[8]; } Job;
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER,network=PTHREAD_MUTEX_INITIALIZER;
static MdbItem *watch;
static MdbItem cw[CW_MAX];
static int cwN;
static time_t cwAt;
static int watchN,blocked,worker,noticeCode,verifyPending,connection;
static time_t watchAt,backoff;
static unsigned generation,serial;
#define HISTORY_MAX 16000
static ContaVisto *historyReady;
static int historyReadyN, historyPending;
static unsigned historyReadyGen;
static time_t historyAt;
static Job jobs[JOB_MAX];
static pthread_mutex_t nextLock=PTHREAD_MUTEX_INITIALIZER;
static char nextIds[CW_MAX][96];
static int nextCount;
static unsigned nextGeneration;
/* Code 1 means a confirmed write; 2 a failure with local state retained;
   3 a failed read using any previous snapshot. No response text is surfaced. */
static int credentials(char *key,unsigned *gen) {
 int ok=mdblist_credencial(key,80,gen);
 pthread_mutex_lock(&lock);
 if(generation!=*gen) {
  generation=*gen;watchN=cwN=0;watchAt=cwAt=backoff=0;blocked=0;noticeCode=0;
  verifyPending=ok;connection=ok?1:0;
  free(historyReady);historyReady=NULL;historyReadyN=historyPending=0;historyAt=0;
  free(watch);watch=NULL;
  for(int i=0;i<JOB_MAX;i++)if(jobs[i].state==1)jobs[i].state=3;
 }
 pthread_mutex_unlock(&lock);return ok;
}
int mdb_library_connected(void) {char key[80];unsigned gen;int ok=credentials(key,&gen);memset(key,0,sizeof key);return ok;}
const char *mdb_library_status(void) {
 pthread_mutex_lock(&lock);int state=connection;pthread_mutex_unlock(&lock);
 return state==2?"MDBList connected":state==3?"MDBList API key rejected":state==4?"MDBList rate limited":state==5?"MDBList network unavailable":state==6?"MDBList response not recognized":state==1?"Checking MDBList API key":"MDBList key missing";
}
static void problem(unsigned gen,int http,int retry,int writing) {
 pthread_mutex_lock(&lock);
 if(gen==generation) {
  if(!writing&&http==422&&noticeCode>=4){pthread_mutex_unlock(&lock);return;}
  if(http==401||http==403)blocked=1;
  connection=http==401||http==403?3:http==429?4:http==0||http>=500?5:6;
  time_t until=time(NULL)+(http==429?(retry>0?retry:3600):60);
  if(until>backoff)backoff=until;
  noticeCode=writing?2:http==401||http==403?4:http==429?5:http==0||http>=500?6:7;
 }
 pthread_mutex_unlock(&lock);
}
static char *get(const char *path,const char *key,unsigned gen) {
 char url[4096],auth[112];int http=0,retry=0;
 snprintf(url,sizeof url,"https://api.mdblist.com%s%capikey=%s",path,strchr(path,'?')?'&':'?',key);
 auth[0]=0;
 const char *headers[]={"Accept: application/json",NULL};
 char *body=rede_baixar_st_retry(url,15,headers,&http,&retry);
 memset(auth,0,sizeof auth);
 if(http<200||http>=300||!body){free(body);problem(gen,http,retry,0);return NULL;}
 pthread_mutex_lock(&lock);if(gen==generation)connection=2;pthread_mutex_unlock(&lock);
 return body;
}
static int allowed(unsigned gen) {
 pthread_mutex_lock(&lock);int ok=gen==generation&&!blocked&&time(NULL)>=backoff;pthread_mutex_unlock(&lock);return ok;
}
static int encode(char *dst,size_t n,const char *p) {
 const char hex[]="0123456789ABCDEF";size_t used=0;
 for(;*p;p++){unsigned char c=(unsigned char)*p;int plain=(c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~';
  if(used+(plain?1:3)>=n)return 0;if(plain)dst[used++]=(char)c;else{dst[used++]='%';dst[used++]=hex[c>>4];dst[used++]=hex[c&15];}}
 dst[used]=0;return 1;
}
static int same(const MdbItem *a,const MdbItem *b) {return !strcmp(a->id,b->id)&&!strcmp(a->type,b->type)&&a->season==b->season&&a->episode==b->episode;}
static void toCat(const MdbItem *item,CatItem *out) {
 memset(out,0,sizeof *out);
 if(item->episode)snprintf(out->imdb,sizeof out->imdb,"%s:%d:%d",item->id,item->season,item->episode);
 else snprintf(out->imdb,sizeof out->imdb,"%s",item->id);
 snprintf(out->tipo,sizeof out->tipo,"%s",item->type);
 snprintf(out->titulo,sizeof out->titulo,"%s",item->title[0]?item->title:item->id);
 snprintf(out->poster,sizeof out->poster,"%s",item->poster);
 /* Existing metadata discovery supplies full cards when opened. IMDb's
    public poster fallback follows the other providers' convention. */
 if(!out->poster[0]&&!strncmp(item->id,"tt",2))snprintf(out->poster,sizeof out->poster,"https://images.metahub.space/poster/medium/%s/img",item->id);
 out->temporada=item->season;out->episodio=item->episode;
 out->progresso=(int)item->progress;out->retomadoMs=item->updated;
 if(item->runtime>0)out->restanteMin=(int)(item->runtime*(100-item->progress)/100.0+0.5);
}
int mdb_library_watchlist(CatItem *out,int max) {
 char key[80];unsigned gen;
 if(!credentials(key,&gen)) {pthread_mutex_lock(&lock);noticeCode=3;pthread_mutex_unlock(&lock);return 0;}
 if(!out) {
  pthread_mutex_lock(&network);
  pthread_mutex_lock(&lock);int fresh=watchAt&&time(NULL)-watchAt<300;pthread_mutex_unlock(&lock);
  if(!fresh&&allowed(gen)) {
   MdbItem *next=calloc(WATCH_MAX,sizeof *next),*page=calloc(200,sizeof *page);
   char cursor[1024]="",previous[1024]="",escaped[3072],path[3400];int n=0,ok=next&&page;
   for(int p=0;ok&&p<100;p++) {
    if(!encode(escaped,sizeof escaped,cursor)){ok=0;break;}
    snprintf(path,sizeof path,"/watchlist/items?limit=100&append_to_response=poster&cursor=%s",escaped);
    char *body=get(path,key,gen);if(!body){ok=0;break;}
    snprintf(previous,sizeof previous,"%s",cursor);
    int count=mdb_parse_watchlist(body,page,200,cursor,sizeof cursor);free(body);
    if(count<0){ok=0;break;}
    for(int i=0;i<count;i++) {int duplicate=0;for(int j=0;j<n;j++)if(same(page+i,next+j)){duplicate=1;break;}
     if(!duplicate){if(n==WATCH_MAX){ok=0;break;}next[n++]=page[i];}}
    if(!ok||!cursor[0])break;
    if(!strcmp(previous,cursor)||p==99){ok=0;break;}
   }
   pthread_mutex_lock(&lock);
   if(ok&&gen==generation){free(watch);watch=next;next=NULL;watchN=n;watchAt=time(NULL);}
   pthread_mutex_unlock(&lock);
   if(!ok)problem(gen,422,0,0);
   free(next);free(page);
  }
  pthread_mutex_unlock(&network);
 }
 memset(key,0,sizeof key);
 pthread_mutex_lock(&lock);int n=gen==generation?watchN:0;
 if(out){if(n>max)n=max;for(int i=0;i<n;i++){toCat(watch+i,out+i);out[i].naLista=1;}}
 pthread_mutex_unlock(&lock);return n;
}
static int writeOK(const char *body,int clear,int add) {
 const char *end=body?js_fim(body):NULL;if(!end||*body!='{')return 0;
 if(clear) {const char *v=mdb_prop(body,end,"deleted");return v&&(!strncmp(v,"true",4)||!strncmp(v,"false",5));}
 double missing=mdb_number(body,end,"not_found",-1);
 if(missing!=0)return 0;
 if(add)return mdb_number(body,end,"added",0)+mdb_number(body,end,"existing",0)>=1;
 /* The remove route uses the documented result envelope as well. A
    missing target is already removed; not_found is not silently accepted. */
 return mdb_prop(body,end,"added")||mdb_prop(body,end,"existing")||mdb_prop(body,end,"removed");
}
/* Independent of Continue Watching choice and playback reporting consent.
   A failed/looped/oversized page never publishes partial watched history. */
static void readHistory(const char *key,unsigned gen) {
 ContaVisto *next=calloc(HISTORY_MAX,sizeof *next),*pageRows=calloc(HISTORY_MAX,sizeof *pageRows);
 unsigned short *seen=calloc(32768,sizeof *seen);
 int count=0,ok=next&&pageRows&&seen;
 char cursor[1024]="",previous[1024],escaped[3072],path[3500];int offset=0;
 for(int page=0;ok&&page<32;page++) {
  if(!allowed(gen)||!encode(escaped,sizeof escaped,cursor)){ok=0;break;}
  if(cursor[0])snprintf(path,sizeof path,"/sync/watched?limit=1000&cursor=%s",escaped);
  else snprintf(path,sizeof path,"/sync/watched?limit=1000&offset=%d",offset);
  char *body=get(path,key,gen);if(!body){ok=0;break;}
  strcpy(previous,cursor);int more=0;
  int got=mdb_watched_page(body,pageRows,HISTORY_MAX,cursor,sizeof cursor,&more);free(body);
  if(got<0){ok=0;break;}
  for(int i=0;i<got;i++) {
   ContaVisto *v=pageRows+i;unsigned hash=2166136261u;
   for(const unsigned char *p=(unsigned char *)v->id;*p;p++)hash=(hash^*p)*16777619u;
   hash=(hash^(unsigned)v->temporada)*16777619u;hash=(hash^(unsigned)v->episodio)*16777619u;
   hash=(hash^(unsigned char)v->tipo[0])*16777619u;unsigned slot=hash&32767u;
   while(seen[slot]) {
    ContaVisto *old=next+seen[slot]-1;
    if(old->temporada==v->temporada&&old->episodio==v->episodio&&!strcmp(old->id,v->id)&&!strcmp(old->tipo,v->tipo))break;
    slot=(slot+1)&32767u;
   }
   if(seen[slot]){ContaVisto *old=next+seen[slot]-1;if(v->vistoMs>old->vistoMs)*old=*v;}
   else {if(count==HISTORY_MAX){ok=0;break;}seen[slot]=(unsigned short)(count+1);next[count++]=*v;}
  }
  if(!ok)break;
  if(!more)break;
  if((cursor[0]&&!strcmp(cursor,previous))||page==31){ok=0;break;}
  offset+=1000;
 }
 pthread_mutex_lock(&lock);
 if(ok&&gen==generation) {
  free(historyReady);historyReady=next;next=NULL;historyReadyN=count;
  historyReadyGen=gen;historyPending=1;historyAt=time(NULL);
 }
 pthread_mutex_unlock(&lock);free(next);free(pageRows);free(seen);
 if(!ok)problem(gen,422,0,0);
}
void mdb_library_history_tick(void) {
 ContaVisto *copy=NULL;int n=0,ready=0;
 pthread_mutex_lock(&lock);
 if(historyPending&&historyReadyGen==generation&&generation==mdblist_geracao_conta()) {
  copy=historyReady;historyReady=NULL;n=historyReadyN;ready=1;historyPending=0;
 }
 pthread_mutex_unlock(&lock);
 if(ready)contalib_mdb_vistos(copy,n);
}
static void *run(void *unused) {
 (void)unused;
 char validationKey[80];unsigned validationGen;
 int hasKey=credentials(validationKey,&validationGen);
 pthread_mutex_lock(&lock);int verify=verifyPending;pthread_mutex_unlock(&lock);
 if(hasKey&&verify&&allowed(validationGen)) {
  pthread_mutex_lock(&network);
  char *body=get("/user",validationKey,validationGen);
  if(body) {
   char username[128];int valid=(js_texto_raiz_em(body,js_fim(body),"username",username,sizeof username)&&username[0])||mdb_number(body,js_fim(body),"user_id",0)>0;
   pthread_mutex_lock(&lock);
   if(validationGen==generation){verifyPending=0;connection=valid?2:6;}
   pthread_mutex_unlock(&lock);
   if(!valid)problem(validationGen,422,0,0);
   free(body);
  }
  pthread_mutex_unlock(&network);
 }
 pthread_mutex_lock(&lock);int needHistory=!historyAt||time(NULL)-historyAt>=600;pthread_mutex_unlock(&lock);
 if(hasKey&&needHistory&&allowed(validationGen)) {
  pthread_mutex_lock(&network);readHistory(validationKey,validationGen);pthread_mutex_unlock(&network);
 }
 memset(validationKey,0,sizeof validationKey);
 for(;;) {
  Job job={0};int slot=-1;char key[80];unsigned gen;
  int valid=credentials(key,&gen);
  pthread_mutex_lock(&lock);
  for(int i=0;i<JOB_MAX;i++)if(jobs[i].state==1&&(slot<0||jobs[i].serial<job.serial)){slot=i;job=jobs[i];}
  if(slot<0){worker=0;pthread_mutex_unlock(&lock);memset(key,0,sizeof key);return NULL;}
  pthread_mutex_unlock(&lock);
  int ok=0,http=0;
  pthread_mutex_lock(&network);
  if(valid&&job.generation==gen&&allowed(gen)) {
   char body[320],url[256],auth[112];
   int formatted=job.clear?mdblist_corpo(body,sizeof body,job.id,0):mdb_watchlist_body(body,sizeof body,job.id,job.type);
   if(formatted) {
    snprintf(url,sizeof url,"https://api.mdblist.com%s?apikey=%s",job.clear?"/scrobble/clear":job.add?"/watchlist/items/add":"/watchlist/items/remove",key);
    auth[0]=0;
    const char *headers[]={"Content-Type: application/json",NULL};
    char *reply=rede_postar_st(url,15,headers,body,&http);
    ok=http>=200&&http<300&&writeOK(reply,job.clear,job.add);free(reply);memset(auth,0,sizeof auth);
   }
  }
  memset(key,0,sizeof key);
  if(!ok)problem(gen,http,0,1);
  pthread_mutex_lock(&lock);
  if(jobs[slot].serial==job.serial)jobs[slot].state=ok&&gen==generation?2:3;
  if(gen==generation){watchAt=cwAt=0;if(ok)connection=2;if(noticeCode!=2)noticeCode=ok?1:2;
   if(ok&&!job.clear&&!job.add) {int w=0;for(int i=0;i<watchN;i++)if(strcmp(watch[i].id,job.id)||strcmp(watch[i].type,job.type))watch[w++]=watch[i];watchN=w;}
  }
  pthread_mutex_unlock(&lock);pthread_mutex_unlock(&network);
 }
}
void mdb_library_tick(void) {
 char key[80];unsigned gen;int connected=credentials(key,&gen);memset(key,0,sizeof key);
 pthread_mutex_lock(&lock);int pending=0;for(int i=0;i<JOB_MAX;i++)if(jobs[i].state==1)pending=1;
 if((pending||(connected&&!blocked&&time(NULL)>=backoff&&(verifyPending||!historyAt||time(NULL)-historyAt>=600)))&&!worker){pthread_t thread;worker=1;if(pthread_create(&thread,NULL,run,NULL)==0)pthread_detach(thread);else{worker=0;noticeCode=2;for(int i=0;i<JOB_MAX;i++)if(jobs[i].state==1)jobs[i].state=3;}}
 pthread_mutex_unlock(&lock);
}
static unsigned queue(const char *id,const char *type,int add,int clear) {
 char key[80],body[320];unsigned gen;int valid=credentials(key,&gen);memset(key,0,sizeof key);
 int formatted=clear?mdblist_corpo(body,sizeof body,id,0):mdb_watchlist_body(body,sizeof body,id,type);
 pthread_mutex_lock(&lock);int slot=-1;
 for(int i=0;i<JOB_MAX;i++)if(jobs[i].state!=1&&(slot<0||jobs[i].serial<jobs[slot].serial))slot=i;
 if(slot<0){noticeCode=2;pthread_mutex_unlock(&lock);return 0;}
 Job *j=jobs+slot;memset(j,0,sizeof *j);j->serial=++serial;if(!serial)j->serial=++serial;
 j->generation=gen;j->add=add;j->clear=clear;j->state=valid&&formatted?1:3;
 snprintf(j->id,sizeof j->id,"%s",id?id:"");snprintf(j->type,sizeof j->type,"%s",type?type:"");
 if(j->state==3)noticeCode=2;unsigned result=j->serial;pthread_mutex_unlock(&lock);mdb_library_tick();return result;
}
unsigned mdb_library_save(const char *id,const char *type,int add){return queue(id,type,add,0);}
unsigned mdb_library_clear(const char *id){return queue(id,"",0,1);}
int mdb_library_result(unsigned id) {
 int state=3;pthread_mutex_lock(&lock);for(int i=0;i<JOB_MAX;i++)if(jobs[i].serial==id)state=jobs[i].state;pthread_mutex_unlock(&lock);return state;
}
const char *mdb_library_notice(int *refresh) {
 pthread_mutex_lock(&lock);int code=noticeCode;noticeCode=0;pthread_mutex_unlock(&lock);
 *refresh=code==1;
 return code==1?"MDBList sync complete":code==2?"MDBList sync failed. Your local changes are safe. Try again when connected.":code==3?"MDBList key missing. Connect in Settings > Tracking > MDBList.":code==4?"MDBList rejected the API key. Reconnect in Tracking settings.":code==5?"MDBList rate limit reached. Automatic retry is delayed.":code==6?"MDBList network unavailable. Saved data retained; retry scheduled.":code==7?"MDBList returned an unsupported response. Saved data retained.":NULL;
}

/* A complete read is swapped atomically. Limits bound memory and network
   work; a pagination loop or capacity overflow retains the previous snapshot
   and reports failure instead of presenting an incomplete list as current. */
static int cwRead(MdbItem *next,const char *key,unsigned gen) {
 MdbItem *page=calloc(512,sizeof *page);if(!page)return -1;
 char *body=get("/sync/playback",key,gen);int n=-1;
 if(body)n=mdb_parse_playback(body,page,512);free(body);
 if(n<0){free(page);return -1;}
 int count=0;long long oldest=0,now=(long long)time(NULL)*1000;
 for(int i=0;i<n;i++) {
  if(page[i].expires&&page[i].expires<=now)continue;
  if(!page[i].updated)oldest=-1;
  else if(oldest>=0&&(!oldest||page[i].updated<oldest))oldest=page[i].updated;
  int at=-1;for(int j=0;j<count;j++)if(same(page+i,next+j)){at=j;break;}
  if(at>=0){if(page[i].updated>next[at].updated)next[at]=page[i];continue;}
  if(count==CW_MAX){free(page);return -1;}next[count++]=page[i];
 }
 for(int offset=0;offset<2000;offset+=100) {
  char path[180];snprintf(path,sizeof path,"/upnext?limit=100&offset=%d&hide_unreleased=true&air_date_format=instant",offset);
  body=get(path,key,gen);int more=0;int got=body?mdb_parse_next(body,page,512,&more):-1;free(body);
  if(got<0){free(page);return -1;}
  for(int i=0;i<got;i++) {
   if(page[i].air&&page[i].air>now)continue;
   int at=-1;for(int j=0;j<count;j++)if(!strcmp(page[i].id,next[j].id)&&!strcmp(page[i].type,next[j].type)){at=j;break;}
   /* A paused show already has a concrete resume episode. Up Next must not
      replace it merely because watched-history activity has a newer date. */
   if(at>=0)continue;
   if(count==CW_MAX){free(page);return -1;}next[count++]=page[i];
  }
  if(!more)break;
  if(offset==1900){free(page);return -1;}
 }
 free(page);
 if(!count)return 0;
 char since[64]="",cursor[1024]="",previous[1024],escaped[3072],path[3500];
 /* The oldest paused instant bounds the history query. Missing timestamps
    require the bounded full-history fallback. History is ONLY a veto. */
 if(oldest>0) {time_t seconds=(time_t)(oldest/1000);struct tm stamp;
  if(gmtime_r(&seconds,&stamp))strftime(since,sizeof since,"&since=%Y-%m-%dT%H:%M:%SZ",&stamp);
 }
 for(int p=0;p<20;p++) {
  if(!encode(escaped,sizeof escaped,cursor))return -1;
  snprintf(path,sizeof path,"/sync/watched?limit=1000%s&cursor=%s",since,escaped);
  body=get(path,key,gen);snprintf(previous,sizeof previous,"%s",cursor);
  int filtered=body?mdb_filter_watched(body,next,count,cursor,sizeof cursor):-1;free(body);
  if(filtered<0)return -1;count=filtered;
  if(!cursor[0])break;
  if(!strcmp(cursor,previous)||p==19)return -1;
 }
 return count;
}
int mdb_library_continue(CatItem *out,int max) {
 char key[80];unsigned gen;
 if(!credentials(key,&gen)){pthread_mutex_lock(&lock);noticeCode=3;pthread_mutex_unlock(&lock);return 0;}
 pthread_mutex_lock(&network);
 pthread_mutex_lock(&lock);int fresh=cwAt&&time(NULL)-cwAt<300;pthread_mutex_unlock(&lock);
 if(!fresh&&allowed(gen)) {
  MdbItem *next=calloc(CW_MAX,sizeof *next);int n=next?cwRead(next,key,gen):-1;
  pthread_mutex_lock(&lock);
  if(n>=0&&gen==generation){
   memcpy(cw,next,(size_t)n*sizeof *next);cwN=n;cwAt=time(NULL);
   pthread_mutex_lock(&nextLock);nextCount=0;nextGeneration=gen;
   for(int i=0;i<n;i++)if(next[i].next)snprintf(nextIds[nextCount++],sizeof nextIds[0],"%s:%d:%d",next[i].id,next[i].season,next[i].episode);
   pthread_mutex_unlock(&nextLock);
  }
  pthread_mutex_unlock(&lock);free(next);
  if(n<0)problem(gen,422,0,0);
 }
 pthread_mutex_unlock(&network);memset(key,0,sizeof key);
 /* Copy compact data before consulting progress (a different mutex). No
    reverse lock order, and no estimated seconds are written to disk. */
 MdbItem *copy=calloc(CW_MAX,sizeof *copy);if(!copy)return 0;
 pthread_mutex_lock(&lock);int n=gen==generation?cwN:0;memcpy(copy,cw,(size_t)n*sizeof *copy);pthread_mutex_unlock(&lock);
 int w=0;
 for(int i=0;i<n;i++) {
  char progressKey[48];ProgRegistro local;
  prog_chave(progressKey,sizeof progressKey,copy[i].id,copy[i].season,copy[i].episode);
  if(prog_por_chave(progressKey,&local)&&mdb_resume_apply(copy+i,local.posSeg,local.durSeg,local.lastWatchedMs,ajustes_cw_concluido())<0)continue;
  if(copy[i].expires&&copy[i].expires<=(long long)time(NULL)*1000)continue;
  copy[w++]=copy[i];
 }
 n=w;
 for(int i=1;i<n;i++){MdbItem value=copy[i];int j=i;while(j>0&&copy[j-1].updated<value.updated){copy[j]=copy[j-1];j--;}copy[j]=value;}
 if(n>max)n=max;
 for(int i=0;i<n;i++){toCat(copy+i,out+i);if(copy[i].next)cwo_marcar_estreia(out[i].imdb,copy[i].air?copy[i].air:CWO_SEM_DATA);}
 free(copy);return n;
}
int mdb_library_next(const char *id) {
 if(!id)return 0;unsigned gen=mdblist_geracao_conta();
 int found=0;pthread_mutex_lock(&nextLock);
 if(gen==nextGeneration)for(int i=0;i<nextCount&&!found;i++)found=!strcmp(id,nextIds[i]);
 pthread_mutex_unlock(&nextLock);return found;
}
