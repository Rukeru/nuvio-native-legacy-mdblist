#ifndef NV_MDBLIST_CHANNEL_H
#define NV_MDBLIST_CHANNEL_H
/* This custom build only follows releases rebuilt with MDBList tracking. */
#ifndef NV_MDBLIST_UPDATE_REPO
#define NV_MDBLIST_UPDATE_REPO "Rukeru/nuvio-native-legacy-mdblist"
#endif
#define NV_MDBLIST_RELEASE_API "https://api.github.com/repos/" NV_MDBLIST_UPDATE_REPO "/releases/latest"
#define NV_MDBLIST_RELEASE_PAGE "https://github.com/" NV_MDBLIST_UPDATE_REPO "/releases"
#define NV_MDBLIST_DOWNLOAD_PREFIX NV_MDBLIST_RELEASE_PAGE "/download/"
#ifndef NV_MDBLIST_SHELL_ID
#define NV_MDBLIST_SHELL_ID "unconfigured"
#endif
#define NV_MDBLIST_SO_SUFFIX "-" NV_MDBLIST_SHELL_ID "-mdblist-tpk-arm.so"
#define NV_MDBLIST_CONTRACT "nuvio-mdblist-tracking/1"
int mdblist_channel_asset(const char *url);
#endif
