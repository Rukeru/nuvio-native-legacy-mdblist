#ifndef NV_MDBFORMAT_H
#define NV_MDBFORMAT_H
#include <stddef.h>
typedef struct {
 char id[64],type[8],title[160],poster[512];
 int season,episode,runtime,next;
 double progress;
 long long updated,air,expires;
} MdbItem;
const char *mdb_prop(const char *obj,const char *end,const char *key);
const char *mdb_object(const char *obj,const char *end,const char *key);
double mdb_number(const char *obj,const char *end,const char *key,double fallback);
int mdb_text(const char *obj,const char *end,const char *key,char *out,size_t n);
int mdb_watchlist_body(char *out,size_t n,const char *id,const char *type);
int mdb_parse_watchlist(const char *json,MdbItem *out,int max,char *cursor,size_t size);
int mdb_parse_playback(const char *json,MdbItem *out,int max);
int mdb_parse_next(const char *json,MdbItem *out,int max,int *more);
int mdb_filter_watched(const char *json,MdbItem *items,int n,char *cursor,size_t size);
#endif
