#ifndef NV_MDBWATCHED_H
#define NV_MDBWATCHED_H
#include "contalib.h"
/* Compact, positive watched evidence. Shows/seasons are aggregates, never
   evidence that every episode (or the whole series) has been completed. */
int mdb_watched_page(const char *json, ContaVisto *out, int max,
                     char *cursor, unsigned size, int *more);
#endif
