#include "discover.h"
#include "catalogo.h"
#include "discover_catalog.h"
#include "addons.h"
#include "metaprov.h"
#include "ajustes.h"
#include "descoberta.h"
#include "menu.h"
#include "gfx.h"
#include "text.h"
#include "tex_cache.h"
#include "ponteiro.h"
#include "focoprof.h"
#include "idioma.h"
#include <stdio.h>
#include <string.h>

/* Provider catalogues are independent of Home quotas. Keep only visible
   copies; the established asynchronous paging worker owns the result list. */
#define DC_GENRES (DC_CATALOG_GENRES+1)
static int type,catalogue,genre,control,posters,selected,drop=-1,cursor;
static int rowCount,count,genreCount=1,exitRequested,openRequested=-1;
static unsigned revision,addonVersion,metadataRevision;
static DiscoverCatalog currentCatalog;
static char genres[DC_GENRES][48],key[192],selectedId[64];
static CatItem featured,visible[8];
static int visibleStart,visibleCount,metadataIndex=-1;
static Uint32 focusSince;
static const char *media(void){return type ? "series" : "movie";}
static int result(int i,CatItem *out){return desc_vertudo_item(i,out)&&!strcmp(out->tipo,media());}
static void cacheVisible(void){
 visibleStart=selected>3 ? selected-3 : 0;visibleCount=0;memset(&featured,0,sizeof featured);
 for(int i=visibleStart;i<count&&i<visibleStart+8;i++){
  if(result(i,&visible[visibleCount]))visibleCount++;
 }
 if(count&&result(selected,&featured)){
  snprintf(selectedId,sizeof selectedId,"%s",featured.imdb);
  CatItem enriched;
  if(cat_copiar_por_id(featured.imdb,featured.tipo,&enriched)&&enriched.sinopse[0])featured=enriched;
 }else selectedId[0]=0;
 focusSince=0;metadataIndex=-1;metadataRevision=cat_revisao_itens();
}
static const char *filter(void){return genre>0&&genre<genreCount ? genres[genre] : "";}
static const char *base(void){return !rowCount ? "" : currentCatalog.addon==-1 ? METAPROV_NUVIO_HOST : currentCatalog.addon==-2 ? METAPROV_CINEMETA_URL : addons_base(currentCatalog.addon);}
static void request(void){
 if(!rowCount){count=0;memset(&featured,0,sizeof featured);visibleCount=0;return;}
 desc_vertudo_filtro(base(),media(),currentCatalog.id,filter());
 count=desc_vertudo_n();if(selected>=count)selected=count>0 ? count-1 : 0;cacheVisible();
}
static void rebuild(int keep){
 char oldGenre[48];snprintf(oldGenre,sizeof oldGenre,"%s",filter());
 addonVersion=addons_versao();rowCount=dc_catalog_count(media(),addonVersion);int retained=-1;
 for(int i=0;i<rowCount;i++){
  DiscoverCatalog c;if(!dc_catalog_item(media(),addonVersion,i,&c))continue;
  char identity[192];snprintf(identity,sizeof identity,"%d:%s",c.addon,c.id);
  if(!strcmp(identity,key)){retained=i;break;}
  if(!key[0]&&strstr(c.id,"popular")&&retained<0)retained=i;
 }
 catalogue=retained>=0 ? retained : 0;memset(&currentCatalog,0,sizeof currentCatalog);
 if(rowCount)dc_catalog_item(media(),addonVersion,catalogue,&currentCatalog);
 snprintf(key,sizeof key,"%d:%s",currentCatalog.addon,currentCatalog.id);
 genreCount=1;snprintf(genres[0],sizeof genres[0],"All");
 for(int i=0;i<currentCatalog.nGenres&&genreCount<DC_GENRES;i++)snprintf(genres[genreCount++],sizeof genres[0],"%s",currentCatalog.genres[i]);
 genre=currentCatalog.requiresGenre&&genreCount>1 ? 1 : 0;
 if(keep)for(int i=1;i<genreCount;i++)if(!strcmp(oldGenre,genres[i]))genre=i;
 if(!keep)selected=0;
 request();revision=dc_catalog_revision();
 int max=drop==0 ? 2 : drop==1 ? rowCount : genreCount;
 if(cursor>=max)cursor=max>0 ? max-1 : 0;
}
void discover_esquecer(void){
 type=catalogue=genre=control=posters=selected=count=rowCount=0;
 key[0]=selectedId[0]=0;genreCount=1;strcpy(genres[0],"All");
 memset(&featured,0,sizeof featured);visibleCount=0;drop=-1;revision=0;exitRequested=0;openRequested=-1;metadataIndex=-1;
}
void discover_iniciar(void){desc_discover_catalogos();exitRequested=0;openRequested=-1;drop=-1;rebuild(1);}
void discover_atualizar(float dt,Uint32 agora){
 (void)dt;desc_discover_catalogos();
 if(revision!=dc_catalog_revision()||addonVersion!=addons_versao())rebuild(1);
 if(rowCount&&!desc_vertudo_corresponde(base(),media(),currentCatalog.id,filter()))request();
 int n=rowCount ? desc_vertudo_n() : 0;
 if(n!=count){count=n;if(selected>=count)selected=count>0 ? count-1 : 0;cacheVisible();}
 if(count){
  if(!focusSince)focusSince=agora;
  if(metadataIndex<0&&agora-focusSince>=350){
   metadataIndex=cat_indice_por_imdb(featured.imdb);
   if(metadataIndex<0)metadataIndex=cat_acrescentar(&featured);
   if(metadataIndex>=0)desc_episodios_garantir(metadataIndex);
  }
  if(metadataIndex>=0&&metadataRevision!=cat_revisao_itens()){CatItem enriched;metadataRevision=cat_revisao_itens();if(cat_copiar_por_id(featured.imdb,featured.tipo,&enriched)&&enriched.sinopse[0])featured=enriched;}
  if(currentCatalog.skip&&selected>=count-4&&!desc_vertudo_carregando()&&!desc_vertudo_fim()&&!desc_vertudo_erro())desc_vertudo_mais();
 }
}
int discover_quer_sair(void){int v=exitRequested;exitRequested=0;return v;}
int discover_pediu_abrir(int *index){int v=openRequested;openRequested=-1;if(v<0)return 0;if(index)*index=v;return 1;}
static int choices(void){return drop==0 ? 2 : drop==1 ? rowCount : genreCount;}
static void choose(void){
 if(drop==0){type=cursor;key[0]=selectedId[0]=0;genre=0;rebuild(0);}
 else if(drop==1&&rowCount){
  DiscoverCatalog c;if(dc_catalog_item(media(),addonVersion,cursor,&c)){snprintf(key,sizeof key,"%d:%s",c.addon,c.id);selectedId[0]=0;rebuild(0);}
 }else if(drop==2){genre=cursor;selected=0;request();}
 drop=-1;
}
static void openFeatured(void){
 if(!count)return;
 int index=cat_indice_por_imdb(featured.imdb);
 if(index<0)index=cat_acrescentar(&featured);
 if(index>=0)openRequested=index;
}
void discover_evento(const SDL_Event *e) {
  if(e->type!=SDL_KEYDOWN || e->key.repeat)return;
  SDL_Keycode k=e->key.keysym.sym;
  if (k==SDLK_ESCAPE || k==SDLK_BACKSPACE || k==SDLK_AC_BACK) {
    if(drop>=0)drop=-1;else exitRequested=1;return;
  }
  if(drop>=0) {
    if(k==SDLK_UP && cursor>(drop==2&&currentCatalog.requiresGenre ? 1 : 0))cursor--;
    else if(k==SDLK_DOWN && cursor+1<choices())cursor++;
    else if(k==SDLK_RETURN || k==SDLK_KP_ENTER)choose();
    return;
  }
  if(k==SDLK_UP)posters=0;
  else if(k==SDLK_DOWN && count)posters=1;
  else if(k==SDLK_LEFT) {
    if(posters && selected>0){selected--;cacheVisible();}
    else if(!posters && control>0)control--;
    else menu_abrir();
  } else if(k==SDLK_RIGHT) {
    if(posters && selected+1<count){selected++;cacheVisible();}
    else if(!posters && control<2)control++;
  } else if(k==SDLK_RETURN || k==SDLK_KP_ENTER) {
    if(posters) {if(count)openFeatured();else if(desc_vertudo_erro())desc_vertudo_mais();}
    else { drop=control;cursor=control==0 ? type : control==1 ? catalogue : genre; }
  }
}
static void focus(int a,int b) {
  if(drop>=0){if(a==2 && b>=0 && b<choices())cursor=b;return;}
  if(a==0){posters=0;control=b;}
  else if(a==1 && b>=0 && b<count){posters=1;selected=b;cacheVisible();}
}
static void label(const char *s,float x,float y,float width,TxtEstilo style,int active) {
  float r=1,g=1,b=1;if(active)ajustes_acento(&r,&g,&b);
  txt_desenhar(txt_linha_corta(style,s,(int)(255*r),(int)(255*g),(int)(255*b),255,width),x,y);
}
static void image(const char *url,GfxRect rect,int mode) {
  if(!url[0])return;
  GLuint texture=mode==GFX_HERO_CHEIO ? tex_obter_hero(url) : tex_obter_larg(url,rect.w);
  if(texture){gfx_tex_aspect_atual=tex_aspecto(url);gfx_rect(rect,texture,mode,0,0,0,.035f,1,1,1,1);gfx_tex_aspect_atual=0;}
}
void discover_desenhar(Uint32 agora) {
  (void)agora;
  float x=ajustes_conteudo_x();
  const CatItem *it=count ? &featured : NULL;
  gfx_cor((GfxRect){0,0,1920,1080},0,.015f,.015f,.02f,1);
  if(it) {
    image(it->backdrop,(GfxRect){0,0,1920,700},GFX_HERO_CHEIO);
    if(it->logo[0])image(it->logo,(GfxRect){x,170,530,180},GFX_ARTE);
    else label(it->titulo,x,220,750,TXT_TITULO1,0);
    for(int i=0;i<it->nElenco && i<3;i++) {
      float cx=x+i*235;
      image(it->elenco[i].foto,(GfxRect){cx,390,42,42},GFX_AVATAR);
      label(it->elenco[i].nome,cx+52,400,175,TXT_CAPTION,0);
    }
    char meta[320];snprintf(meta,sizeof meta,"%s · %s%s%s",it->genero,it->meta,it->classificacao[0] ? " · " : "",it->classificacao);
    label(meta,x,455,840,TXT_CAPTION,0);
    txt_bloco_corta(TXT_BODY,it->sinopse,220,220,220,x,505,780,1.2f,1,3);
  }
  if(!menu_pilula_titulo())label("Discover",x,65,500,TXT_TITULO2,0);

  const char *values[]={type ? "Series" : "Movies",rowCount ? currentCatalog.name : "No catalogues",genres[genre]};
  const char *filterTitle=strstr(currentCatalog.id,"-year") ? "Year" : strstr(currentCatalog.id,"-language") ? "Language" : "Genre";
  const char *titles[]={"Media type","Catalogue",filterTitle};
  for(int i=0;i<3;i++) {
    GfxRect r={x+i*400,710,380,74};
    gfx_cor(r,.14f,.09f,.09f,.11f,1);
    if(!posters && control==i)foco_anel(r,.14f,1,1);
    label(titles[i],r.x+16,r.y+8,348,TXT_CAPTION2,0);
    label(values[i],r.x+16,r.y+34,348,TXT_BODY,!posters && control==i);
    ponteiro_alvo(r.x,r.y,r.w,r.h,focus,NULL,0,i);
  }
  label(desc_vertudo_erro() ? "Catalogue unavailable · OK to retry" : desc_vertudo_carregando() ? "Loading catalogue…" : "Provider catalogue · declared filters",x,1040,1300,TXT_CAPTION2,0);
  int start=visibleStart;
  for(int i=start;i<start+visibleCount && i<start+7;i++) {
    const CatItem *card=&visible[i-start];
    GfxRect r={x+(i-start)*252,816,236,156};
    if(posters && selected==i){r=foco_zoom(r,1);foco_anel(r,.035f,1,1);}
    image(card->backdrop[0] ? card->backdrop : card->poster,r,GFX_ARTE);
    label(card->titulo,r.x,r.y+r.h+12,r.w,TXT_CAPTION,posters && selected==i);
    if(card->nota) {char rating[24];snprintf(rating,sizeof rating,"%.1f",card->nota/10.0);label(rating,r.x+175,r.y+122,52,TXT_CAPTION2,0);}
    ponteiro_alvo(r.x,r.y,r.w,r.h+42,focus,NULL,1,i);
  }
  if(!count)label(desc_vertudo_carregando() || desc_montando() ? "Loading catalogues…" : "No loaded titles match these filters",x,870,1300,TXT_BODY,0);
  if(drop>=0) {
    ponteiro_camada();
    gfx_cor((GfxRect){0,0,1920,1080},0,0,0,0,.45f);
    int first=cursor>3 ? cursor-3 : 0;
    if(drop==2&&currentCatalog.requiresGenre&&first<1)first=1;
    int n=choices()-first;if(n>6)n=6;if(n<1)n=1;
    GfxRect panel={x+control*400,795,380,n*42.0f+12};
    gfx_cor(panel,.04f,.10f,.08f,.12f,1);
    for(int j=first;j<choices() && j<first+6;j++) {
      DiscoverCatalog c={0};if(drop==1)dc_catalog_item(media(),addonVersion,j,&c);
      const char *value=drop==0 ? (j ? "Series" : "Movies") : drop==1 ? c.name : genres[j];
      GfxRect r={panel.x+6,panel.y+6+(j-first)*42,368,42};
      if(j==cursor)foco_anel(r,.05f,1,1);
      label(value,r.x+12,r.y+8,344,TXT_CAPTION,j==cursor);
      ponteiro_alvo(r.x,r.y,r.w,r.h,focus,NULL,2,j);
    }
  }
}

#ifdef NV_SHOT_HOOKS
/* Isolated renderer fixture: no provider/network state is changed in builds. */
void discover_shot_seed(const CatItem *items,int n){
 discover_esquecer();if(n<0)n=0;if(n>7)n=7;count=n;visibleCount=n;visibleStart=0;
 for(int i=0;i<n;i++)visible[i]=items[i];if(n){featured=items[0];snprintf(selectedId,sizeof selectedId,"%s",featured.imdb);}
 addonVersion=addons_versao();rowCount=dc_catalog_count("movie",addonVersion);
 if(rowCount)dc_catalog_item("movie",addonVersion,0,&currentCatalog);
 genreCount=1;strcpy(genres[0],"All");for(int i=0;i<currentCatalog.nGenres;i++)snprintf(genres[genreCount++],sizeof genres[0],"%s",currentCatalog.genres[i]);
}
#endif
