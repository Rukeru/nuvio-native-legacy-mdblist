#include "discover.h"
#include "catalogo.h"
#include "ajustes.h"
#include "descoberta.h"
#include "menu.h"
#include "gfx.h"
#include "text.h"
#include "tex_cache.h"
#include "ponteiro.h"
#include "focoprof.h"
#include "idioma.h"
#include <stdio.h>
#include <string.h>

/* Keep indices only, never a second copy of the catalogue/artwork. Rebuild
   once per catalogue revision or filter change. Genre names are taken from
   the selected provider/type's actual metadata, not shared TMDB numeric IDs. */
#define DC_GENRES 64
static int type, catalogue, genre, control, posters, selected, drop = -1, cursor;
static int rows[CAT_FIL_MAX], rowCount, items[CAT_MAX], count;
static char genres[DC_GENRES][80], key[192], selectedId[64];
static int genreCount, exitRequested, openRequested = -1;
static unsigned revision;
static const char *media(void) { return type ? "series" : "movie"; }
static void remember(void) {
  const CatItem *it = count ? cat_item(items[selected]) : NULL;
  snprintf(selectedId,sizeof selectedId,"%s",it ? it->imdb : "");
}
static int hasGenre(const char *list, const char *wanted) {
  /* Metadata joins exact names with U+00B7; substring matching would confuse
     e.g. Action with Action & Adventure. */
  const char *p=list;
  while (*p) {
    const char *end=strstr(p," · ");
    size_t n=end ? (size_t)(end-p) : strlen(p);
    if (strlen(wanted)==n && !strncmp(p,wanted,n)) return 1;
    if (!end) break;
    p=end+4;
  }
  return 0;
}
static void collectGenres(const CatItem *it) {
  const char *p=it->genero;
  while (*p && genreCount<DC_GENRES) {
    const char *end=strstr(p," · ");
    size_t n=end ? (size_t)(end-p) : strlen(p);
    char name[80]; int found=0;
    if (n && n<sizeof name) {
      memcpy(name,p,n);name[n]=0;
      /* The metadata prefix describes media, not a genre. */
      if (strcmp(name,"Filme") && strcmp(name,"Série") && strcmp(name,"Programa de TV") &&
          strcmp(name,"Movie") && strcmp(name,"Series")) {
        for (int i=1;i<genreCount;i++) if (!strcmp(genres[i],name)) found=1;
        if (!found) snprintf(genres[genreCount++],sizeof genres[0],"%s",name);
      }
    }
    if (!end) break;
    p=end+4;
  }
}
static void rebuild(int keep) {
  char oldGenre[80]; snprintf(oldGenre,sizeof oldGenre,"%s",genres[genre]);
  rowCount=0; int retained=-1;
  for (int r=0;r<cat_n_fileiras() && rowCount<CAT_FIL_MAX;r++) {
    const CatFileira *f=cat_fileira(r);
    if (!f || strcmp(f->tipo,media()) || !f->catId[0] || !f->base[0]) continue;
    if (!strcmp(f->chave,key)) retained=rowCount;
    rows[rowCount++]=r;
  }
  catalogue=retained>=0 ? retained : 0;
  const CatFileira *f=rowCount ? cat_fileira(rows[catalogue]) : NULL;
  snprintf(key,sizeof key,"%s",f ? f->chave : "");
  genreCount=1;snprintf(genres[0],sizeof genres[0],"All");
  if (f) for (int i=0;i<f->n;i++) {
    const CatItem *it=cat_item(f->ini+i);
    if (it && !strcmp(it->tipo,media())) collectGenres(it);
  }
  genre=0;
  if (keep) for (int g=1;g<genreCount;g++) if (!strcmp(oldGenre,genres[g])) genre=g;
  count=0; selected=0;
  if (f) for (int i=0;i<f->n && count<CAT_MAX;i++) {
    const CatItem *it=cat_item(f->ini+i);
    if (!it || strcmp(it->tipo,media()) || (genre && !hasGenre(it->genero,genres[genre]))) continue;
    int duplicate=0;
    for (int j=0;j<count;j++) {
      const CatItem *prev=cat_item(items[j]);
      if (it->imdb[0] && prev && !strcmp(prev->imdb,it->imdb)) { duplicate=1;break; }
    }
    if (duplicate) continue;
    if (keep && !strcmp(it->imdb,selectedId)) selected=count;
    items[count++]=f->ini+i;
  }
  remember();revision=cat_revisao();
  /* A refresh can remove catalogue/dropdown items while it is open. */
  int max=drop==0 ? 2 : drop==1 ? rowCount : genreCount;
  if (cursor>=max) cursor=max>0 ? max-1 : 0;
}
void discover_esquecer(void) {
  type=catalogue=genre=control=posters=selected=count=rowCount=0;
  key[0]=selectedId[0]=0;genreCount=1;snprintf(genres[0],sizeof genres[0],"All");
  drop=-1;revision=0;exitRequested=0;openRequested=-1;
}
void discover_iniciar(void) { exitRequested=0;openRequested=-1;drop=-1;rebuild(1); }
void discover_atualizar(float dt, Uint32 agora) {
  (void)dt;(void)agora;
  if (revision!=cat_revisao()) rebuild(1);
}
int discover_quer_sair(void) { int v=exitRequested;exitRequested=0;return v; }
int discover_pediu_abrir(int *indice) {
  int v=openRequested;openRequested=-1;
  if(v<0)return 0;
  if(indice)*indice=v;
  return 1;
}
static int choices(void) { return drop==0 ? 2 : drop==1 ? rowCount : genreCount; }
static void choose(void) {
  if (drop==0) { type=cursor;key[0]=0;selectedId[0]=0;genre=0;rebuild(0); }
  else if(drop==1 && rowCount) {
    catalogue=cursor;const CatFileira *f=cat_fileira(rows[catalogue]);
    snprintf(key,sizeof key,"%s",f ? f->chave : "");selectedId[0]=0;rebuild(0);
  } else if(drop==2) {
    genre=cursor;selectedId[0]=0;rebuild(1);
  }
  drop=-1;
}
void discover_evento(const SDL_Event *e) {
  if(e->type!=SDL_KEYDOWN || e->key.repeat)return;
  SDL_Keycode k=e->key.keysym.sym;
  if (k==SDLK_ESCAPE || k==SDLK_BACKSPACE || k==SDLK_AC_BACK) {
    if(drop>=0)drop=-1;else exitRequested=1;return;
  }
  if(drop>=0) {
    if(k==SDLK_UP && cursor>0)cursor--;
    else if(k==SDLK_DOWN && cursor+1<choices())cursor++;
    else if(k==SDLK_RETURN || k==SDLK_KP_ENTER)choose();
    return;
  }
  if(k==SDLK_UP)posters=0;
  else if(k==SDLK_DOWN && count)posters=1;
  else if(k==SDLK_LEFT) {
    if(posters && selected>0){selected--;remember();}
    else if(!posters && control>0)control--;
    else menu_abrir();
  } else if(k==SDLK_RIGHT) {
    if(posters && selected+1<count){selected++;remember();}
    else if(!posters && control<2)control++;
  } else if(k==SDLK_RETURN || k==SDLK_KP_ENTER) {
    if(posters) {if(count)openRequested=items[selected];}
    else { drop=control;cursor=control==0 ? type : control==1 ? catalogue : genre; }
  }
}
static void focus(int a,int b) {
  if(drop>=0){if(a==2 && b>=0 && b<choices())cursor=b;return;}
  if(a==0){posters=0;control=b;}
  else if(a==1 && b>=0 && b<count){posters=1;selected=b;remember();}
}
static void label(const char *s,float x,float y,float width,TxtEstilo style,int active) {
  float r=1,g=1,b=1;if(active)ajustes_acento(&r,&g,&b);
  txt_desenhar(txt_linha_corta(style,s,(int)(255*r),(int)(255*g),(int)(255*b),255,width),x,y);
}
static void image(const char *url,GfxRect rect,int mode) {
  if(!url[0])return;
  GLuint texture=mode==GFX_HERO_CHEIO ? tex_obter_hero(url) : tex_obter_larg(url,rect.w);
  if(texture){gfx_tex_aspect_atual=tex_aspecto(url);gfx_rect(rect,texture,mode,0,0,0,.035f,1,1,1,1);gfx_tex_aspect_atual=0;}
}
void discover_desenhar(Uint32 agora) {
  (void)agora;
  float x=ajustes_conteudo_x();
  const CatItem *it=count ? cat_item(items[selected]) : NULL;
  gfx_cor((GfxRect){0,0,1920,1080},0,.015f,.015f,.02f,1);
  if(it) {
    image(it->backdrop,(GfxRect){0,0,1920,700},GFX_HERO_CHEIO);
    if(it->logo[0])image(it->logo,(GfxRect){x,170,530,180},GFX_ARTE);
    else label(it->titulo,x,220,750,TXT_TITULO1,0);
    for(int i=0;i<it->nElenco && i<3;i++) {
      float cx=x+i*235;
      image(it->elenco[i].foto,(GfxRect){cx,390,42,42},GFX_AVATAR);
      label(it->elenco[i].nome,cx+52,400,175,TXT_CAPTION,0);
    }
    char meta[320];snprintf(meta,sizeof meta,"%s · %s%s%s",it->genero,it->meta,it->classificacao[0] ? " · " : "",it->classificacao);
    label(meta,x,455,840,TXT_CAPTION,0);
    txt_bloco_corta(TXT_BODY,it->sinopse,220,220,220,x,505,780,1.2f,1,3);
  }
  if(!menu_pilula_titulo())label("Discover",x,65,500,TXT_TITULO2,0);
  const CatFileira *f=rowCount ? cat_fileira(rows[catalogue]) : NULL;
  const char *values[]={type ? "Series" : "Movies",f ? f->titulo : "No catalogues",genres[genre]};
  const char *titles[]={"Media type","Catalogue","Genre"};
  for(int i=0;i<3;i++) {
    GfxRect r={x+i*400,710,380,74};
    gfx_cor(r,.14f,.09f,.09f,.11f,1);
    if(!posters && control==i)foco_anel(r,.14f,1,1);
    label(titles[i],r.x+16,r.y+8,348,TXT_CAPTION2,0);
    label(values[i],r.x+16,r.y+34,348,TXT_BODY,!posters && control==i);
    ponteiro_alvo(r.x,r.y,r.w,r.h,focus,NULL,0,i);
  }
  /* Loaded-snapshot limitation is visible. No unsupported remote filter API. */
  label("Available catalogue snapshots · genres filter loaded titles",x,1040,1300,TXT_CAPTION2,0);
  int start=selected>3 ? selected-3 : 0;
  for(int i=start;i<count && i<start+7;i++) {
    const CatItem *card=cat_item(items[i]);if(!card)continue;
    GfxRect r={x+(i-start)*252,816,236,156};
    if(posters && selected==i){r=foco_zoom(r,1);foco_anel(r,.035f,1,1);}
    image(card->backdrop[0] ? card->backdrop : card->poster,r,GFX_ARTE);
    label(card->titulo,r.x,r.y+r.h+12,r.w,TXT_CAPTION,posters && selected==i);
    if(card->nota) {char rating[24];snprintf(rating,sizeof rating,"%.1f",card->nota/10.0);label(rating,r.x+175,r.y+122,52,TXT_CAPTION2,0);}
    ponteiro_alvo(r.x,r.y,r.w,r.h+42,focus,NULL,1,i);
  }
  if(!count)label(desc_montando() ? "Loading catalogues…" : "No loaded titles match these filters",x,870,1300,TXT_BODY,0);
  if(drop>=0) {
    ponteiro_camada();
    gfx_cor((GfxRect){0,0,1920,1080},0,0,0,0,.45f);
    int first=cursor>3 ? cursor-3 : 0;
    int n=choices()-first;if(n>6)n=6;if(n<1)n=1;
    GfxRect panel={x+control*400,795,380,n*42.0f+12};
    gfx_cor(panel,.04f,.10f,.08f,.12f,1);
    for(int j=first;j<choices() && j<first+6;j++) {
      const CatFileira *row=drop==1 ? cat_fileira(rows[j]) : NULL;
      const char *value=drop==0 ? (j ? "Series" : "Movies") : drop==1 ? (row ? row->titulo : "") : genres[j];
      GfxRect r={panel.x+6,panel.y+6+(j-first)*42,368,42};
      if(j==cursor)foco_anel(r,.05f,1,1);
      label(value,r.x+12,r.y+8,344,TXT_CAPTION,j==cursor);
      ponteiro_alvo(r.x,r.y,r.w,r.h,focus,NULL,2,j);
    }
  }
}
