#ifndef NV_VIEWGEOMETRY_H
#define NV_VIEWGEOMETRY_H
/* 248px cards + 16px spacing; 24px gap plus 12px focus overhang. */
static inline int vt_grid_columns(float left, float panel) {
  int n=(int)((panel-left-36.0f+16.0f)/264.0f);
  return n<1 ? 1 : n>5 ? 5 : n;
}
#endif
