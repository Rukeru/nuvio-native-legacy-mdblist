#include "mdbaccount.h"
#include "mdbformat.h"
#include "js.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

static const char *valueEnd(const char *p, const char *end) {
  if (!p || p >= end) return NULL;
  if (*p == '{' || *p == '[') {
    const char *f = js_fim(p);
    return f && f > p && f <= end && f[-1] == (*p == '{' ? '}' : ']') ? f : NULL;
  }
  if (*p == '"') for (const char *q = p + 1; q < end && *q; q++) {
    if (*q == '"') return q + 1;
    if (*q == '\\') { if (++q >= end || !*q) return NULL; }
  }
  return NULL;
}

/* Complete object or serialized object. The output fits the entire raw input,
   preventing js_cadeia's bounded decoder from truncating a credential. */
static char *objectCopy(const char *p, const char *end) {
  const char *f = valueEnd(p, end);
  if (!f || (size_t)(f - p) > 2u * 1024u * 1024u) return NULL;
  size_t n = (size_t)(f - p);
  char *out = malloc(n + 1);
  if (!out) return NULL;
  if (*p == '"') {
    if (!js_cadeia(p, out, n + 1)) { free(out); return NULL; }
  } else { memcpy(out, p, n); out[n] = 0; }
  char *start = out;
  while (isspace((unsigned char)*start)) start++;
  if (start != out) memmove(out, start, strlen(start) + 1);
  f = *out == '{' ? valueEnd(out, out + strlen(out)) : NULL;
  if (!f) { free(out); return NULL; }
  while (isspace((unsigned char)*f)) f++;
  if (*f) { free(out); return NULL; }
  return out;
}

static int keyValue(const char *p, const char *end, char *dst, size_t n) {
  if (!p) return 0;
  if (*p == '{') {
    const char *f = valueEnd(p, end);
    if (!f) return -1;
    p = mdb_prop(p, f, "value"); /* typed profile setting */
    end = f;
  }
  const char *f = valueEnd(p, end);
  if (!p || *p != '"' || !f || (size_t)(f - p) >= 512 || !dst || !n) return -1;
  char decoded[512];
  /* Keys are URL/header-safe ASCII; reject escapes rather than accept a NUL
     prefix, malformed escape or silently truncated secret. */
  for (const char *q = p + 1; q < f - 1; q++) if (*q == '\\') return -1;
  size_t raw = (size_t)(f - p - 2);
  memcpy(decoded, p + 1, raw); decoded[raw] = 0;
  char *start = decoded;
  while (isspace((unsigned char)*start)) start++;
  size_t len = strlen(start);
  while (len && isspace((unsigned char)start[len - 1])) len--;
  if (len >= 80 || len >= n) return -1;
  for (size_t i = 0; i < len; i++)
    if (!((start[i] >= 'a' && start[i] <= 'z') ||
          (start[i] >= 'A' && start[i] <= 'Z') ||
          (start[i] >= '0' && start[i] <= '9') || start[i] == '-' || start[i] == '_')) return -1;
  memcpy(dst, start, len); dst[len] = 0;
  return 1;
}

int mdb_account_credential(const char *row, const char *end, char *dst, size_t n) {
  if (!row || !end || !valueEnd(row, end)) return -1;
  char provider[48];
  if (!js_texto_raiz_em(row, end, "provider", provider, sizeof provider)) return 0;
  char *start = provider;
  while (isspace((unsigned char)*start)) start++;
  size_t len = strlen(start);
  while (len && isspace((unsigned char)start[len - 1])) start[--len] = 0;
  for (size_t i = 0; i < len; i++) start[i] = (char)tolower((unsigned char)start[i]);
  if (strcmp(start, "mdblist")) return 0;
  const char *p = mdb_prop(row, end, "credential_json");
  if (!p) p = mdb_prop(row, end, "credentialJson");
  char *object = objectCopy(p, end);
  if (!object) return -1;
  int result = keyValue(mdb_prop(object, object + strlen(object), "api_key"),
                        object + strlen(object), dst, n);
  free(object);
  return result ? result : -1;
}

int mdb_account_settings(const char *settings, char *dst, size_t n) {
  if (!settings) return 0;
  char *object = objectCopy(settings, settings + strlen(settings));
  if (!object) return -1;
  const char *end = object + strlen(object), *scope = object;
  const char *features = mdb_prop(object, end, "features");
  if (features) {
    const char *f = valueEnd(features, end);
    scope = f && *features == '{' ? mdb_prop(features, f, "mdblist_settings") : NULL;
    if (!scope) { free(object); return 0; }
  } else {
    const char *feature = mdb_prop(object, end, "mdblist_settings");
    if (feature) scope = feature;
  }
  char *feature = objectCopy(scope, end);
  if (!feature) { free(object); return -1; }
  const char *fend = feature + strlen(feature);
  int result = keyValue(mdb_prop(feature, fend, "mdblist_api_key"), fend, dst, n);
  free(feature); free(object);
  return result;
}

int mdb_account_profile_reply(const char *reply, char *dst, size_t n) {
  if (!reply) return 0;
  while (isspace((unsigned char)*reply)) reply++;
  const char *finish = *reply == '[' ? valueEnd(reply, reply + strlen(reply)) : NULL;
  if (!finish) return -1;
  while (isspace((unsigned char)*finish)) finish++;
  if (*finish) return -1;
  const char *row = js_raiz_array(reply), *end = row ? js_fim(row) : NULL;
  if (!row || !end || !valueEnd(row, end)) return 0;
  const char *settings = mdb_prop(row, end, "settings_json");
  return settings ? mdb_account_settings(settings, dst, n) : 0;
}
