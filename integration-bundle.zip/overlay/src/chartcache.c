#include "chartcache.h"
#include "ajustes.h"
#include "text.h"
#include <stdio.h>
#include <math.h>
/* Visible panel targets together may use at most 6 MiB. Failure is a direct
   rendering fallback, never a missing chart. No image-cache eviction. */
static size_t allocated;
#define CHART_BUDGET (6u * 1024u * 1024u)
void chartcache_clear(ChartCache *c) {
  allocated -= (size_t)c->target.w * (size_t)c->target.h * 4u;
  gfx_mini_liberar(&c->target); c->valid=0;
}
int chartcache_draw(ChartCache *c, GfxRect r, uint64_t revision, ChartPaint paint, const void *data, float alpha) {
  int w=(int)ceilf(r.w), h=(int)ceilf(r.h);
  size_t bytes;
  if (!gfx_mini_disponivel() || w<1 || h<1 || w>2048 || h>1080) return 0;
  bytes=(size_t)w*(size_t)h*4u;
  uint64_t key=revision ^ ((uint64_t)(unsigned)ajustes_idioma()<<48) ^ ((uint64_t)(unsigned)txt_fonte_interface()<<56);
  if (c->target.w!=w || c->target.h!=h) {
    chartcache_clear(c);
    if (bytes>CHART_BUDGET-allocated || !gfx_mini_alvo(&c->target,w,h)) return 0;
    allocated+=bytes;
  }
  if (!c->valid || c->key!=key) {
    int pending=txt_pendentes, draws=gfx_n_rect, binds=gfx_n_bind;
    Uint64 start=SDL_GetPerformanceCounter();
    float opacity=gfx_opacidade_grupo;
    gfx_opacidade_grupo=1;
    gfx_mini_comecar(&c->target,0,0,1);
    paint((GfxRect){0,0,r.w,r.h},data);
    gfx_mini_terminar();
    gfx_opacidade_grupo=opacity;
    c->valid=txt_pendentes==pending; c->key=key; c->builds++;
    if (ajustes_medidor_desempenho())
      printf("[season-charts] bake=%u draws=%d binds=%d cpu_ms=%.3f memory_bytes=%zu\n",c->builds,gfx_n_rect-draws,gfx_n_bind-binds,1000.0*(double)(SDL_GetPerformanceCounter()-start)/(double)SDL_GetPerformanceFrequency(),allocated);
  } else c->hits++;
  gfx_mini_desenhar(&c->target,r,0,alpha);
  return 1;
}
