#ifndef NV_CHARTCACHE_H
#define NV_CHARTCACHE_H
#include "gfx.h"
#include <stdint.h>
typedef struct { GfxMini target; uint64_t key; int valid; unsigned hits, builds; } ChartCache;
typedef void (*ChartPaint)(GfxRect r, const void *data);
/* Render-thread only. Static content only: backgrounds and focus stay live. */
int chartcache_draw(ChartCache *c, GfxRect r, uint64_t revision, ChartPaint paint, const void *data, float alpha);
void chartcache_clear(ChartCache *c);
#endif
