#ifndef NV_MDBACCOUNT_H
#define NV_MDBACCOUNT_H
#include <stddef.h>
/* 1: valid, including explicit empty/removal; 0: absent; -1: malformed.
   Failures preserve dst. No network, persistence or secret logging. */
int mdb_account_credential(const char *row, const char *end, char *dst, size_t n);
int mdb_account_settings(const char *settings, char *dst, size_t n);
int mdb_account_profile_reply(const char *reply, char *dst, size_t n);
#endif
