#ifndef NV_MDBCREDENTIALS_H
#define NV_MDBCREDENTIALS_H
void mdb_credentials_scope(void); /* main thread before playback dispatch */
int mdb_credentials_manual(const char *key); /* masked UI; blank disconnects */
void mdb_credentials_import(const char *key); /* main-thread guarded cloud reply */
void mdb_credentials_push(void); /* existing account-sync worker only */
void mdb_credentials_forget(void);
const char *mdb_credentials_status(void);
#endif
