#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
flags=(-std=gnu11 -O1 -UNDEBUG -g -Wall -Wextra -Isrc -DSDL_MAIN_HANDLED)
read -ra sdl <<< "$(sdl2-config --cflags)"
cc "${flags[@]}" "${sdl[@]}" tests/mdbchangelog.c -lm -o "$out/changelog"
"$out/changelog"
cc "${flags[@]}" tests/mdbformat.c src/mdbformat.c src/js.c -lm -o "$out/format"
cc "${flags[@]}" tests/mdbwatched.c src/mdbwatched.c src/mdbformat.c src/js.c -lm -o "$out/history-format"
"$out/history-format"
cc "${flags[@]}" tests/history_sync.c src/contalib.c src/vistoep.c src/js.c -pthread -lm -o "$out/history-sync"
"$out/history-sync"
bash tests/contalib.sh
bash tests/contapend.sh
CPATH="$(sdl2-config --prefix)/include:${CPATH:-}" bash tests/visto.sh
"$out/format"
cc "${flags[@]}" tests/mdbaccount.c src/mdbaccount.c src/mdbformat.c src/js.c -lm -o "$out/account"
"$out/account"
cc "${flags[@]}" "${sdl[@]}" -Itests/stubs/mdblist tests/mdbcredentials.c -o "$out/credentials"
"$out/credentials"
cc "${flags[@]}" tests/episodeindex.c src/episodeindex.c -o "$out/episode-index"
"$out/episode-index"
cc "${flags[@]}" "${sdl[@]}" tests/progress_perf.c src/chartcache.c src/js.c -pthread -lm -o "$out/progress"
"$out/progress"
cc "${flags[@]}" tests/vistoep.c src/vistoep.c src/js.c -pthread -lm -o "$out/watched"
"$out/watched"
cc "${flags[@]}" tests/vistoep_threads.c src/vistoep.c src/js.c -pthread -lm -o "$out/watched-threads"
"$out/watched-threads"
python3 tests/ajustes_secoes.py src/ajustes.c
python3 tools/idiomas.py
cc "${flags[@]}" tests/mdbresume.c src/mdbresume.c -lm -o "$out/resume"
"$out/resume"
cc "${flags[@]}" "${sdl[@]}" -Itests/stubs/mdblist tests/mdblistlibrary.c src/mdbwatched.c src/mdbformat.c src/mdbresume.c src/mdblistscrobble.c src/js.c -lm -o "$out/library"
"$out/library"
cc "${flags[@]}" "${sdl[@]}" tests/chartcache.c src/chartcache.c -lm -o "$out/charts"
"$out/charts"
cc "${flags[@]}" "${sdl[@]}" -ffunction-sections -fdata-sections tests/source_cache.c src/stream_parse.c src/js.c src/badges.c -Wl,--gc-sections -lm -o "$out/cache"
"$out/cache"
# Existing parser and quality/codec filtering regressions use the real badges.
CPATH="$(sdl2-config --prefix)/include:${CPATH:-}" bash tests/stream_parser.sh
CPATH="$(sdl2-config --prefix)/include:${CPATH:-}" bash tests/streamfit_parser.sh
