#include "mdbwatched.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void) {
 ContaVisto rows[8];char cursor[1024];int more;
 const char *documented="{\"movies\":[{\"last_watched_at\":\"2026-10-08T12:00:00Z\",\"movie\":{\"ids\":{\"imdb\":\"tt0372784\"}}}],\"shows\":[{\"last_watched_at\":\"2026-10-08T12:00:00Z\",\"show\":{\"ids\":{\"imdb\":\"tt5875444\"}}}],\"episodes\":[{\"last_watched_at\":\"2026-10-08T12:00:00Z\",\"episode\":{\"season\":1,\"number\":1,\"ids\":{\"imdb\":\"tt99999\"},\"show\":{\"title\":\"Slow Horses\",\"ids\":{\"imdb\":\"tt5875444\"}}}}],\"pagination\":{\"has_more\":true}}";
 assert(mdb_watched_page(documented,rows,8,cursor,sizeof cursor,&more)==2&&more&&!cursor[0]);
 assert(!strcmp(rows[0].id,"tt0372784")&&!strcmp(rows[0].tipo,"movie")&&!rows[0].episodio);
 assert(!strcmp(rows[1].id,"tt5875444")&&rows[1].temporada==1&&rows[1].episodio==1&&rows[1].vistoMs>0);
 assert(mdb_watched_page("{\"episodes\":[{\"watched_at\":\"2026-10-08T12:00:00Z\",\"episode\":{\"season\":0,\"number\":2},\"show\":{\"ids\":{\"imdb\":\"tt5875444\"}}}],\"pagination\":{\"next_cursor\":\"page2\"}}",rows,8,cursor,sizeof cursor,&more)==1&&more&&!strcmp(cursor,"page2"));
 assert(rows[0].temporada==0&&rows[0].episodio==2);
 assert(mdb_watched_page("{\"shows\":[{\"show\":{\"ids\":{\"imdb\":\"tt5875444\"}},\"seasons\":[{\"number\":2,\"episodes\":[{\"number\":1,\"last_watched_at\":\"2026-10-08T12:00:00Z\"},{\"number\":2,\"last_watched_at\":null}]}]}]}",rows,8,cursor,sizeof cursor,&more)==1);
 assert(rows[0].temporada==2&&rows[0].episodio==1);
 assert(mdb_watched_page("{\"movies\":[{\"watched_at\":null,\"movie\":{\"ids\":{\"imdb\":\"tt1\"}}},{\"watched_at\":\"2026-10-08T12:00:00Z\",\"movie\":{\"ids\":{\"tmdb\":1}}}]}",rows,8,cursor,sizeof cursor,&more)==0); /* never alias all TMDB IDs to 'tmdb' */
 assert(mdb_watched_page(documented,rows,1,cursor,sizeof cursor,&more)<0);
 const char *bad[]={"{\"error\":\"unauthorized\"}","{\"movies\":{}}","{\"movies\":[123]}","{\"episodes\":[{\"watched_at\":\"2026-10-08T12:00:00Z\",\"episode\":{\"season\":1,\"number\":1.5,\"show\":{\"ids\":{\"imdb\":\"tt1\"}}}}]}","{\"movies\":[]", "{\"movies\":[],\"pagination\":{\"next_cursor\":123}}"};
 for(unsigned i=0;i<sizeof bad/sizeof *bad;i++)assert(mdb_watched_page(bad[i],rows,8,cursor,sizeof cursor,&more)<0);
 assert(mdb_watched_page("{\"movies\":[],\"pagination\":{\"total\":2001,\"limit\":1000,\"offset\":1000}}",rows,8,cursor,sizeof cursor,&more)==0&&more);
 assert(mdb_watched_page("{\"movies\":[],\"pagination\":{\"next_cursor\":\"1234567\"}}",rows,8,cursor,4,&more)<0);
 puts("Watched history: documented and modern envelopes, Slow Horses episodes, nested seasons, nulls, paging, bounds and identity passed");
}
