# Sourced only by real native renderer fixtures. Keep production GLES on Linux
# and original OpenGL on Darwin; run the same C assertions on both hosts.
host_flags=(-I/opt/homebrew/include -I/opt/homebrew/include/SDL2)
host_libs=(-L/opt/homebrew/lib -lSDL2 -lSDL2_image -lSDL2_ttf -lz -framework OpenGL)
run=()
if [ "$(uname -s)" = Linux ]; then
  host_flags=(-DNV_LINUX_DESKTOP)
  read -ra includes <<< "$(pkg-config --cflags sdl2 SDL2_image SDL2_ttf zlib glesv2 egl)"
  read -ra host_libs <<< "$(pkg-config --libs sdl2 SDL2_image SDL2_ttf zlib glesv2 egl)"
  host_flags+=("${includes[@]}")
  host_libs+=(-pthread -ldl -lm)
  run=(xvfb-run -a)
fi
