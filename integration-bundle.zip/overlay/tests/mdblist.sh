#!/bin/bash
set -eu
cd "$(dirname "$0")/.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
cc -std=c11 -Wall -Wextra -Werror -Isrc -Itests/stubs/mdblist \
  tests/mdblist.c src/mdblistscrobble.c src/traktscrobble.c -lm -o "$out/mdblist"
"$out/mdblist"
