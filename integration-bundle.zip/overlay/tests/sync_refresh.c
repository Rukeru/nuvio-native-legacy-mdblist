/* Reuse upstream's real sync worker harness without editing its scenarios or
 * assertions. Override only remote/account adapters for additional cases. */
#define main upstream_syncaddons_main
#define sessao_rpc original_rpc
#define perfis_ativo original_profile
#define perfis_ativo_addons original_addon_profile
#define sessao_usuario original_user
#define nuvem_freio_ativo original_brake
#define desc_repetir_addons original_rebuild
#define col_definir_json original_col_apply
#define ajustes_aplicar_blob original_settings_apply
#define ajustes_mesclar_blob original_settings_merge
#include "syncaddons.c"
#undef main
#undef sessao_rpc
#undef perfis_ativo
#undef perfis_ativo_addons
#undef sessao_usuario
#undef nuvem_freio_ativo
#undef desc_repetir_addons
#undef col_definir_json
#undef ajustes_aplicar_blob
#undef ajustes_mesclar_blob
#include <assert.h>
#include <time.h>
static int profile=1,brake,fail_col,rebuilt,invalidated,applied,settings_applied,settings_push;
static unsigned clock_ms=1000;
static const char *owner="conta-a";
static int remote_revision=1;
static volatile int block_rpc,entered;
int refresh_clock_gettime(clockid_t id,struct timespec *t) {
  (void)id;t->tv_sec=clock_ms/1000;t->tv_nsec=(clock_ms%1000)*1000000;return 0;
}
int perfis_ativo(void){return profile;}
int perfis_ativo_addons(void){return profile;}
const char *sessao_usuario(void){return owner;}
int nuvem_freio_ativo(void){return brake;}
void desc_repetir_addons(void){rebuilt++;}
void desc_manifesto_cache_invalidar(void){invalidated++;}
int col_definir_json(const char *s){applied=atoi(s+1);return 1;}
/* colfileiras_receber in the included harness resolves to original_col_apply;
 * it remains an inert adapter. A separate real Collections fixture covers the
 * snapshot/schema/UI revision; this fixture verifies the sync result itself. */
int ajustes_aplicar_blob(const char *s){(void)s;settings_applied++;return 1;}
int ajustes_mesclar_blob(const char *s,char **out){(void)s;*out=strdup("{\"local\":true}");return 1;}
char *sessao_rpc(const char *fn,const char *body,int *st){
 if(!strcmp(fn,"sync_pull_collections")) {
   __atomic_store_n(&entered,1,__ATOMIC_RELEASE);
   while(__atomic_load_n(&block_rpc,__ATOMIC_ACQUIRE))usleep(1000);
   *st=fail_col?503:200;
   char s[32];snprintf(s,sizeof s,"[%d]",remote_revision);
   return strdup(fail_col?"{}":s);
 }
 if(!strcmp(fn,"sync_pull_profile_settings_blob")){*st=200;return strdup("[{\"settings_json\":{\"remote\":true}}]");}
 if(!strcmp(fn,"sync_push_profile_settings_blob")){settings_push++;*st=503;return strdup("{}");}
 return original_rpc(fn,body,st);
}
static SyncFreshStatus status(void){SyncFreshStatus s;sync_fresh_status(&s);return s;}
static void wait_entered(void){for(int i=0;i<4000&&!__atomic_load_n(&entered,__ATOMIC_ACQUIRE);i++)usleep(1000);assert(entered);}
int main(void){
 snprintf(conta,sizeof conta,"AB");contaGravar();
 assert(sync_periodico(1000)==0); /* No unsolicited pre-login/startup retry. */
 brake=1;sync_iniciar();assert(status().state==5);
 brake=0;assert(sync_periodico(1001)==0);
 clock_ms+=SYNC_RETENTA_MS;
 assert(sync_periodico(1002)==1);ateTerminar();assert(status().state==2);
 assert(status().last_success>0);
 int before=rebuilt;
 assert(sync_now(70000)==1);assert(sync_now(70001)==0);
 ateTerminar();assert(status().state==2);assert(invalidated==1&&rebuilt>before);
 assert(sync_now(70002)==-2);assert(status().state==5);
 long success=status().last_success;
 fail_col=1;assert(sync_now(140000)==1);ateTerminar();
 assert(status().state==3&&status().cached&&status().last_success==success);
 assert(strstr(sync_fresh_text(),"cached account"));
 fail_col=0;remote_revision=2;
 sync_proteger_ajustes_locais();int local=settings_applied;
 assert(sync_now(210000)==1);ateTerminar();
 assert(settings_push>0&&settings_applied==local&&status().pending);
 assert(dados_ler("ajustes-locais.txt")!=NULL);
 entered=0;block_rpc=1;assert(sync_now(280000)==1);wait_entered();
 profile=2;assert(status().last_success==0);
 __atomic_store_n(&block_rpc,0,__ATOMIC_RELEASE);ateTerminar();ateTerminar();
 assert(status().profile==2);
 profile=3;assert(status().last_success==0);
 owner="conta-b";profile=1;assert(status().last_success==0);
 puts("Sync refresh: initial retry, cooldown, fresh/cache distinction, pending writes and profile isolation passed");
 return 0;
}
