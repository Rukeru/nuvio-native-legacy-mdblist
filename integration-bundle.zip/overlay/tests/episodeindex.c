#include "episodeindex.h"
#include "viewgeometry.h"
#include <assert.h>
#include <stdio.h>
#include <time.h>
static int calls,seasons[1200];
static int readSeason(void *u,int i){(void)u;calls++;return seasons[i];}
static int oldLookup(int column,int season,int n){int q=0;for(int i=0;i<n;i++)if(readSeason(NULL,i)==season&&q++==column)return i;return -1;}
static void benchmark(int n,int last,int season){
 EpisodeIndex v={0};volatile int result=0;calls=0;clock_t begin=clock();
 for(int frame=0;frame<1000;frame++)for(int c=0;c<12;c++)result+=oldLookup(c,season,n);
 double before=1000.0*(clock()-begin)/CLOCKS_PER_SEC;int scans=calls;calls=0;begin=clock();
 for(int frame=0;frame<1000;frame++) {episode_index_prepare(&v,1,1,n,season,readSeason,NULL);for(int c=0;c<12;c++)result+=v.indices[c];}
 double after=1000.0*(clock()-begin)/CLOCKS_PER_SEC;
 assert(calls==n&&v.count==last);assert(result);
 printf("episode-index catalogue=%d season=%d frames=1000 before_reads=%d after_reads=%d before_cpu_ms=%.3f after_cpu_ms=%.3f memory_bytes=%zu\n",n,season,scans,calls,before,after,sizeof v);
}
int main(void){
 for(int i=0;i<1200;i++)seasons[i]=i/24+1;
 benchmark(72,24,3);benchmark(888,24,37);benchmark(1200,24,50);
 EpisodeIndex v={0};episode_index_prepare(&v,1,1,888,37,readSeason,NULL);assert(v.indices[0]==864&&v.indices[23]==887);
 seasons[887]=38;episode_index_prepare(&v,1,2,888,37,readSeason,NULL);assert(v.count==23);
 episode_index_prepare(&v,1,2,888,-1,readSeason,NULL);assert(v.count==888&&v.indices[887]==887);
 episode_index_prepare(&v,2,2,0,1,readSeason,NULL);assert(!v.count);
 for(int left=60;left<=380;left+=20){int cols=vt_grid_columns(left,1480);assert(cols>=1&&cols<=5);assert(left+(cols-1)*264+248+8<=1480-24);}
 puts("episode order/revision/season/empty catalogue and Collections focus geometry passed");
}
