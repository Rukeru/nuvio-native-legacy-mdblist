#include "mdbresume.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
int main(void) {
 MdbItem item={.progress=70,.updated=999,.runtime=100};
 assert(mdb_resume_apply(&item,1200,3600,1,90)==1);
 assert(item.progress>33&&item.progress<34&&item.updated==1&&item.runtime==60);
 assert(mdb_resume_apply(&item,3500,3600,1,90)==-1);
 assert(mdb_resume_apply(&item,NAN,3600,1,90)==0);
 assert(mdb_resume_apply(&item,30,0,1,90)==0);
 assert(mdb_resume_apply(&item,0,3600,1,90)==-1);
 item.next=1;assert(mdb_resume_apply(&item,10,3600,1,90)==1&&item.progress==0);
 puts("MDBList resume: older precise local wins, completion veto, missing runtime and Up Next passed");return 0;
}
