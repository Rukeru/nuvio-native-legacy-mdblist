#!/bin/bash
# Run all upstream defaults plus the five original MDBList assertions.
set -euo pipefail
cd "$(dirname "$0")/.."
out=$(mktemp -d "${TMPDIR:-/tmp}/nuvio-mdblist-defaults.XXXXXX")
trap 'rm -rf "$out"' EXIT
sources=()
for source in src/*.c src/dts/*.c; do
  case "$source" in src/main.c|src/ajustes.c) continue;; esac
  sources+=("$source")
done
flags=(-O1 -UNDEBUG -g -Isrc -DSDL_MAIN_HANDLED)
packages=(sdl2 SDL2_image SDL2_ttf zlib)
libraries=(-pthread -lm)
if [ "$(uname -s)" = Linux ]; then
  flags+=(-DNV_LINUX_DESKTOP)
  packages+=(glesv2 egl)
  libraries+=(-ldl)
else
  libraries+=(-framework OpenGL)
fi
read -ra includes <<< "$(pkg-config --cflags "${packages[@]}")"
read -ra links <<< "$(pkg-config --libs "${packages[@]}")"
cc "${flags[@]}" "${includes[@]}" "${sources[@]}" tests/mdblist_settings_defaults.c \
  "${links[@]}" "${libraries[@]}" -o "$out/defaults"
"$out/defaults"
