#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define pthread_mutex_t MdbCredTestMutex
#define pthread_t MdbCredTestThread
#include "pthread.h"
#include "../src/mdbcredentials.c"
static char files[33][200],active[80];
static const char *uid="account_one";static int selected=1,logged=1,writes,pushResult=1,failStorage;
int pthread_mutex_lock(pthread_mutex_t *m){assert(!*m);*m=1;return 0;}
int pthread_mutex_unlock(pthread_mutex_t *m){assert(*m);*m=0;return 0;}
const char *sessao_usuario(void){return uid;}
int sessao_logada(void){return logged;}
int perfis_ativo(void){return selected;}
static int slot(const char *s){int p=-1;assert(sscanf(s,"mdblist-p%d.txt",&p)==1&&p>=0&&p<=32);return p;}
char *dados_ler(const char *name){int i=slot(name);return files[i][0]?strdup(files[i]):NULL;}
int dados_gravar_privado(const char *name,const char *body){if(failStorage)return 0;snprintf(files[slot(name)],200,"%s",body);return 1;}
int dados_apagar(const char *name){files[slot(name)][0]=0;return 1;}
void extras_definir_chave(const char *v){snprintf(active,sizeof active,"%s",v);}
int sync_empurrar_credencial_perfil(const char *provider,const char *body,int target,const char *ownerId){assert(target==selected&&!strcmp(ownerId,uid));assert(!mutex&&!strcmp(provider,"mdblist"));assert(strstr(body,"api_key"));writes++;return pushResult;}
int main(void){
 mdb_credentials_scope();assert(!active[0]);mdb_credentials_import("cloud_key");assert(!strcmp(active,"cloud_key"));
 assert(mdb_credentials_manual("manual_key"));mdb_credentials_import("");assert(!strcmp(active,"manual_key"));
 profile=-1;memset(key,0,sizeof key);mdb_credentials_scope();assert(!strcmp(active,"manual_key")&&pending); /* restart */
 pushResult=0;mdb_credentials_push();assert(pending&&writes==1);pushResult=1;mdb_credentials_push();assert(!pending&&writes==2);
 selected=2;mdb_credentials_scope();assert(!active[0]);mdb_credentials_import("second_key");
 selected=1;mdb_credentials_scope();assert(!strcmp(active,"manual_key"));
 uid="account_two";mdb_credentials_scope();assert(!active[0]); /* same profile number, different owner */
 assert(!mdb_credentials_manual("bad&key"));failStorage=1;assert(!mdb_credentials_manual("valid_key")&&!active[0]);failStorage=0;
 assert(mdb_credentials_manual("valid_key"));assert(mdb_credentials_manual(""));assert(!active[0]&&pending);mdb_credentials_import("stale_key");assert(!active[0]);
 pushResult=-1;mdb_credentials_push();int n=writes;mdb_credentials_push();assert(writes==n&&pending);
 mdb_credentials_forget();assert(!key[0]&&!files[1][0]&&!files[2][0]);
 puts("MDBList manual/cloud persistence, pending edit/removal, restart, account/profile isolation, storage/push failure tests passed");
}
