/* No real credentials, network, UI or threads. The controlled scheduler lets
   rapid episode switches and credential changes be tested deterministically. */
#include <assert.h>
#include <locale.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "pthread.h"

static time_t now = 1000;
static void *(*scheduled)(void *);
static void *scheduled_arg;
static int create_fail, calls, http = 200, switch_key;
static char urls[256][220], bodies[256][340];
static time_t fake_time(time_t *out) { if (out) *out = now; return now; }
#define time fake_time
#include "../src/mdblist.c"
#undef time

int pthread_mutex_lock(pthread_mutex_t *m) { assert(!*m); *m = 1; return 0; }
int pthread_mutex_unlock(pthread_mutex_t *m) { assert(*m); *m = 0; return 0; }
int pthread_create(pthread_t *t, const void *a, void *(*f)(void *), void *arg) {
  (void)a;
  if (create_fail) return 1;
  assert(!scheduled); *t = 1; scheduled = f; scheduled_arg = arg; return 0;
}
int pthread_detach(pthread_t t) { (void)t; return 0; }
static void drain(void) {
  void *(*f)(void *) = scheduled;
  void *arg = scheduled_arg;
  scheduled = NULL;
  if (f) f(arg);
}
char *rede_postar_st(const char *url, int timeout, const char *const *headers,
                    const char *body, int *status) {
  assert(!trava); /* HTTP cannot hold the lock or block the render thread. */
  assert(timeout == 15 && !strcmp(headers[0], "Content-Type: application/json"));
  assert(calls < 256);
  snprintf(urls[calls], sizeof urls[calls], "%s", url);
  snprintf(bodies[calls++], sizeof bodies[0], "%s", body);
  *status = http;
  if (switch_key) { switch_key = 0; mdblist_definir_chave("replacement"); }
  return NULL;
}
static void reset(void) {
  drain(); mdblist_atualizar(0, 0); mdblist_definir_chave("");
  mdblist_limiar(85);
  now = 1000; http = 200; calls = create_fail = switch_key = 0;
}
static void enable(void) { mdblist_definir_chave("test_key-123"); mdblist_atualizar(1, 1); }
static int event(int ev, const char *id, double pct) { return mdblist_scrobble(ev, id, pct * 10, 1000); }

int main(void) {
  char b[320], tiny[4];
  MdbScrobbleEstado s = { "", 0 };
  const char *ep = "tt0944947:5:3";
  assert(mdblist_corpo(b, sizeof b, "tt0111161", 15.5));
  assert(!strcmp(b, "{\"movie\":{\"ids\":{\"imdb\":\"tt0111161\"}},\"progress\":15.50}"));
  assert(mdblist_corpo(b, sizeof b, ep, 42.75));
  assert(!strcmp(b, "{\"show\":{\"ids\":{\"imdb\":\"tt0944947\"},\"season\":5,\"episode\":3},\"progress\":42.75}"));
  assert(mdblist_corpo(b, sizeof b, "tt123:0:2", -5) && strstr(b, "\"season\":0") && strstr(b, "0.00"));
  assert(mdblist_corpo(b, sizeof b, "tt123", 200) && strstr(b, "100.00"));
  assert(mdblist_corpo(b, sizeof b, "tt123", 79.999) && strstr(b, "79.99"));
  assert(mdblist_corpo(b, sizeof b, "tmdb:m278", 15.5));
  assert(!strcmp(b, "{\"movie\":{\"ids\":{\"tmdb\":278}},\"progress\":15.50}"));
  assert(mdblist_corpo(b, sizeof b, "tmdb:t1396:1:2", 10));
  assert(!strcmp(b, "{\"show\":{\"ids\":{\"tmdb\":1396},\"season\":1,\"episode\":2},\"progress\":10.00}"));
  assert(mdblist_corpo(b,sizeof b,"tvdb:t71663:1:2",10)&&strstr(b,"\"tvdb\":71663"));
  assert(!mdblist_corpo(b,sizeof b,"tvdb:t71663",10));
  assert(!mdblist_corpo(b, sizeof b, "tmdb:t1396", 10));
  assert(!mdblist_corpo(b, sizeof b, "tmdb:m278:1:2", 10));
  assert(!mdblist_corpo(b, sizeof b, "tmdb:m0", 10));
  assert(!mdblist_corpo(b, sizeof b, "tmdb:m01", 10));
  assert(!mdblist_corpo(tiny, sizeof tiny, ep, 20) && !tiny[0]);
  { const char *bad[] = { "", "tt", "tt1:1", "tt1:1:0", "tt1:-1:2", "tt1:1:2:3", "tt1:999999999999:1", "tt1\"", "jellyfin:abc", "tmdb:123", NULL };
    int i; for (i = 0; bad[i]; i++) assert(!mdblist_corpo(b, sizeof b, bad[i], 10)); }
  assert(!mdblist_corpo(b, sizeof b, NULL, 10));
  assert(!mdblist_corpo(b, sizeof b, ep, NAN));
  assert(!mdblist_corpo(b, sizeof b, ep, INFINITY));
  setlocale(LC_NUMERIC, "Portuguese");
  assert(mdblist_corpo(b, sizeof b, ep, 42.75) && strstr(b, "42.75"));
  setlocale(LC_NUMERIC, "C");
  assert(mdblist_decidir(&s, SCR_EV_PAUSOU, ep) == SCR_NADA);
  assert(mdblist_decidir(&s, SCR_EV_TOCANDO, ep) == SCR_START);
  assert(mdblist_decidir(&s, SCR_EV_TOCANDO, ep) == SCR_NADA);
  assert(mdblist_decidir(&s, SCR_EV_PAUSOU, ep) == SCR_PAUSE);
  assert(mdblist_decidir(&s, SCR_EV_PAUSOU, ep) == SCR_NADA);
  assert(mdblist_decidir(&s, SCR_EV_TOCANDO, ep) == SCR_START);
  assert(mdblist_decidir(&s, SCR_EV_SAIU, ep) == SCR_STOP);
  assert(mdblist_decidir(&s, SCR_EV_SAIU, ep) == SCR_NADA);

  reset(); assert(event(SCR_EV_TOCANDO, ep, 20) == SCR_NADA);
  mdblist_atualizar(1, 1); assert(event(SCR_EV_TOCANDO, ep, 20) == SCR_NADA);
  assert(!strcmp(mdblist_estado(), "Chave ausente"));
  enable();
  assert(mdblist_scrobble(SCR_EV_TOCANDO, ep, 2, 30) == SCR_NADA);
  assert(mdblist_scrobble(SCR_EV_TOCANDO, ep, NAN, 200) == SCR_NADA);
  assert(event(SCR_EV_TOCANDO, "jellyfin:abc", 20) == SCR_NADA);
  assert(event(SCR_EV_TOCANDO, ep, 20) == SCR_START);
  assert(event(SCR_EV_TOCANDO, ep, 21) == SCR_NADA);
  assert(event(SCR_EV_PAUSOU, ep, 0.5) == SCR_PAUSE); /* no Trakt 1% limit */
  assert(event(SCR_EV_TOCANDO, ep, 30) == SCR_START);
  assert(event(SCR_EV_SAIU, ep, 79.99) == SCR_STOP);
  assert(event(SCR_EV_TOCANDO, "tt0944947:5:4", 0) == SCR_START);
  assert(!calls); drain(); assert(calls == 5);
  assert(strstr(urls[0], "/start?apikey=test_key-123"));
  assert(strstr(urls[1], "/pause?") && strstr(bodies[1], "0.50"));
  assert(strstr(urls[3], "/stop?") && strstr(bodies[3], "79.99"));
  assert(strstr(bodies[4], "\"episode\":4"));
  now += 59; assert(event(SCR_EV_TOCANDO, "tt0944947:5:4", 30) == SCR_NADA);
  now++; assert(event(SCR_EV_TOCANDO, "tt0944947:5:4", 35) == SCR_START); drain();
  assert(calls == 6);
  assert(event(SCR_EV_SAIU, "tt0944947:5:4", 80) == SCR_STOP); drain();
  assert(strstr(bodies[6], "79.99")); /* default 85 protects 80-85 */
  assert(event(SCR_EV_SAIU, "tt123", 90) == SCR_STOP); drain();
  assert(strstr(bodies[7], "90.00"));

  reset(); enable(); event(SCR_EV_TOCANDO, ep, 20); mdblist_atualizar(1, 2); drain(); assert(!calls);
  event(SCR_EV_TOCANDO, ep, 20); mdblist_atualizar(0, 2); drain(); assert(!calls);
  enable(); event(SCR_EV_TOCANDO, ep, 20); mdblist_definir_chave("new_key"); drain(); assert(!calls);
  event(SCR_EV_TOCANDO, ep, 21); drain(); assert(calls == 1 && strstr(urls[0], "apikey=new_key"));
  event(SCR_EV_SAIU, ep, 40); mdblist_definir_chave(""); drain(); assert(calls == 1);
  mdblist_definir_chave("abc&injected=1"); assert(!chave[0]);
  { char key[100]; memset(key, 'a', sizeof key); key[99] = 0; mdblist_definir_chave(key); assert(!chave[0]); }

  reset(); enable(); http = 401; event(SCR_EV_TOCANDO, ep, 10); drain();
  assert(calls == 1 && !strcmp(mdblist_estado(), "Chave recusada"));
  now += 10000; assert(event(SCR_EV_TOCANDO, ep, 20) == SCR_NADA);
  http = 200; mdblist_definir_chave("corrected"); event(SCR_EV_TOCANDO, ep, 20); drain(); assert(calls == 2);
  switch_key = 1; http = 401; event(SCR_EV_PAUSOU, ep, 25); drain();
  assert(!bloqueado && !strcmp(chave, "replacement")); /* stale failure cannot reject the new key */

  reset(); enable(); http = 503; event(SCR_EV_TOCANDO, ep, 10); drain(); assert(calls == 1);
  mdblist_atualizar(1, 1); drain(); assert(calls == 1);
  now += 30; mdblist_atualizar(1, 1); drain(); assert(calls == 2);
  now += 120; mdblist_atualizar(1, 1); drain(); assert(calls == 3 && !quantidade);
  reset(); enable(); http = 0; event(SCR_EV_SAIU, ep, 80); drain();
  now += 30; http = 200; mdblist_atualizar(1, 1); drain(); assert(calls == 2 && !quantidade);
  reset(); enable(); http = 422; event(SCR_EV_TOCANDO, ep, 20); drain();
  now += 30; mdblist_atualizar(1, 1); drain(); assert(calls == 1 && !quantidade);
  reset(); enable(); http = 429; event(SCR_EV_SAIU, ep, 85); drain();
  assert(!strcmp(mdblist_estado(), "Limite da API atingido"));
  now = 86399; mdblist_atualizar(1, 1); drain(); assert(calls == 1);
  now = 86400; http = 200; mdblist_atualizar(1, 1); drain(); assert(calls == 2 && !quantidade);

  reset(); enable(); create_fail = 1; event(SCR_EV_TOCANDO, ep, 10); assert(!scheduled && quantidade == 1);
  create_fail = 0; now += 30; mdblist_atualizar(1, 1); drain(); assert(calls == 1);
  reset(); enable();
  { int i; char id[64]; for (i = 0; i < MDB_QUEUE; i++) {
      snprintf(id, sizeof id, "tt123:1:%d", i + 1); assert(event(SCR_EV_SAIU, id, 80) == SCR_STOP);
    }
    assert(event(SCR_EV_SAIU, "tt123:2:1", 80) == SCR_NADA);
    drain(); assert(calls == MDB_QUEUE);
    assert(event(SCR_EV_SAIU, "tt123:2:1", 80) == SCR_STOP); drain();
  }
  reset(); enable();
  assert(event(SCR_EV_TOCANDO,ep,79)==SCR_START);drain();
  assert(event(SCR_EV_PAUSOU,ep,84.999)==SCR_PAUSE);drain();assert(strstr(bodies[1],"79.99"));
  assert(event(SCR_EV_TOCANDO,ep,84.999)==SCR_START);drain();
  assert(event(SCR_EV_TOCANDO,ep,85)==SCR_STOP);drain();assert(strstr(bodies[3],"85.00"));
  assert(event(SCR_EV_PAUSOU,ep,86)==SCR_NADA&&event(SCR_EV_SAIU,ep,90)==SCR_NADA);drain();assert(calls==4);
  assert(event(SCR_EV_TOCANDO,ep,0)==SCR_START);drain(); /* deliberate replay */
  reset();enable();mdblist_limiar(95);event(SCR_EV_TOCANDO,"tt123",90);drain();event(SCR_EV_SAIU,"tt123",94.999);drain();assert(strstr(bodies[1],"79.99"));
  reset();enable();mdblist_limiar(80);event(SCR_EV_SAIU,"tt123",80);drain();assert(strstr(bodies[0],"80.00"));
  puts("MDBList payload, lifecycle, FIFO, consent, credentials, retries, 85%/95% boundary, completion dedup and replay tests passed.");
  return 0;
}
