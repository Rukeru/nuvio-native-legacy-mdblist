#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define NV_VERSAO "2.0.2.17"
#include "../src/mdbchangelog.c"
static char saved[80];
static int reads, writes, fail_save, drawn, blocks;
static float scale = 1, configured = 1;
static float accent = .3f, button_luminance;
static float linear(float c) {return c<=.04045f ? c/12.92f : powf((c+.055f)/1.055f,2.4f);}
char *dados_ler(const char *name) {
  assert(!strcmp(name, SEEN)); reads++;
  return saved[0] ? strdup(saved) : NULL;
}
int dados_gravar(const char *name, const char *s) {
  assert(!strcmp(name, SEEN)); writes++;
  if (fail_save) return 0;
  snprintf(saved, sizeof saved, "%s", s); return 1;
}
const char *i18n(const char *s) { return s; }
void ajustes_acento(float *r,float *g,float *b) {*r=*g=*b=accent;}
float gfx_escala_ui(void) {return configured;}
float gfx_escala(void) {return scale;}
void gfx_escala_sair(float s) {scale=s;}
void gfx_cor(GfxRect rect,float radius,float r,float g,float b,float a) {
  (void)radius;(void)r;(void)g;(void)b;(void)a;
  assert(rect.x >= 0 && rect.y >= 0);
  assert(rect.x + rect.w <= NV_TELA_W + .01f && rect.y + rect.h <= NV_TELA_H + .01f); drawn++;
  if(rect.w==260 && rect.h==72) button_luminance=.2126f*linear(r)+.7152f*linear(g)+.0722f*linear(b);
}
void gfx_anel(GfxRect rect,float radius,float width,float r,float g,float b,float a) {
  (void)width;gfx_cor(rect,radius,r,g,b,a);
}
TxtLinha txt_linha_corta(TxtEstilo st,const char *s,int r,int g,int b,int a,float width) {
  (void)st;(void)a;assert(s && width>0);
  if(!strcmp(s,"OK · Got it")) {
    float text_luminance=.2126f*linear(r/255.f)+.7152f*linear(g/255.f)+.0722f*linear(b/255.f);
    assert((text_luminance+.05f)/(button_luminance+.05f)>=4.5f);
  }
  return (TxtLinha){0};
}
void txt_desenhar(TxtLinha l,float x,float y) {(void)l;assert(x>=0 && y>=0);}
float txt_bloco_corta(TxtEstilo st,const char *s,int r,int g,int b,float x,float y,float width,float leading,float alpha,int lines) {
  (void)st;(void)r;(void)g;(void)b;(void)x;(void)y;(void)alpha;
  assert(s && width>0 && leading==32 && lines==2);blocks++;return leading*lines;
}
static void key(SDL_Keycode k,int repeat) {
  SDL_Event e={0};e.type=SDL_KEYDOWN;e.key.keysym.sym=k;e.key.repeat=repeat;mdbchangelog_evento(&e);
}
static void restart(void) {checked=opened=page=0;}
int main(void) {
  mdbchangelog_primeira_vez();assert(opened && reads==1 && !writes);
  for(int i=0;i<10000;i++)mdbchangelog_primeira_vez();assert(reads==1);
  key(SDLK_RIGHT,1);assert(page==0);key(SDLK_RIGHT,0);assert(page==1);
  for(int i=0;i<PAGES+2;i++)key(SDLK_RIGHT,0);assert(page==PAGES-1);
  for(int i=0;i<PAGES+2;i++)key(SDLK_LEFT,0);assert(page==0);
  for(int s=0;s<3;s++) {configured=1+s*.25f;accent=s*.5f;drawn=blocks=0;scale=1;
    mdbchangelog_desenhar();assert(drawn>0 && blocks==3 && scale==1);}
  key(SDLK_RETURN,0);assert(!opened && writes==1 && !strcmp(saved,NV_VERSAO));
  restart();mdbchangelog_primeira_vez();assert(!opened);
  mdbchangelog_abrir();assert(opened && page==0);key(SDLK_ESCAPE,0);assert(!opened);
  strcpy(saved,"2.0.2.16");restart();mdbchangelog_primeira_vez();assert(opened);
  fail_save=1;key(SDLK_AC_BACK,0);assert(!opened);
  mdbchangelog_primeira_vez();assert(!opened);restart();mdbchangelog_primeira_vez();assert(opened);
  fail_save=0;key(SDLK_SPACE,0);restart();mdbchangelog_primeira_vez();assert(!opened);
  puts("changelog: installed-version persistence, idle reads, pagination, remote keys and layout passed");
}
