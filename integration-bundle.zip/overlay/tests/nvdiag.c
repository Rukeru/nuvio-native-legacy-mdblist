/* Real worker, formatter and persistence; controlled HTTPS transport only. */
#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <unistd.h>
#include <sys/stat.h>
#include "../src/nvdiag.c"
static char test_dir[1024], sent[NVD_PAYLOAD], auth[180];
static int posts,reply_status=201,write_fail,check_thread;
static pthread_t ui;
static const char *reply_body="{\"version\":1,\"report_id\":\"11111111-2222-4333-8444-555555555555\",\"code\":\"ABC234\"}";
char *dados_caminho(char *out,unsigned cap,const char *name) {
 snprintf(out,cap,"%s/%s",test_dir,name);return out;
}
int dados_gravar_privado(const char *name,const char *body) {
 char path[2048];FILE *f;
 if(check_thread)assert(!pthread_equal(ui,pthread_self()));
 if(write_fail)return 0;
 dados_caminho(path,sizeof path,name);f=fopen(path,"wb");assert(f);
 assert(chmod(path,0600)==0);assert(fwrite(body,1,strlen(body),f)==strlen(body));assert(!fclose(f));return 1;
}
int dados_apagar(const char *name) {char path[2048];dados_caminho(path,sizeof path,name);return !unlink(path);}
int rede_pedir(const RedePedido *p,RedeResposta *r) {
 if(check_thread)assert(!pthread_equal(ui,pthread_self()));
 assert(!strcmp(p->metodo,"POST"));assert(p->max_bytes==4096&&p->max_cabecalhos==4096);
 assert(p->prazo_ms==10000&&!p->seguir&&!p->tls_pessoal);
 assert(!strncmp(p->url,"https://nuvio-diagnostics-api.rukeru23.workers.dev/v1/",
   sizeof("https://nuvio-diagnostics-api.rukeru23.workers.dev/v1/")-1));
 assert(strlen(p->corpo)<NVD_PAYLOAD);strcpy(sent,p->corpo);
 auth[0]=0;
 if(p->cabecalhos[0] && !strncmp(p->cabecalhos[0],"Authorization:",14))strcpy(auth,p->cabecalhos[0]);
 posts++;r->erro=REDE_OK;r->status=reply_status;r->corpo=strdup(reply_body);return 1;
}
void rede_resposta_limpar(RedeResposta *r){free(r->corpo);free(r->cabecalhos);memset(r,0,sizeof *r);}
static NvDiagReport sample(void) {
 NvDiagReport r={0};strcpy(r.id,"12345678-1234-4123-8123-123456789abc");
 strcpy(r.version,"2.0.4.64");strcpy(r.build,"0123456789abcdef0123456789abcdef01234567");
 r.created=time(NULL);r.n=1;r.events[0]=(NvDiagEvent){NVD_MANUAL,1,0};return r;
}
static void format_tests(void) {
 NvDiagReport r=sample();char json[NVD_PAYLOAD];int i;
 assert(nvdiag_report_json(&r,"tizen",json,sizeof json));
 assert(strstr(json,"\"manual_report\",\"context\":{\"count\":1}"));
 assert(!nvdiag_report_json(&r,"android",json,sizeof json));
 assert(!nvdiag_report_json(&r,"webos",json,20)&&!json[0]);
 r.n=33;assert(!nvdiag_report_json(&r,"webos",json,sizeof json));r.n=1;
 strcpy(r.version,"2.0.4\"secret");assert(!nvdiag_report_json(&r,"webos",json,sizeof json));r=sample();
 r.id[14]='1';assert(!nvdiag_report_json(&r,"webos",json,sizeof json));r=sample();
 r.build[5]='\"';assert(!nvdiag_report_json(&r,"webos",json,sizeof json));r=sample();
 for(i=0;i<NVD_EVENT_COUNT;i++) {
  int a=0,b=0;
  if(i==NVD_MANUAL||i==NVD_PREVIOUS||i==NVD_DUPLICATE)a=1;
  if(i==NVD_RETRY)b=1;
  r.events[0]=(NvDiagEvent){i,a,b};
  assert(nvdiag_report_json(&r,"webos",json,sizeof json));
  r.events[0].a=-1;assert(!nvdiag_report_json(&r,"webos",json,sizeof json));
  r.events[0].a=1000000;assert(!nvdiag_report_json(&r,"webos",json,sizeof json));
 }
 assert(!nvdiag_event_valid((NvDiagEvent){NVD_MDB_FAILED,42,0}));
 assert(!nvdiag_event_valid((NvDiagEvent){NVD_MDB_AUTH,401,1}));
 assert(!nvdiag_event_valid((NvDiagEvent){NVD_RETRY,9,1}));
 assert(!nvdiag_event_valid((NvDiagEvent){NVD_RETRY,1,0}));
 assert(nvdiag_backoff(1,0)==30&&nvdiag_backoff(2,503)==60);
 assert(nvdiag_backoff(8,503)<=3840&&nvdiag_backoff(1,429)==3600);
}
static void persistence_tests(void) {
 NvDiagReport loaded[NVD_QUEUE];char body[32768];int i;
 status.queued=NVD_QUEUE;
 for(i=0;i<NVD_QUEUE;i++){queue[i]=sample();queue[i].automatic=i%2;queue[i].events[0].a=i+1;}
 assert(save_queue());assert(load_queue(loaded,1)==8);assert(load_queue(loaded,0)==4);
 assert(loaded[3].events[0].a==7);
 assert(bounded_read(QUEUE,body,sizeof body));
 assert(!bounded_read(QUEUE,body,20));
 dados_gravar_privado(QUEUE,"R bad secret https://private/addon 1 0 0 10 0\nE 0 1 0\n");
 assert(load_queue(loaded,1)==0);
 status.queued=1;queue[0]=sample();queue[0].created=time(NULL)-15*86400;assert(save_queue());assert(load_queue(loaded,1)==0);
 queue[0]=sample();queue[0].attempts=9;assert(save_queue());assert(load_queue(loaded,1)==0);
 status.queued=0;assert(save_queue());
}
static void transmission_tests(void) {
 int before;char first[NVD_PAYLOAD];
 strcpy(installation,"11111111-2222-4333-8444-555555555555");memset(secret,'a',64);secret[64]=0;
 status.queued=1;queue[0]=sample();strcpy(manual_id,queue[0].id);status.paired=1;
 before=posts;write_fail=1;upload(0);assert(posts==before);write_fail=0;
 reply_status=503;upload(0);assert(status.queued==1&&status.state==3);strcpy(first,sent);
 assert(strstr(auth,"Bearer nv1.")&&!strstr(sent,secret));
 reply_status=201;upload(0);assert(!strcmp(first,sent));assert(!status.queued&&status.state==2&&!strcmp(status.receipt,"ABC234"));
 status.queued=1;queue[0]=sample();reply_status=409;upload(0);assert(queue[0].attempts==8&&status.queued==1);
 queue[0]=sample();reply_status=401;upload(0);assert(!status.paired&&status.queued==1);
 queue[0]=sample();reply_status=429;upload(0);assert(queue[0].next>=time(NULL)+3599);
 queue[0]=sample();reply_status=201;reply_body="{\"code\":null}";upload(0);assert(status.queued==1&&status.state==3);
 status.queued=0;assert(save_queue());
}
static int ready_state(int preview_needed) {
 NvDiagStatus s;int i;
 for(i=0;i<200;i++){
  struct timespec delay={0,10000000};nvdiag_status(&s);
  if(s.ready&&(!preview_needed||s.preview_ready))return 1;
  nanosleep(&delay,NULL);
 }
 return 0;
}
static void asynchronous_tests(void) {
 NvDiagStatus s;char body[NVD_PAYLOAD];struct timespec a,b;int before=posts,i;
 memset(&status,0,sizeof status);memset(secret,0,sizeof secret);installation[0]=0;
 dados_apagar(CREDENTIALS);dados_apagar(CONSENT);dados_apagar(RECEIPT);
 /* Upstream consent does not grant this recipient consent. */
 dados_gravar_privado("telemetria-perguntado.txt","1\n");
 ui=pthread_self();check_thread=1;nvdiag_init();assert(ready_state(0));
 nvdiag_status(&s);assert(!s.consent&&!s.asked&&!s.paired);
 nvdiag_event(NVD_MDB_AUTH,401,0);nvdiag_event(NVD_MDB_AUTH,401,0);
 assert(event_count==1);
 nvdiag_preview();assert(ready_state(1));assert(nvdiag_preview_copy(body,sizeof body));
 assert(strstr(body,"mdblist_auth")&&!strstr(body,"token")&&!strstr(body,"https://"));assert(posts==before);
 assert(!nvdiag_send()); /* no device credential */
 clock_gettime(CLOCK_MONOTONIC,&a);
 for(i=0;i<100000;i++){nvdiag_performance(16,100);nvdiag_status(&s);}
 clock_gettime(CLOCK_MONOTONIC,&b);
 assert((b.tv_sec-a.tv_sec)+(b.tv_nsec-a.tv_nsec)/1e9<1.0);
 assert(posts==before);
 nvdiag_shutdown();check_thread=0;
 puts("PASS private diagnostics: privacy, strict schema, queue, retry, consent, worker and overhead");
}
int main(void) {
 char dir[]="/tmp/nvdiag-test.XXXXXX";assert(mkdtemp(dir));strcpy(test_dir,dir);
 format_tests();persistence_tests();transmission_tests();asynchronous_tests();
 return 0;
}
