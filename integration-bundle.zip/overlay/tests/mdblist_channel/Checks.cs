using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using NuvioTpk;
static class Checks
{
    static void Require(bool ok, string message) { if (!ok) throw new Exception(message); }
    static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
    static byte[] Changed(byte[] original, int offset, byte value) { var b=(byte[])original.Clone();b[offset]=value;return b; }
    static int Find(byte[] b, string s)
    {
        byte[] t=Encoding.ASCII.GetBytes(s);
        for(int i=0;i<=b.Length-t.Length;i++) { int j=0;while(j<t.Length && b[i+j]==t[j])j++;if(j==t.Length)return i; }
        throw new Exception("Missing fixture symbol");
    }
    static void Stage(string dir, byte[] b, string version, string hash=null)
    {
        File.WriteAllBytes(Path.Combine(dir,"libnuvio.staged.so"),b);
        File.WriteAllText(Path.Combine(dir,"libnuvio.staged.sha256"),hash??Hash(b));
        File.WriteAllText(Path.Combine(dir,"libnuvio.staged.ver"),version);
    }
    static int Main(string[] args)
    {
        byte[] good=File.ReadAllBytes(args[0]);
        string shell=File.ReadAllText(args[1]).Trim();
        Require(MdbListChannel.Compatible(good,shell),"Patched release ELF must be accepted");
        Require(!MdbListChannel.Compatible(null),"Null ELF rejected");
        Require(!MdbListChannel.Compatible(new byte[51]),"Short ELF rejected");
        Require(!MdbListChannel.Compatible(Changed(good,4,2)),"ELF64 rejected");
        Require(!MdbListChannel.Compatible(Changed(good,5,2)),"Big endian rejected");
        Require(!MdbListChannel.Compatible(Changed(good,18,62)),"Wrong architecture rejected");
        Require(!MdbListChannel.Compatible(Changed(good,37,(byte)(good[37]|4))),"Hard-float ABI rejected");
        Require(!MdbListChannel.Compatible(Changed(good,46,1)),"Invalid section size rejected");
        var corrupt=(byte[])good.Clone();for(int i=32;i<36;i++)corrupt[i]=255;
        Require(!MdbListChannel.Compatible(corrupt),"Section range overflow rejected");
        var noMarker=Changed(good,Find(good,"nv_mdblist_update_contract_v1"),(byte)'X');
        Require(!MdbListChannel.Compatible(noMarker),"Missing export rejected");
        Require(!MdbListChannel.Compatible(Changed(good,Find(good,"nuvio-mdblist-tracking/1"),(byte)'X')),"Wrong contract rejected");
        Require(!MdbListChannel.Compatible(good,new string('f',64)),"Different host/resource identity rejected");
        if(args.Length>2)Require(!MdbListChannel.Compatible(File.ReadAllBytes(args[2])),"Real upstream vanilla ELF rejected");
        string dir=Path.Combine(Path.GetTempPath(),"nuvio-mdblist-check-"+Guid.NewGuid());Directory.CreateDirectory(dir);
        try {
            Stage(dir,good,"2.0.3.1");Require(NvCarga.DecidirStaged(dir,"2.0.2.0",out _)==null,"Missing packaged shell identity rejected");
            Stage(dir,good,"2.0.3.1");Require(NvCarga.DecidirStaged(dir,"2.0.2.0",out _,shell)!=null,"Valid patched update selected");
            Stage(dir,noMarker,"2.0.3.1");Require(NvCarga.DecidirStaged(dir,"2.0.2.0",out _,shell)==null,"Correct checksum cannot admit vanilla update");
            Require(!File.Exists(Path.Combine(dir,"libnuvio.staged.so")),"Rejected staging removed");
            Stage(dir,good,"2.0.3.1",new string('0',64));Require(NvCarga.DecidirStaged(dir,"2.0.2.0",out _,shell)==null,"Checksum mismatch rejected");
            Stage(dir,good,"2.0.2.0");Require(NvCarga.DecidirStaged(dir,"2.0.2.0",out _,shell)==null,"Equal version rejected");
            Stage(dir,good,"2.0.2.2");Require(NvCarga.DecidirStaged(dir,"2.0.2.1",out _,shell)!=null,"Newer fork revision accepted");
            Stage(dir,good,"2.0.2.1");Require(NvCarga.DecidirStaged(dir,"2.0.2.2",out _,shell)==null,"Older fork revision rejected");
        } finally { Directory.Delete(dir,true); }
        Console.WriteLine("MDBList ELF compatibility, checksum and staged update tests: PASS");return 0;
    }
}
