#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
cc -std=c11 -UNDEBUG -DSDL_MAIN_HANDLED -Wall -Wextra -Werror -Isrc $(sdl2-config --cflags) tests/discover.c -o "$tmp/discover"
"$tmp/discover"
