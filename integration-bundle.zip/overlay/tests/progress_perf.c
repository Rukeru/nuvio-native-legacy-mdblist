/* Real progress data and renderer, deterministic drawing backend; no TV FPS claim. */
#define NV_PROGRESS_PERF
#include "../src/vistoep.c"
#include "../src/temporadas_grafico.c"
#include <assert.h>
#include <time.h>
static CatItem item;
static CatEp episodes[1200];
static int episodeCount, graphCalls, textCalls, draws;
static unsigned catalogRevision=1, friendRevision=1;
int txt_pendentes,gfx_n_rect,gfx_n_bind;
float gfx_opacidade_grupo=1;
static int targetsAvailable=1,language,font;
int ajustes_idioma(void) { return language; }
int ajustes_medidor_desempenho(void) { return 0; }
TxtFamilia txt_fonte_interface(void) { return (TxtFamilia)font; }
Uint64 SDLCALL SDL_GetPerformanceCounter(void) { return (Uint64)clock(); }
Uint64 SDLCALL SDL_GetPerformanceFrequency(void) { return CLOCKS_PER_SEC; }
int gfx_mini_disponivel(void) { return targetsAvailable; }
int gfx_mini_alvo(GfxMini *m,int w,int h) { m->w=w;m->h=h;m->fbo=m->tex=1;return 1; }
void gfx_mini_liberar(GfxMini *m) { memset(m,0,sizeof *m); }
void gfx_mini_comecar(GfxMini *m,float x,float y,float scale) { (void)m;(void)x;(void)y;(void)scale; }
void gfx_mini_terminar(void) {}
void gfx_mini_desenhar(const GfxMini *m,GfxRect r,float radius,float alpha) { (void)m;(void)r;(void)radius;(void)alpha;draws++; }
const CatItem *cat_item(int i) { return i==0?&item:NULL; }
int cat_n_episodios(int i) { return i==0?episodeCount:0; }
const CatEp *cat_episodio(int i,int e) { return i==0&&e>=0&&e<episodeCount?episodes+e:NULL; }
unsigned cat_revisao(void) { return catalogRevision; }
int extras_agenda_temporada(void) { return 0; }
int extras_agenda_episodio(void) { return 0; }
unsigned amigostitulo_revisao(void) { return friendRevision; }
int amigostitulo_obter(const char *id,AmigosTitulo *out) { (void)id; memset(out,0,sizeof *out);return 0; }
void amigostitulo_primeiro_nome(const char *s,char *out,size_t size) { snprintf(out,size,"%s",s); }
const char *i18n(const char *s) { return s; }
int ajustes_animacoes_reduzidas(void) { return 0; }
void ajustes_acento(float *r,float *g,float *b) { *r=.4f;*g=.7f;*b=1; }
TxtLinha txt_linha(TxtEstilo style,const char *s,int r,int g,int b,int a) { (void)style;(void)r;(void)g;(void)b;(void)a;textCalls++;return (TxtLinha){1,(int)strlen(s)*10,22,0,0}; }
TxtLinha txt_linha_corta(TxtEstilo style,const char *s,int r,int g,int b,int a,float w) { TxtLinha result=txt_linha(style,s,r,g,b,a);if(result.w>w)result.w=(int)w;return result; }
void txt_desenhar_alpha(TxtLinha l,float x,float y,float a) { (void)l;(void)x;(void)y;(void)a;draws++; }
void gfx_cor(GfxRect r,float radius,float cr,float cg,float cb,float a) { (void)r;(void)radius;(void)cr;(void)cg;(void)cb;(void)a;draws++; }
void gfx_icone(GfxRect r,const char *icon,float cr,float cg,float cb,float a) { (void)r;(void)icon;(void)cr;(void)cg;(void)cb;(void)a;draws++; }
void notasui_painel(GfxRect r,float radius,float a) { (void)r;(void)radius;(void)a;draws++; }
void plrui_linha_foco(GfxRect r,float radius,float a) { (void)r;(void)radius;(void)a;draws++; }
void plrui_trilho(GfxRect r,float fraction,float cr,float cg,float cb,float a) { (void)r;(void)fraction;(void)cr;(void)cg;(void)cb;(void)a;graphCalls++;draws++; }
void svd_avatar(GfxRect r,const char *url,const char *name,const char *id,float a) { (void)r;(void)url;(void)name;(void)id;(void)a;draws++; }
void svd_ponto_vivo(float x,float y,float d,float border,float a,Uint32 t) { (void)x;(void)y;(void)d;(void)border;(void)a;(void)t;draws++; }
static void seed(int count) {
 vistoep_esquecer(); episodeCount=count;catalogRevision++;memset(&item,0,sizeof item);strcpy(item.imdb,"tt0096697");
 for(int i=0;i<8000-count;i++)vistoep_definir("tt0000001",i/100+1,i%100+1,1);
 for(int i=0;i<count;i++){memset(episodes+i,0,sizeof *episodes);episodes[i].temporada=i/24+1;episodes[i].episodio=i%24+1;vistoep_definir(item.imdb,episodes[i].temporada,episodes[i].episodio,i%2);}
}
int main(void) {
 int sizes[]={72,888,1200};
 for(int test=0;test<3;test++) {
  seed(sizes[test]);vistoep_perf_reads=0;clock_t start=clock();
  const TgDados *data=tgraf_dados(0);
  double buildMs=1000.0*(clock()-start)/CLOCKS_PER_SEC;
  unsigned long long reads=vistoep_perf_reads;
  assert(data->total==sizes[test]&&data->vistos==sizes[test]/2);
  for(int frame=0;frame<1000;frame++)assert(tgraf_dados(0)==data);
  assert(vistoep_perf_reads==reads); /* stable frames already cached */
  unsigned revision=data->revision;
  vistoep_definir("tt0000001",1,1,0);
  assert(tgraf_dados(0)->revision==revision); /* unrelated history */
  vistoep_definir(item.imdb,1,1,0);assert(tgraf_dados(0)->revision==revision); /* no-op */
  strcat(item.imdb,":1:1");assert(tgraf_dados(0)->revision==revision);strcpy(item.imdb,"tt0096697");
  tgraf_reiniciar();tgraf_desenhar(data,48,200,1824,-1,1,1,1);
  graphCalls=textCalls=draws=0;start=clock();
  for(int frame=0;frame<1000;frame++)tgraf_desenhar(data,48,200,1824,-1,1,1,10000+frame*16);
  printf("progress %d episodes/%d seasons: rebuild_reads=%llu build_ms=%.3f; stable_1000_frames bars=%d text_calls=%d draws=%d draw_cpu_ms=%.3f\n",sizes[test],data->n,reads,buildMs,graphCalls,textCalls,draws,1000.0*(clock()-start)/CLOCKS_PER_SEC);
  graphCalls=0;tgraf_desenhar(data,48,190,1824,-1,1,.5f,30000);assert(graphCalls>0);
  language++;font++;tgraf_desenhar(data,48,190,1824,2,1,1,30000);
  graphCalls=draws=0;tgraf_desenhar(data,48,1200,1824,2,1,1,30000);assert(!graphCalls&&!draws);
  targetsAvailable=0;tgraf_desenhar(data,48,200,1824,2,1,1,30000);assert(graphCalls>0);targetsAvailable=1;
  vistoep_definir(item.imdb,1,1,1);assert(tgraf_dados(0)->vistos==sizes[test]/2+1);
 }
 for(int seasons=1;seasons<=64;seasons++)for(int focus=0;focus<seasons;focus++) {
  float widths[]={1024,1260,1824};
  for(int w=0;w<3;w++){TgLayout layout=tgraf_layout(seasons,widths[w],focus);
   assert(layout.count>0&&layout.first<=focus&&focus<layout.first+layout.count);
   assert(layout.rowHeight>=46&&layout.columnWidth>=300);
   assert(layout.count<=layout.rows*layout.columns&&layout.first+layout.count<=seasons);
  }
 }
 tgraf_reiniciar();
 vistoep_esquecer();puts("progress fixture: watched counts, stable data cache and visible-window assertions passed");
}
