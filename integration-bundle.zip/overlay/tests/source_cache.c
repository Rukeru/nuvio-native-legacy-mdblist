#include "streams.h"
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
static int status(const char *s) { return stream_cache_metadata(s,s+strlen(s)); }
int main(void) {
  assert(status("{\"streamData\":{\"service\":{\"cached\":true}}}")==STREAM_CACHE_CACHED);
  assert(status("{\"streamData\":{\"service\":{\"cached\":false}}}")==STREAM_CACHE_UNCACHED);
  assert(status("{\"name\":\"cached instant lightning\",\"filename\":\"cached.mkv\"}")==STREAM_CACHE_UNKNOWN);
  assert(status("{\"streamData\":{\"service\":{\"cached\":\"true\"}}}")==STREAM_CACHE_UNKNOWN);
  assert(status("{\"streamData\":{\"service\":{\"cached\":null}}}")==STREAM_CACHE_UNKNOWN);
  assert(status("{\"behaviorHints\":{\"streamData\":{\"service\":{\"cached\":true}}}}")==STREAM_CACHE_UNKNOWN);
  assert(status("{\"streamData\":{\"service\":{\"other\":{\"cached\":true}}}}")==STREAM_CACHE_UNKNOWN);
  Stream *v=NULL;
  int n=stream_extrair("{\"streams\":[{\"url\":\"https://example.test/a\",\"name\":\"uncached\",\"streamData\":{\"service\":{\"cached\":true}}},{\"url\":\"https://example.test/b\"},{\"url\":\"https://example.test/c\",\"streamData\":{\"service\":{\"cached\":false}}}]}","test",&v);
  assert(n==3); assert(v[0].cacheEstado==STREAM_CACHE_CACHED && !v[0].foraCache);
  assert(v[1].cacheEstado==STREAM_CACHE_UNKNOWN); assert(v[2].foraCache);
  free(v); puts("source cache: explicit booleans, scope, missing fields and precedence passed");
}
