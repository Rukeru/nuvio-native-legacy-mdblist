#!/bin/bash
set -eu
cd "$(dirname "$0")/.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
cc -std=c11 -Wall -Wextra -Werror -Isrc tests/mdblist_channel.c src/mdblistchannel.c -o "$out/channel"
"$out/channel"
