"""Keep local fixture HTTPServer startup independent of hosted reverse DNS.

Client networking, sockets, TLS verification and non-loopback DNS are real.
HTTPServer.server_bind only uses getfqdn to set its diagnostic server_name.
"""
import socket
_original_getfqdn=socket.getfqdn

def _fixture_getfqdn(name=''):
    if name in ('127.0.0.1','::1'):
        return 'localhost'
    return _original_getfqdn(name)

socket.getfqdn=_fixture_getfqdn
