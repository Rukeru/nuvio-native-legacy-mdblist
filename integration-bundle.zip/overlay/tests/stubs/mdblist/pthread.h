/* Deterministic scheduler for MDBList transport tests. Never used by builds. */
#ifndef MDB_TEST_PTHREAD_H
#define MDB_TEST_PTHREAD_H
typedef int pthread_mutex_t;
typedef int pthread_t;
#define PTHREAD_MUTEX_INITIALIZER 0
int pthread_mutex_lock(pthread_mutex_t *m);
int pthread_mutex_unlock(pthread_mutex_t *m);
int pthread_create(pthread_t *t, const void *attr, void *(*run)(void *), void *arg);
int pthread_detach(pthread_t t);
#endif
