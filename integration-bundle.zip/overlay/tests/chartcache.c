#include "chartcache.h"
#include "text.h"
#include <SDL2/SDL.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
static int paints,available=1,language,font,pending;
int txt_pendentes,gfx_n_rect,gfx_n_bind;
float gfx_opacidade_grupo=1;
int ajustes_idioma(void) { return language; }
int ajustes_medidor_desempenho(void) { return 0; }
TxtFamilia txt_fonte_interface(void) { return (TxtFamilia)font; }
Uint64 SDLCALL SDL_GetPerformanceCounter(void) { return 100; }
Uint64 SDLCALL SDL_GetPerformanceFrequency(void) { return 1000; }
int gfx_mini_disponivel(void) { return available; }
int gfx_mini_alvo(GfxMini *m,int w,int h) { m->w=w;m->h=h;m->fbo=m->tex=1;return 1; }
void gfx_mini_liberar(GfxMini *m) { memset(m,0,sizeof *m); }
void gfx_mini_comecar(GfxMini *m,float x,float y,float s) { (void)m;(void)x;(void)y;(void)s; }
void gfx_mini_terminar(void) {}
void gfx_mini_desenhar(const GfxMini *m,GfxRect r,float radius,float a) { (void)m;(void)r;(void)radius;(void)a; }
static void paint(GfxRect r,const void *p) { (void)r;(void)p;paints++;txt_pendentes+=pending; }
int main(void) {
 ChartCache c={0},other={0};GfxRect r={0,0,900,800};
 assert(chartcache_draw(&c,r,1,paint,NULL,1)); assert(paints==1);
 r.y=-200; assert(chartcache_draw(&c,r,1,paint,NULL,.5f));assert(paints==1);
 assert(chartcache_draw(&c,r,2,paint,NULL,1));assert(paints==2);
 language++;chartcache_draw(&c,r,2,paint,NULL,1);assert(paints==3);
 font++;chartcache_draw(&c,r,2,paint,NULL,1);assert(paints==4);
 assert(!chartcache_draw(&other,(GfxRect){0,0,1200,800},1,paint,NULL,1));
 chartcache_clear(&c);assert(chartcache_draw(&other,(GfxRect){0,0,1200,800},1,paint,NULL,1));
 chartcache_clear(&other);available=0;assert(!chartcache_draw(&c,r,1,paint,NULL,1));available=1;
 pending=1;chartcache_draw(&c,r,8,paint,NULL,1);assert(!c.valid);
 pending=0;int before=paints;chartcache_draw(&c,r,8,paint,NULL,1);assert(c.valid&&paints==before+1);
 chartcache_clear(&c);puts("chart cache: scrolling, revision/font/language invalidation, pending text, nesting and memory budget passed");
}
