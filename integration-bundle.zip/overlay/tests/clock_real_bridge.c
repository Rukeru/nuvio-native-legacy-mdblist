/* Darwin equivalent of the GNU linker clock wrapper: only this bridge
   is compiled without the clock_gettime remapping used by the fixture. */
#define _POSIX_C_SOURCE 200809L
#include <time.h>
int __real_clock_gettime(clockid_t clock, struct timespec *out) {
  return clock_gettime(clock, out);
}
