/* Own the MDBList assertions without editing the upstream factory-default test.
   Include and execute its actual main: new upstream assertions run unchanged. */
#define main upstream_settings_defaults_main
#include "ajustes_padroes.c"
#undef main

int main(void) {
  assert(!ajustes_mdblist_rastrear());
  assert(valor[AJ_MDB_RASTREAR] == 1 && OPCOES[AJ_MDB_RASTREAR].n == 2);
  assert(!strcmp(CHAVE[AJ_MDB_RASTREAR], "mdblistScrobbleLocal"));
  assert(somenteDesteAparelho(AJ_MDB_RASTREAR) && dePerfil(AJ_MDB_RASTREAR));
  assert(OPCOES[AJ_MDB_ESTADO].tipo == OP_LEITURA);
  puts("MDBList factory consent, key, profile/local scope and read-only status: ok");
  return upstream_settings_defaults_main();
}
