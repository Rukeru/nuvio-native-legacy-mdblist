/* Controlled transport, clock, credentials, progress and scheduler. No real
   account, network or graphics. Checks complete snapshots and local safety. */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "contalib.h"
/* glibc exposes real pthread typedefs through stdlib in GNU mode. Keep the
   deterministic scheduler's types distinct from those platform typedefs. */
#define pthread_mutex_t MdbTestMutex
#define pthread_t MdbTestThread
#include "pthread.h"
static void *(*scheduled)(void *);
static int calls,http=200,retry=0,changeKey,postCalls;
static unsigned account=1;
static const char *keyValue="test_key";
static const char *response="{\"movies\":[],\"shows\":[]}";
static const char *second;
static const char *historyResponse="{\"movies\":[],\"episodes\":[]}";
static const char *historySecond;
static int historyHttp=200,historyCalls,imported=-1;
static ContaVisto *importRows;
void contalib_mdb_vistos(ContaVisto *owned,int n){free(importRows);importRows=owned;imported=n;}
static const char *postResponse="{\"added\":1,\"existing\":0,\"not_found\":0}";
static time_t now=1791500000;
static double localPos,localDuration;
static time_t fake_time(time_t *out){if(out)*out=now;return now;}
#ifdef _WIN32
static struct tm *portable_gmtime(const time_t *at,struct tm *out){struct tm *r=gmtime(at);if(r)*out=*r;return r?out:NULL;}
#define gmtime_r portable_gmtime
#endif
#define time fake_time
#include "../src/mdblistlibrary.c"
#undef time
int pthread_mutex_lock(pthread_mutex_t *m){assert(!*m);*m=1;return 0;}
int pthread_mutex_unlock(pthread_mutex_t *m){assert(*m);*m=0;return 0;}
int pthread_create(pthread_t *t,const void *attr,void *(*f)(void *),void *arg){(void)attr;(void)arg;assert(!scheduled);scheduled=f;*t=1;return 0;}
int pthread_detach(pthread_t t){(void)t;return 0;}
static void drain(void){void *(*f)(void *)=scheduled;scheduled=NULL;if(f)f(NULL);}
int mdblist_credencial(char *out,size_t n,unsigned *gen){snprintf(out,n,"%s",keyValue);*gen=account;return !!*keyValue;}
unsigned mdblist_geracao_conta(void) { return account; }
char *rede_baixar_st_retry(const char *url,int timeout,const char *const *headers,int *status,int *after){
 assert(!lock&&network);assert(timeout==15);assert(strstr(url,"apikey=test_key"));assert(!strcmp(headers[0],"Accept: application/json"));
 *status=http;*after=retry;calls++;
 if(changeKey){changeKey=0;account++;mdb_library_tick();}
 const char *value=second&&strstr(url,"cursor=page2")?second:response;
 if(strstr(url,"/user?"))value="{\"username\":\"fixture_user\"}";
 if(strstr(url,"/sync/playback"))value="[{\"type\":\"movie\",\"progress\":70,\"runtime\":90,\"movie\":{\"ids\":{\"imdb\":\"tt123\"}},\"paused_at\":\"2026-10-08T01:00:00Z\"}]";
 if(strstr(url,"/upnext"))value="{\"items\":[],\"has_more\":false}";
 if(strstr(url,"/sync/watched")) {
  historyCalls++;
  int later=strstr(url,"cursor=page2")||strstr(url,"offset=1000");
  value=later&&historySecond?historySecond:historyResponse;
  if(later)*status=historyHttp;
  if(strstr(url,"offset="))assert(!strstr(url,"since=")); /* full import includes old watched items */
 }
 return value?strdup(value):NULL;
}
char *rede_postar_st(const char *url,int timeout,const char *const *headers,const char *body,int *status){
 assert(!lock&&network);assert(timeout==15);assert(!strcmp(headers[0],"Content-Type: application/json"));assert(strstr(url,"apikey=test_key"));
 if(strstr(url,"watchlist"))assert(strstr(body,"\"ids\""));
 postCalls++;*status=http;return postResponse?strdup(postResponse):NULL;
}
void prog_chave(char *out,unsigned n,const char *id,int season,int ep){if(ep)snprintf(out,n,"%s_s%de%d",id,season,ep);else snprintf(out,n,"%s",id);}
int prog_por_chave(const char *key,ProgRegistro *out){(void)key;memset(out,0,sizeof *out);out->posSeg=localPos;out->durSeg=localDuration;out->lastWatchedMs=1;return localDuration>0;}
int ajustes_cw_concluido(void){return 90;}
void cwo_marcar_estreia(const char *id,long long at){(void)id;(void)at;}
static void reset(void){drain();account++;keyValue="test_key";char key[80];unsigned gen;credentials(key,&gen);http=200;retry=calls=postCalls=changeKey=0;second=NULL;historySecond=NULL;historyHttp=200;historyResponse="{\"movies\":[],\"episodes\":[]}";historyCalls=0;imported=-1;noticeCode=0;localPos=localDuration=0;}
int main(void){
 CatItem *items=calloc(4,sizeof *items);assert(items);
 reset();response="{\"movies\":[{\"ids\":{\"imdb\":\"tt123\"}}],\"pagination\":{\"next_cursor\":\"page2\"}}";
 second="{\"movies\":[{\"ids\":{\"imdb\":\"tt123\"}}],\"shows\":[{\"ids\":{\"tmdb\":55}}]}";
 assert(mdb_library_watchlist(NULL,0)==2&&calls==2);
 assert(mdb_library_watchlist(items,4)==2&&items[0].naLista&&calls==2);
 assert(mdb_library_watchlist(NULL,0)==2&&calls==2); /* TTL */
 now+=301;http=500;assert(mdb_library_watchlist(NULL,0)==2&&calls==3); /* retain */
 assert(!strcmp(mdb_library_status(),"MDBList network unavailable"));
 now+=61;http=200;assert(mdb_library_watchlist(NULL,0)==2);assert(!strcmp(mdb_library_status(),"MDBList connected")); /* recover status after successful retry */
 reset();http=429;retry=120;assert(mdb_library_watchlist(NULL,0)==0);int seen=calls;
 now+=61;assert(mdb_library_watchlist(NULL,0)==0&&calls==seen);now+=60;assert(mdb_library_watchlist(NULL,0)==0&&calls>seen);
 reset();http=401;assert(mdb_library_watchlist(NULL,0)==0);assert(!strcmp(mdb_library_status(),"MDBList API key rejected"));seen=calls;now+=5000;assert(mdb_library_watchlist(NULL,0)==0&&calls==seen);
 reset();response="{\"movies\":[{\"ids\":{\"imdb\":\"tt123\"}}]}";changeKey=1;assert(mdb_library_watchlist(NULL,0)==0); /* discard old profile reply */
 reset();unsigned job=mdb_library_save("tt123","movie",1);assert(job&&mdb_library_result(job)==1);drain();assert(mdb_library_result(job)==2&&postCalls==1);
 reset();postResponse="{\"added\":0,\"existing\":0,\"not_found\":1}";job=mdb_library_save("tt123","movie",1);drain();assert(mdb_library_result(job)==3);
 reset();postResponse="{\"added\":1,\"existing\":0,\"not_found\":0}";job=mdb_library_save("tt123","movie",1);account++;mdb_library_tick();drain();assert(mdb_library_result(job)==3&&postCalls==0);
 reset();job=mdb_library_save("tmdb:t55","movie",1);assert(mdb_library_result(job)==3&&postCalls==0);
 reset();localDuration=3600;localPos=1200;assert(mdb_library_continue(items,4)==1&&items[0].progresso==33&&items[0].retomadoMs==1&&calls==3);
 localPos=3500;assert(mdb_library_continue(items,4)==0&&calls==3); /* completed local, unchanged cache */
 reset();keyValue="";job=mdb_library_save("tt123","movie",1);assert(mdb_library_result(job)==3&&postCalls==0);
 reset();mdb_library_tick();drain();assert(!strcmp(mdb_library_status(),"MDBList connected"));
 /* Drawing consumes a compact snapshot even while the network/data lock is
    occupied; it does not copy an API key or format identifiers per card. */
 pthread_mutex_lock(&nextLock);nextCount=1;nextGeneration=account;strcpy(nextIds[0],"tt123:2:3");pthread_mutex_unlock(&nextLock);
 seen=calls;lock=1;
 for(int i=0;i<10000;i++){assert(mdb_library_next("tt123:2:3"));assert(!mdb_library_next("tt123:2:4"));}
 lock=0;assert(calls==seen);account++;assert(!mdb_library_next("tt123:2:3"));
 reset();historyResponse="{\"movies\":[{\"last_watched_at\":\"2024-01-01T00:00:00Z\",\"movie\":{\"ids\":{\"imdb\":\"tt0372784\"}}}],\"pagination\":{\"next_cursor\":\"page2\"}}";
 historySecond="{\"episodes\":[{\"last_watched_at\":\"2026-10-08T12:00:00Z\",\"episode\":{\"season\":1,\"number\":1,\"show\":{\"ids\":{\"imdb\":\"tt5875444\"}}}}]}";
 mdb_library_tick();assert(scheduled);drain();assert(historyCalls==2&&postCalls==0&&imported==-1);
 mdb_library_history_tick();assert(imported==2&&!strcmp(importRows[1].id,"tt5875444")&&importRows[1].episodio==1);
 seen=calls;for(int i=0;i<10000;i++){mdb_library_tick();mdb_library_history_tick();}assert(!scheduled&&calls==seen); /* stable idle */
 now+=601;historyHttp=500;mdb_library_tick();drain();mdb_library_history_tick();assert(imported==2); /* page 2 failure retains previous */
 now+=61;historyHttp=200;mdb_library_tick();drain();mdb_library_history_tick();assert(imported==2); /* automatic retry */
 reset();historyResponse="{\"movies\":[],\"pagination\":{\"has_more\":true}}";historySecond="{\"movies\":[],\"pagination\":{\"has_more\":false}}";
 mdb_library_tick();drain();mdb_library_history_tick();assert(imported==0&&historyCalls==2); /* old offset pagination */
 reset();mdb_library_tick();drain();account++;mdb_library_history_tick();assert(imported==-1); /* stale ready snapshot */
 reset();http=429;retry=120;mdb_library_tick();drain();seen=calls;now+=61;mdb_library_tick();assert(!scheduled&&calls==seen);
 reset();historyResponse="{\"movies\":[],\"pagination\":{\"next_cursor\":\"page2\"}}";historySecond=historyResponse;
 mdb_library_tick();drain();mdb_library_history_tick();assert(imported==-1&&historyCalls==2); /* cursor loop fails closed */
 free(items);free(watch);free(historyReady);free(importRows);puts("MDBList library: pagination/dedup, TTL, failure retention, 401/429, account isolation, write confirmation, render snapshot and precise local resume passed");return 0;
}
