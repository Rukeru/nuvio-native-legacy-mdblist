#include "contalib.h"
#include "catalogo.h"
#include "vistoep.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned long long scope=1;
static unsigned titleRev;
static int movie=-1,hidden;
static unsigned writes,filters;
unsigned long long cat_historico_geracao(void){return scope;}
unsigned cat_historico_revisao(void){return titleRev;}
void cat_historico_definir_id(const char *id,const char *type,int state){assert(!strcmp(id,"tt0372784")&&!strcmp(type,"movie"));writes++;if(movie!=state){movie=state;titleRev++;}}
int cat_n(void){return 0;}
const CatItem *cat_item(int i){(void)i;return NULL;}
int cat_indice_por_imdb(const char *id){(void)id;return -1;}
void cat_definir_na_lista(int i,int v){(void)i;(void)v;}
int cat_acrescentar_lote(const CatItem *items,int n,int *indices){(void)items;(void)n;(void)indices;return 0;}
const char *i18n(const char *s){return s;}
const char *idioma_mes_data(int month,const char *s){(void)month;return s;}
static int veto(const char *id,int t,int e,long long at){(void)t;(void)at;filters++;return hidden&&!strcmp(id,"tt5875444")&&e==1;}
int main(void){
 contalib_filtros(NULL,veto);
 assert(contalib_ler_vistos("[{\"content_id\":\"tt0372784\",\"content_type\":\"movie\",\"watched_at\":\"2026-10-08T12:00:00Z\"},{\"content_id\":\"tt5875444\",\"content_type\":\"series\",\"season\":1,\"episode\":1,\"watched_at\":\"2026-10-08T12:00:00Z\"}]")==2);
 /* Real Trakt parser has established 'false' for these episodes. Account
    and MDBList positive evidence still reaches badges and progress counts. */
 assert(vistoep_ler_progresso("tt5875444","{\"seasons\":[{\"number\":1,\"episodes\":[{\"number\":1,\"completed\":false},{\"number\":2,\"completed\":false}]}]}")==2);
 contalib_vistos_tick();assert(movie==1&&vistoep_estado("tt5875444",1,1)==1);
 ContaVisto *mdb=calloc(100,sizeof *mdb);assert(mdb);
 for(int i=0;i<100;i++){strcpy(mdb[i].id,"tt5875444");strcpy(mdb[i].tipo,"series");mdb[i].temporada=2;mdb[i].episodio=i+1;mdb[i].vistoMs=1791460800000LL;}
 contalib_mdb_vistos(mdb,100);unsigned before=filters;contalib_vistos_tick();assert(filters-before==64);
 assert(vistoep_estado("tt5875444",2,100)==-1);contalib_vistos_tick();assert(vistoep_estado("tt5875444",2,100)==1);
 unsigned er=vistoep_revisao();before=filters;unsigned oldWrites=writes;
 for(int i=0;i<10000;i++)contalib_vistos_tick();assert(filters==before&&writes==oldWrites&&vistoep_revisao()==er);
 /* Opening a title can load another provider's incomplete snapshot later. */
 vistoep_definir("tt5875444",2,100,0);contalib_vistos_tick();contalib_vistos_tick();assert(vistoep_estado("tt5875444",2,100)==1);
 hidden=1;vistoep_definir("tt5875444",1,1,0);contalib_vistos_tick();contalib_vistos_tick();assert(vistoep_estado("tt5875444",1,1)==0);
 scope++;movie=-1;titleRev++;contalib_vistos_tick();assert(movie==-1&&vistoep_contar("tt5875444")==0);
 contalib_esquecer();puts("History integration: Nuvio + MDBList with Trakt, actual episode index, movie badge state, bounded batches, stable idle, unwatch veto and profile isolation passed");
}
