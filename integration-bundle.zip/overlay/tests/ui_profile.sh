#!/bin/bash
# Actual GLES2 UI on Linux/Mesa. Counts are comparable; CPU is not a TV FPS prediction.
set -euo pipefail
fixture_root="$(cd "$(dirname "$0")/.." && pwd)"
tree="$(cd "${1:-$fixture_root}" && pwd)"
out="${2:-$tree/build/ui-profile}"
mkdir -p "$out"
out="$(cd "$out" && pwd)"
temp=$(mktemp -d /tmp/nuvio-fluidez-perf-XXXXXX)
trap 'rm -rf "$temp"' EXIT
cd "$tree"
sources=()
for source in src/*.c src/dts/*.c; do
  [ "$source" = src/main.c ] || sources+=("$source")
done
profile_version="preview"
if [ -f src/mdbchangelog_notes.h ]; then
  profile_version=$(sed -n 's/^\/\* Installed-version preview: \(.*\) \*\//\1/p' src/mdbchangelog_notes.h)
  profile_version="${profile_version:-preview}"
fi
cc -DNV_VERSAO="\"$profile_version\"" "${sources[@]}" "$fixture_root/tests/fluidez_perf.c" -Isrc \
  -DNV_LINUX_DESKTOP -DNV_FLUIDEZ_PERF -DNV_PROGRESS_CACHE_EXPERIMENT -DNV_SHOT_HOOKS -DNV_TRAKT_CLIENT_ID='"fixture-only"' \
  -O2 -UNDEBUG -g $(pkg-config --cflags sdl2 SDL2_image SDL2_ttf glesv2 egl zlib) \
  $(pkg-config --libs sdl2 SDL2_image SDL2_ttf glesv2 egl zlib) -pthread -ldl -lm -o "$temp/profile"
if [ "${NV_CHANGELOG_ONLY:-}" = 1 ]; then
  mkdir -p "$temp/changelog"
  LIBGL_ALWAYS_SOFTWARE=1 NUVIO_DADOS="$temp/changelog" \
    NV_PROGRESS_SHOTS="$out/installed" "$temp/profile" > "$out/changelog.txt" 2>&1
  exit 0
fi
for scene in moderna dinamica; do
  mkdir -p "$temp/$scene"
  LIBGL_ALWAYS_SOFTWARE=1 NV_HOME_ONLY=1 NV_PROGRESS_DIRECT=1 NV_CENARIO="$scene" \
  NUVIO_DADOS="$temp/$scene" NUVIO_DUMP_FUNDO_DIR="$temp" \
  NV_PROGRESS_SHOTS="$out/$scene" "$temp/profile" > "$out/home-$scene.txt" 2>&1
  rg '^\[(moderna|dinamica|progress-render)\]' "$out/home-$scene.txt" || true
done
mkdir -p "$temp/cache"
LIBGL_ALWAYS_SOFTWARE=1 NV_HOME_ONLY=1 NV_PROGRESS_ONLY=1 NV_CENARIO=moderna \
NUVIO_DADOS="$temp/cache" NUVIO_DUMP_FUNDO_DIR="$temp" \
NV_PROGRESS_SHOTS="$out/cache-experiment" "$temp/profile" > "$out/progress-cache-experiment.txt" 2>&1
rg '^\[progress-render\]' "$out/progress-cache-experiment.txt" || true
