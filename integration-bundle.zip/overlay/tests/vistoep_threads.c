/* Network history writes may overlap UI reads. Exercise real pthreads. */
#include "vistoep.h"
#include <pthread.h>
#include <assert.h>
#include <stdio.h>
static void *writeHistory(void *unused) {
 (void)unused;
 for(int i=0;i<12000;i++)vistoep_definir("tt0096697",i/100+1,i%100+1,i%2);
 return NULL;
}
int main(void) {
 pthread_t worker;
 vistoep_esquecer();assert(pthread_create(&worker,NULL,writeHistory,NULL)==0);
 VistoPar pairs[]={{1,1},{1,2},{50,10}};signed char states[3];int known;
 for(int i=0;i<12000;i++){
  vistoep_snapshot("tt0096697",pairs,3,states,&known);
  for(int p=0;p<3;p++)assert(states[p]>=-1&&states[p]<=1);
  int n=vistoep_n();assert(n>=0&&n<=8000);
 }
 assert(pthread_join(worker,NULL)==0);assert(vistoep_n()==8000);
 assert(vistoep_estado("tt0096697:1:2",1,2)==1);
 assert(vistoep_estado("tt0096697",1,1)==0);
 unsigned r=vistoep_revisao_titulo("tt0096697");
 vistoep_definir("tt0096697",1,1,0);assert(vistoep_revisao_titulo("tt0096697")==r);
 vistoep_definir("tt0096697",1,1,1);assert(vistoep_revisao_titulo("tt0096697")!=r);
 vistoep_esquecer();assert(vistoep_estado("tt0096697",1,1)==-1);
 vistoep_definir("tt0096697",1,1,1);assert(vistoep_estado("tt0096697",1,1)==1);
 puts("watched index: concurrent map growth, capacity, no-op revisions and reset passed");
 vistoep_esquecer();
}
