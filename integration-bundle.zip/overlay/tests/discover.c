#include "../src/discover.c"
#include <assert.h>
static CatItem data[5];static int resultN,loading,finished,error,requests,pages,menus;
static char requestedType[8],requestedId[96],requestedGenre[48];
unsigned cat_revisao_itens(void){return 1;}
void desc_discover_catalogos(void){}
unsigned addons_versao(void){return 1;}
const char *addons_base(int n){(void)n;return "https://fixture.invalid";}
int desc_vertudo_n(void){return resultN;}
int desc_vertudo_item(int n,CatItem *out){if(n<0||n>=resultN)return 0;*out=data[n];return 1;}
void desc_vertudo_filtro(const char *b,const char *t,const char *id,const char *g){
 (void)b;if(!strcmp(requestedType,t)&&!strcmp(requestedId,id)&&!strcmp(requestedGenre,g))return;
 snprintf(requestedType,sizeof requestedType,"%s",t);snprintf(requestedId,sizeof requestedId,"%s",id);snprintf(requestedGenre,sizeof requestedGenre,"%s",g);requests++;
 resultN=0;loading=1;error=finished=0;
}
int desc_vertudo_corresponde(const char *b,const char *t,const char *id,const char *g){(void)b;return !strcmp(t,requestedType)&&!strcmp(id,requestedId)&&!strcmp(g,requestedGenre);}
int desc_vertudo_carregando(void){return loading;}
int desc_vertudo_fim(void){return finished;}
int desc_vertudo_erro(void){return error;}
void desc_vertudo_mais(void){pages++;loading=1;}
int cat_copiar_por_id(const char *id,const char *type,CatItem *out){(void)id;(void)type;(void)out;return 0;}
int cat_indice_por_imdb(const char *id){return !strcmp(id,"tt0")?0:-1;}
int cat_acrescentar(const CatItem *it){return it->imdb[2]-'0';}
void desc_episodios_garantir(int n){(void)n;}
void menu_abrir(void){menus++;}
static void keypress(SDL_Keycode k){SDL_Event e={0};e.type=SDL_KEYDOWN;e.key.keysym.sym=k;discover_evento(&e);}
static void publish(int n,const char *type){resultN=n;loading=0;for(int i=0;i<n;i++){snprintf(data[i].imdb,sizeof data[i].imdb,"tt%d",i);snprintf(data[i].tipo,sizeof data[i].tipo,"%s",type);}discover_atualizar(0,100);}
int main(void){
 const char *manifest="{\"catalogs\":[{\"type\":\"movie\",\"id\":\"popular\",\"name\":\"Popular\",\"extra\":[{\"name\":\"skip\"},{\"name\":\"genre\",\"options\":[\"Action\",\"Comedy\"]}]},{\"type\":\"series\",\"id\":\"series-popular\",\"extra\":[{\"name\":\"genre\",\"isRequired\":true,\"options\":[\"Action & Adventure\",\"Drama\"]}]},{\"type\":\"movie\",\"id\":\"search\",\"extra\":[{\"name\":\"search\",\"isRequired\":true}]}]}";
 unsigned epoch=dc_catalog_epoch();dc_catalog_manifest(0,1,epoch,manifest,1);
 assert(dc_catalog_count("movie",1)==1&&dc_catalog_count("series",1)==1);
 DiscoverCatalog c;assert(dc_catalog_item("movie",1,0,&c)&&c.skip&&c.nGenres==2);
 discover_esquecer();discover_iniciar();assert(rowCount==1&&genreCount==3&&requests==1&&!count);
 publish(5,"movie");assert(count==5);keypress(SDLK_LEFT);assert(menus==1);
 keypress(SDLK_RIGHT);keypress(SDLK_RIGHT);keypress(SDLK_RETURN);assert(drop==2);
 keypress(SDLK_DOWN);keypress(SDLK_RETURN);assert(!strcmp(requestedGenre,"Action")&&requests==2&&!count);
 publish(2,"movie");keypress(SDLK_DOWN);keypress(SDLK_RETURN);int index=-1;assert(discover_pediu_abrir(&index)&&index==0);
 keypress(SDLK_RIGHT);assert(selected==1);int previous=requests;discover_iniciar();assert(selected==1&&genre==1&&requests==previous);
 keypress(SDLK_UP);keypress(SDLK_LEFT);keypress(SDLK_LEFT);keypress(SDLK_RETURN);keypress(SDLK_ESCAPE);assert(!discover_quer_sair());
 keypress(SDLK_RETURN);keypress(SDLK_DOWN);keypress(SDLK_RETURN);assert(type==1&&genre==1&&!strcmp(requestedGenre,"Action & Adventure"));
 publish(2,"series");assert(!strcmp(featured.tipo,"series"));
 keypress(SDLK_RIGHT);keypress(SDLK_RIGHT);keypress(SDLK_RETURN);keypress(SDLK_UP);assert(cursor==1);keypress(SDLK_ESCAPE);
 discover_esquecer();assert(!count&&!selectedId[0]);dc_catalog_forget();dc_catalog_manifest(0,1,epoch,manifest,1);assert(!dc_catalog_count("movie",1));
 dc_catalog_manifest(0,1,dc_catalog_epoch(),manifest,0);assert(!dc_catalog_count("movie",1));
 assert(!dc_catalog_count("movie",2));
 puts("Discover: real manifest options, required filters, type separation, paging handoff, Back, detail/cache and obsolete profile scope passed");return 0;
}
/* Rendering boundaries are isolated; production navigation/data are above. */
float gfx_tex_aspect_atual;
float ajustes_conteudo_x(void){return 200;}
void ajustes_acento(float *r,float *g,float *b){*r=.5f;*g=.1f;*b=.7f;}
int ajustes_borda_foco(void){return 1;}
int ajustes_vidro(void){return 0;}
int menu_pilula_titulo(void){return 0;}
int desc_montando(void){return 0;}
GLuint tex_obter_hero(const char *url){(void)url;return 0;}
GLuint tex_obter_larg(const char *url,float width){(void)url;(void)width;return 0;}
float tex_aspecto(const char *url){(void)url;return 1;}
void gfx_cor(GfxRect r,float radius,float cr,float cg,float cb,float ca){(void)r;(void)radius;(void)cr;(void)cg;(void)cb;(void)ca;}
void gfx_rect(GfxRect r,GLuint t,GfxModo m,float f,float x,float y,float radius,float cr,float cg,float cb,float ca){(void)r;(void)t;(void)m;(void)f;(void)x;(void)y;(void)radius;(void)cr;(void)cg;(void)cb;(void)ca;}
void gfx_vidro_cartao(GfxRect r,float radius,float f,float a){(void)r;(void)radius;(void)f;(void)a;}
TxtLinha txt_linha_corta(TxtEstilo e,const char *s,int r,int g,int b,int a,float w){(void)e;(void)s;(void)r;(void)g;(void)b;(void)a;(void)w;return (TxtLinha){0};}
void txt_desenhar(TxtLinha l,float x,float y){(void)l;(void)x;(void)y;}
float txt_bloco_corta(TxtEstilo e,const char *s,int r,int g,int b,float x,float y,float w,float leading,float a,int lines){(void)e;(void)s;(void)r;(void)g;(void)b;(void)x;(void)y;(void)w;(void)leading;(void)a;(void)lines;return 0;}
void ponteiro_alvo(float x,float y,float w,float h,PonteiroFn f,PonteiroFn a,int i,int j){(void)x;(void)y;(void)w;(void)h;(void)f;(void)a;(void)i;(void)j;}
void ponteiro_camada(void){}
