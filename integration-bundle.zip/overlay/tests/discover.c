#include "../src/discover.c"
#include <assert.h>
static CatItem data[5];
static CatFileira feeds[3];
static unsigned rev=1;
static int menus;
unsigned cat_revisao(void){return rev;}
int cat_n_fileiras(void){return 3;}
const CatFileira *cat_fileira(int r){return r>=0 && r<3 ? feeds+r : NULL;}
const CatItem *cat_item(int i){return i>=0 && i<5 ? data+i : NULL;}
void menu_abrir(void){menus++;}
static void keypress(SDL_Keycode k){SDL_Event e={0};e.type=SDL_KEYDOWN;e.key.keysym.sym=k;discover_evento(&e);}
int main(void){
  for(int i=0;i<5;i++){snprintf(data[i].imdb,sizeof data[i].imdb,"tt%d",i);strcpy(data[i].tipo,i<3 ? "movie" : "series");}
  strcpy(data[0].genero,"Filme · Action");strcpy(data[1].genero,"Filme · Comedy");strcpy(data[2].genero,"Filme · Action & Adventure");
  strcpy(data[3].genero,"Programa de TV · Action & Adventure");strcpy(data[4].genero,"Programa de TV · Drama");
  for(int i=0;i<3;i++){snprintf(feeds[i].chave,sizeof feeds[i].chave,"feed%d",i);strcpy(feeds[i].base,"https://provider");strcpy(feeds[i].catId,"popular");strcpy(feeds[i].tipo,i<2 ? "movie" : "series");}
  feeds[0].ini=0;feeds[0].n=3;feeds[1].ini=1;feeds[1].n=1;feeds[2].ini=3;feeds[2].n=2;
  discover_esquecer();discover_iniciar();assert(count==3 && rowCount==2 && genreCount==4);
  assert(hasGenre(data[0].genero,"Action") && !hasGenre(data[2].genero,"Action"));
  keypress(SDLK_LEFT);assert(menus==1);
  keypress(SDLK_RIGHT);keypress(SDLK_RIGHT);keypress(SDLK_RETURN);assert(drop==2);
  keypress(SDLK_DOWN);keypress(SDLK_RETURN);assert(drop==-1 && count==1 && genre==1);
  keypress(SDLK_DOWN);keypress(SDLK_RETURN);int index=-1;assert(discover_pediu_abrir(&index) && index==0);assert(!discover_pediu_abrir(&index));
  discover_iniciar();assert(count==1 && selected==0 && genre==1);
  keypress(SDLK_UP);keypress(SDLK_LEFT);keypress(SDLK_LEFT);keypress(SDLK_RETURN);assert(drop==0);
  keypress(SDLK_ESCAPE);assert(drop==-1 && !discover_quer_sair());
  keypress(SDLK_RETURN);keypress(SDLK_DOWN);keypress(SDLK_RETURN);assert(type==1 && rowCount==1 && count==2);
  assert(!strcmp(genres[1],"Action & Adventure"));
  keypress(SDLK_DOWN);keypress(SDLK_RIGHT);assert(selected==1);remember();
  rev++;discover_atualizar(0,0);assert(selected==1);
  strcpy(data[3].imdb,"tt4");rev++;discover_atualizar(0,0);assert(count==1);
  feeds[2].n=0;rev++;discover_atualizar(0,0);assert(!count);keypress(SDLK_RETURN);assert(!discover_pediu_abrir(&index));
  keypress(SDLK_ESCAPE);assert(discover_quer_sair());
  discover_esquecer();assert(type==0 && !count && !key[0] && !selectedId[0]);
  puts("discover: filters, type separation, focus, Back, detail return, revisions and isolation passed");
  return 0;
}

/* Rendering boundaries are isolated; production navigation/data are above. */
float gfx_tex_aspect_atual;
float ajustes_conteudo_x(void){return 200;}
void ajustes_acento(float *r,float *g,float *b){*r=.5f;*g=.1f;*b=.7f;}
int ajustes_borda_foco(void){return 1;}
int ajustes_vidro(void){return 0;}
int menu_pilula_titulo(void){return 0;}
int desc_montando(void){return 0;}
GLuint tex_obter_hero(const char *url){(void)url;return 0;}
GLuint tex_obter_larg(const char *url,float width){(void)url;(void)width;return 0;}
float tex_aspecto(const char *url){(void)url;return 1;}
void gfx_cor(GfxRect r,float radius,float cr,float cg,float cb,float ca){(void)r;(void)radius;(void)cr;(void)cg;(void)cb;(void)ca;}
void gfx_rect(GfxRect r,GLuint t,GfxModo m,float f,float x,float y,float radius,float cr,float cg,float cb,float ca){(void)r;(void)t;(void)m;(void)f;(void)x;(void)y;(void)radius;(void)cr;(void)cg;(void)cb;(void)ca;}
void gfx_vidro_cartao(GfxRect r,float radius,float f,float a){(void)r;(void)radius;(void)f;(void)a;}
TxtLinha txt_linha_corta(TxtEstilo e,const char *s,int r,int g,int b,int a,float w){(void)e;(void)s;(void)r;(void)g;(void)b;(void)a;(void)w;return (TxtLinha){0};}
void txt_desenhar(TxtLinha l,float x,float y){(void)l;(void)x;(void)y;}
float txt_bloco_corta(TxtEstilo e,const char *s,int r,int g,int b,float x,float y,float w,float leading,float a,int lines){(void)e;(void)s;(void)r;(void)g;(void)b;(void)x;(void)y;(void)w;(void)leading;(void)a;(void)lines;return 0;}
void ponteiro_alvo(float x,float y,float w,float h,PonteiroFn f,PonteiroFn a,int i,int j){(void)x;(void)y;(void)w;(void)h;(void)f;(void)a;(void)i;(void)j;}
void ponteiro_camada(void){}
