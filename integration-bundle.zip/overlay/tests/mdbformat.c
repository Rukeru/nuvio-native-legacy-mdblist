#include "mdbformat.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void) {
 MdbItem items[8];char cursor[64],body[180];int more;
 assert(mdb_watchlist_body(body,sizeof body,"tt123","series"));assert(!strcmp(body,"{\"shows\":[{\"ids\":{\"imdb\":\"tt123\"}}]}"));
 assert(mdb_watchlist_body(body,sizeof body,"tmdb:m123","movie"));
 assert(!mdb_watchlist_body(body,sizeof body,"tmdb:t123","movie"));
 assert(!mdb_watchlist_body(body,sizeof body,"tt123:1:2","series"));
 assert(!mdb_watchlist_body(body,sizeof body,"tt123\"","movie"));
 assert(!mdb_watchlist_body(body,4,"tt123","movie"));
 assert(!mdb_watchlist_body(NULL,0,"tt123","movie"));
 int n=mdb_parse_watchlist("{\"movies\":[{\"id\":9,\"title\":\"Unknown external id\"},{\"ids\":{\"imdb\":\"tt123\"},\"title\":\"Film\"}],\"shows\":[{\"ids\":{\"tmdb\":55},\"title\":\"Show\"}],\"pagination\":{\"next_cursor\":\"page2\"}}",items,8,cursor,sizeof cursor);
 assert(n==2&&!strcmp(items[0].id,"tt123")&&!strcmp(items[1].id,"tmdb:t55")&&!strcmp(cursor,"page2"));
 assert(mdb_parse_watchlist("{\"error\":\"unauthorized\"}",items,8,cursor,sizeof cursor)<0);
 assert(mdb_parse_watchlist("{\"movies\":[{\"ids\":{\"imdb\":\"tt123\"}}]",items,8,cursor,sizeof cursor)<0);
 assert(mdb_parse_playback("[{\"type\":\"movie\",\"progress\":20,\"movie\":{\"ids\":{\"imdb\":\"tt123\"}}}",items,8)<0);
 assert(mdb_parse_watchlist("{\"movies\":[],\"shows\":[],\"pagination\":{\"next_cursor\":null}}",items,8,cursor,sizeof cursor)==0&&!cursor[0]);
 n=mdb_parse_playback(" [{\"type\":\"movie\",\"progress\":35.5,\"runtime\":100,\"movie\":{\"ids\":{\"imdb\":\"tt123\"}},\"paused_at\":\"2026-10-08T01:00:00Z\"},{\"type\":\"episode\",\"progress\":25,\"show\":{\"ids\":{\"tmdb\":55}},\"episode\":{\"season\":0,\"number\":2}}, {\"type\":\"movie\",\"progress\":80,\"movie\":{\"ids\":{\"imdb\":\"tt999\"}}}, {\"type\":\"movie\",\"progress\":\"20\",\"movie\":{\"ids\":{\"imdb\":\"tt777\"}}} ]",items,8);
 assert(n==2&&items[0].progress==35.5&&items[0].runtime==100&&items[0].updated>0&&items[1].season==0&&items[1].episode==2&&items[1].runtime==0);
 assert(mdb_parse_playback("[{\"type\":\"episode\",\"progress\":30,\"episode\":{\"ids\":{\"imdb\":\"tt777\"},\"season\":1,\"number\":2}}]",items,8)==0);
 assert(mdb_parse_playback("{\"error\":\"failed\"}",items,8)<0);
 n=mdb_parse_next("{\"items\":[{\"show\":{\"ids\":{\"imdb\":\"tt123\"}},\"next_episode\":{\"season\":1,\"number\":3,\"air_date\":\"2026-10-01T20:00:00Z\"}}],\"has_more\":true}",items,8,&more);
 assert(n==1&&more&&items[0].next&&items[0].progress==0&&items[0].episode==3&&items[0].air>0);
 items[0].updated=1;
 assert(mdb_filter_watched("{\"episodes\":[{\"show\":{\"ids\":{\"imdb\":\"tt123\"}},\"episode\":{\"season\":1,\"number\":2},\"watched_at\":\"2026-10-08T01:00:00Z\"}]}",items,n,cursor,sizeof cursor)==1);
 assert(mdb_filter_watched("{\"episodes\":[{\"show\":{\"ids\":{\"imdb\":\"tt123\"}},\"episode\":{\"season\":1,\"number\":3},\"watched_at\":\"2026-10-08T01:00:00Z\"}]}",items,n,cursor,sizeof cursor)==0);
 puts("MDBList format: typed identities, cursor pages, paused percentages, numbering and exact watched exclusion passed");
 return 0;
}
