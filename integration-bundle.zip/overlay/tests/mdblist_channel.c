#include "mdblistchannel.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
  assert(mdblist_channel_asset(NV_MDBLIST_DOWNLOAD_PREFIX "v2.0.3.1/libnuvio-2.0.3.1" NV_MDBLIST_SO_SUFFIX));
  assert(!mdblist_channel_asset(NULL));
  assert(!mdblist_channel_asset("https://github.com/iqui27/nuvio-native-legacy/releases/download/v2.0.3/libnuvio-2.0.3-tpk-arm.so"));
  assert(!mdblist_channel_asset(NV_MDBLIST_DOWNLOAD_PREFIX "v2.0.3/libnuvio-2.0.3-tpk-arm.so"));
  assert(!mdblist_channel_asset("https://github.com/attacker/nuvio-native-legacy-mdblist/releases/download/v2.0.3/libnuvio-2.0.3-mdblist-tpk-arm.so"));
  assert(!mdblist_channel_asset(NV_MDBLIST_DOWNLOAD_PREFIX "/libnuvio-2.0.3-mdblist-tpk-arm.so"));
  assert(!mdblist_channel_asset(NV_MDBLIST_DOWNLOAD_PREFIX "v2.0.3/subdir/libnuvio-2.0.3-mdblist-tpk-arm.so"));
  assert(!mdblist_channel_asset(NV_MDBLIST_DOWNLOAD_PREFIX "v2.0.3/libnuvio-2.0.3-mdblist-tpk-arm.so?download=1"));
  puts("MDBList update channel asset isolation: PASS");
  return 0;
}
