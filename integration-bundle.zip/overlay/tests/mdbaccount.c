#include "mdbaccount.h"
#include "js.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static int row(const char *json, char *key, size_t n) {
  return mdb_account_credential(json, json + strlen(json), key, n);
}
int main(void) {
  char key[80] = "previous";
  assert(row("{\"provider\":\"mdblist\",\"credential_json\":{\"api_key\":\"fixture_key\"}}", key, sizeof key) == 1);
  assert(!strcmp(key, "fixture_key"));
  const char *serialized = "{\"provider\":\"mdblist\",\"credential_json\":\"{\\\"api_key\\\":\\\"fixture_key\\\"}\"}";
  /* Reproduce the old reader's failure with the documented string format. */
  char raw[256], old[80] = "previous";
  assert(js_bruto(serialized, NULL, "credential_json", raw, sizeof raw));
  assert(!js_texto(raw, NULL, "api_key", old, sizeof old));
  assert(row(serialized, key, sizeof key) == 1 && !strcmp(key, "fixture_key"));
  assert(row("{\"provider\":\" MDBList \",\"credentialJson\":\"{\\\"api_key\\\":\\\"  spaced_key  \\\"}\"}", key, sizeof key) == 1);
  assert(!strcmp(key, "spaced_key"));
  assert(row("{\"provider\":\"torbox\",\"credential_json\":{\"api_key\":\"other\"}}", key, sizeof key) == 0);
  assert(!strcmp(key, "spaced_key"));
  assert(row("{\"provider\":\"mdblist\",\"credential_json\":{\"nested\":{\"api_key\":\"wrong\"}}}", key, sizeof key) == -1);
  assert(row("{\"provider\":\"mdblist\",\"credential_json\":{\"api_key\":123}}", key, sizeof key) == -1);
  assert(row("{\"provider\":\"mdblist\",\"credential_json\":\"{\\\"api_key\\\":\\\"cut\\\"\"}", key, sizeof key) == -1);
  assert(row("{\"provider\":\"mdblist\",\"credential_json\":{\"api_key\":\"bad&key\"}}", key, sizeof key) == -1);
  assert(row("{\"provider\":\"mdblist\",\"credential_json\":{\"api_key\":\"key\\u0000tail\"}}", key, sizeof key) == -1);
  assert(!strcmp(key, "spaced_key"));
  assert(row("{\"provider\":\"mdblist\",\"credential_json\":{\"api_key\":\"too_long\"}}", key, 4) == -1);
  char longrow[256];
  snprintf(longrow, sizeof longrow, "{\"provider\":\"mdblist\",\"credential_json\":{\"api_key\":\"%080d\"}}", 1);
  assert(row(longrow, key, sizeof key) == -1 && !strcmp(key, "spaced_key"));
  assert(row("{\"provider\":\"mdblist\",\"credential_json\":{\"api_key\":\"\"}}", key, sizeof key) == 1 && !key[0]);

  const char *typed = "{\"version\":1,\"features\":{\"mdblist_settings\":{\"mdblist_api_key\":{\"type\":\"string\",\"value\":\"profile_key\"}}}}";
  assert(mdb_account_settings(typed, key, sizeof key) == 1 && !strcmp(key, "profile_key"));
  assert(mdb_account_settings("{\"mdblist_settings\":{\"mdblist_api_key\":\"direct_key\"}}", key, sizeof key) == 1 && !strcmp(key, "direct_key"));
  assert(mdb_account_settings("{\"mdblist_api_key\":\"flat_key\"}", key, sizeof key) == 1 && !strcmp(key, "flat_key"));
  assert(mdb_account_settings("{\"features\":{\"other\":{\"mdblist_api_key\":\"wrong\"}}}", key, sizeof key) == 0 && !strcmp(key, "flat_key"));
  assert(mdb_account_settings("{\"features\":{\"mdblist_settings\":{\"mdblist_api_key\":{\"type\":\"string\",\"value\":null}}}}", key, sizeof key) == -1);
  assert(mdb_account_settings("{\"mdblist_api_key\":\"cut\"", key, sizeof key) == -1);
  assert(!strcmp(key, "flat_key"));
  assert(mdb_account_profile_reply("[{\"settings_json\":{\"features\":{\"mdblist_settings\":{\"mdblist_api_key\":\"rpc_key\"}}}}]", key, sizeof key) == 1 && !strcmp(key, "rpc_key"));
  assert(mdb_account_profile_reply("[{\"settings_json\":\"{\\\"features\\\":{\\\"mdblist_settings\\\":{\\\"mdblist_api_key\\\":{\\\"type\\\":\\\"string\\\",\\\"value\\\":\\\"serialized_profile_key\\\"}}}}\"}]", key, sizeof key) == 1);
  assert(!strcmp(key, "serialized_profile_key"));
  assert(mdb_account_profile_reply("[]", key, sizeof key) == 0);
  assert(mdb_account_profile_reply("[{\"settings_json\":{\"mdblist_api_key\":\"truncated\"}}", key, sizeof key) == -1);
  assert(mdb_account_profile_reply("[{\"settings_json\":null}]", key, sizeof key) == -1);
  assert(!strcmp(key, "serialized_profile_key"));
  assert(mdb_account_settings("{\"mdblist_api_key\":\"\"}", key, sizeof key) == 1 && !key[0]);
  puts("MDBList account key: object/string credentials, typed/serialized profile settings, isolation, explicit removal and no truncation: PASS");
  return 0;
}
