#ifndef NV_MDBLIST_H
#define NV_MDBLIST_H
/* Playback writes only. Ratings and their master switch remain in extras.c. */
void mdblist_definir_chave(const char *chave);
/* Main loop: apply profile/consent changes and service deferred retries. */
void mdblist_atualizar(int ligado, int perfil);
int mdblist_scrobble(int evento, const char *id, double posSeg, double durSeg);
const char *mdblist_estado(void); /* Portuguese i18n key, no credential material */
#endif
