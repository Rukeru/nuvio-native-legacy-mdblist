#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
cc -std=gnu11 -UNDEBUG -DSDL_MAIN_HANDLED -Wall -Wextra -Isrc -I"$(sdl2-config --prefix)/include" $(sdl2-config --cflags) tests/profilestats.c src/profilestats.c src/js.c src/mdbformat.c -lm -o "$tmp/stats"
"$tmp/stats"
