/* Actual native GLES/font/artwork path, using clearly synthetic test content. */
#include "discover.h"
#include "menu.h"
#include "discover_catalog.h"
#include "addons.h"
#include "profilestats.h"
#include "ajustes.h"
#include "dados.h"
#include "gfx.h"
#include "text.h"
#include "tex_cache.h"
#include "perfil.h"
#include "ponteiro.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void save(const char *out,int scene){
 unsigned char *pixels=malloc(1920*1080*4);assert(pixels);
 SDL_Surface *surface=SDL_CreateRGBSurfaceWithFormat(0,1920,1080,32,SDL_PIXELFORMAT_RGBA32);assert(surface);
 glReadPixels(0,0,1920,1080,GL_RGBA,GL_UNSIGNED_BYTE,pixels);assert(glGetError()==GL_NO_ERROR);
 unsigned bright=0;for(int y=0;y<1080;y++){memcpy((char *)surface->pixels+y*surface->pitch,pixels+(1079-y)*1920*4,1920*4);}
 for(int i=0;i<1920*1080;i++)if(pixels[i*4]>40||pixels[i*4+1]>40||pixels[i*4+2]>40)bright++;
 assert(bright>10000);char path[1024];snprintf(path,sizeof path,"%s/native-%d.png",out,scene);assert(IMG_SavePNG(surface,path)==0);SDL_FreeSurface(surface);free(pixels);
}
static void press(SDL_Keycode key){SDL_Event e={0};e.type=SDL_KEYDOWN;e.key.keysym.sym=key;discover_evento(&e);}
int main(int argc,char **argv){
 assert(argc==2);assert(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_TIMER)==0);IMG_Init(IMG_INIT_PNG);
 SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION,2);
#ifdef NV_LINUX_DESKTOP
 SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION,0);SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,SDL_GL_CONTEXT_PROFILE_ES);
#else
 SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION,1);
#endif
 SDL_Window *window=SDL_CreateWindow("Native Discover fixture",0,0,1920,1080,SDL_WINDOW_OPENGL|SDL_WINDOW_HIDDEN);assert(window);assert(SDL_GL_CreateContext(window));
 glViewport(0,0,1920,1080);gfx_tamanho_alvo(1920,1080);assert(gfx_iniciar());gfx_snap_iniciar(960,540);gfx_borrao_iniciar(480,270);assert(txt_iniciar("deploy/app",1));tex_iniciar(64);ponteiro_iniciar();
 dados_iniciar("deploy/app/art");ajustes_dir(dados_dir());assert(ajustes_shot_valor("selected_theme",2));assert(ajustes_shot_valor("homeLayoutLocal",0));
 SDL_Surface *art=SDL_CreateRGBSurfaceWithFormat(0,1920,700,32,SDL_PIXELFORMAT_RGBA32);assert(art);
 for(int y=0;y<700;y++)for(int x=0;x<1920;x++)((Uint32 *)((char *)art->pixels+y*art->pitch))[x]=SDL_MapRGBA(art->format,(Uint8)(20+x/16),(Uint8)(35+y/5),(Uint8)(70+x/20),255);
 char file[1024];snprintf(file,sizeof file,"%s/fixture.bmp",argv[1]);assert(SDL_SaveBMP(art,file)==0);SDL_FreeSurface(art);
 const char *manifest="{\"catalogs\":[{\"type\":\"movie\",\"id\":\"popular\",\"name\":\"Popular\",\"extra\":[{\"name\":\"genre\",\"options\":[\"Action\",\"Adventure\",\"Animation\",\"Comedy\",\"Crime\",\"Documentary\",\"Drama\",\"Family\"]}]},{\"type\":\"movie\",\"id\":\"trending\",\"name\":\"Trending\"}]}";
 dc_catalog_manifest(0,addons_versao(),dc_catalog_epoch(),manifest,1);
 CatItem items[20]={0};for(int i=0;i<20;i++){snprintf(items[i].imdb,sizeof items[i].imdb,"tt%d",i);strcpy(items[i].tipo,"movie");snprintf(items[i].titulo,sizeof items[i].titulo,"Native rendering fixture %d",i+1);snprintf(items[i].backdrop,sizeof items[i].backdrop,"%.511s",file);snprintf(items[i].poster,sizeof items[i].poster,"%.1023s",file);strcpy(items[i].genero,"Drama · Mystery");strcpy(items[i].meta,"2026 · 1h 48m");strcpy(items[i].classificacao,"PG-13");strcpy(items[i].sinopse,"Synthetic content for checking native text, artwork, filter chips and collection grid layout. This fixture contains no account data.");items[i].nElenco=3;for(int j=0;j<3;j++)snprintf(items[i].elenco[j].nome,sizeof items[i].elenco[j].nome,"Fixture actor %d",j+1);items[i].nota=83;}
 for(int scene=0;scene<4;scene++){
  discover_shot_seed(items,20);if(scene){for(int j=1;j<scene;j++)press(SDLK_RIGHT);press(SDLK_RETURN);}
  for(int frame=0;frame<30;frame++){SDL_PumpEvents();tex_bombear(4);txt_novo_quadro();tex_novo_quadro();gfx_novo_quadro();gfx_sem_recorte();glClear(GL_COLOR_BUFFER_BIT);discover_desenhar(frame*16);glFinish();SDL_Delay(10);}
  save(argv[1],scene);
 }
 PerfilDados profile={0};strcpy(profile.nome,"Synthetic profile");strcpy(profile.periodo,"2026-10 · partial");strcpy(profile.aviso,"Nuvio + MDBList · partial unique-item history · watch time unknown");profile.plays=12;profile.filmes=4;profile.episodios=8;profile.parcial=profile.uniqueItems=profile.timeUnknown=1;profile.sourcesMask=6;profile.nDias=34;profile.primeiroDiaSemana=4;profile.atividade[12]=2;profile.atividade[13]=3;profile.diasAtivosMes=2;
 perfil_iniciar();perfil_abrir();perfil_definir_dados(&profile);
 for(int frame=0;frame<40;frame++){SDL_PumpEvents();txt_novo_quadro();tex_novo_quadro();gfx_novo_quadro();gfx_sem_recorte();glClear(GL_COLOR_BUFFER_BIT);perfil_atualizar(.016f,frame*16);perfil_desenhar(frame*16);glFinish();}
 save(argv[1],4);
 Uint64 cost=0;
 for(int scene=5;scene<=8;scene++) {
  assert(ajustes_shot_valor("homeLayoutLocal",scene==7?1:0));
  gfx_escala_ui_definir(scene==7?1.25f:1);
  discover_shot_seed(items,20);discover_shot_focus(scene==6?6:1,scene==6?432:0);
  if(scene==8){menu_iniciar();menu_definir_destino(MENU_DISCOVER);menu_abrir_sobre(1);}
  for(int frame=0;frame<45;frame++) {
   SDL_PumpEvents();tex_bombear(4);txt_novo_quadro();tex_novo_quadro();gfx_novo_quadro();gfx_sem_recorte();glClear(GL_COLOR_BUFFER_BIT);
   Uint64 start=SDL_GetPerformanceCounter();discover_desenhar(frame*16);
   if(scene==8){menu_atualizar(.016f,frame*16);menu_desenhar(frame*16);}
   glFinish();if(frame>=15)cost+=SDL_GetPerformanceCounter()-start;
  }
  save(argv[1],scene);if(scene==8)menu_fechar();
 }
 printf("Discover warmed native draw average: %.2f ms (120 frames, including software GLES finish)\n",1000.0*cost/SDL_GetPerformanceFrequency()/120);
 puts("Actual GLES2 Discover/filter menus and partial-profile render snapshots passed");return 0;
}
