/* Link without network, file, formatter or pthread providers: disabled builds
 * cannot accidentally create a worker, store events or send an HTTP request. */
#include "../src/nvdiag.c"
#include "../src/nvdiag_observe.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
  NvDiagStatus status;char preview[32]="must clear";int side_effect=0;
  nvdiag_init();
  nvdiag_consent(1);
  nvdiag_event(NVD_MDB_AUTH,401,0);
  nvdiag_observe(NVD_SYNC_FAILED,500,0);
  NVD_NOTE(NVD_SYNC_FAILED,++side_effect,0);
  assert(side_effect==0);
  for(int i=0;i<10000;i++)nvdiag_performance(999,1024);
  assert(!nvdiag_pair("0123456789abcdef0123456789abcdef"));
  nvdiag_preview();assert(!nvdiag_preview_copy(preview,sizeof preview));assert(!preview[0]);
  assert(!nvdiag_send());nvdiag_status(&status);
  assert(!status.ready&&!status.paired&&!status.consent&&!status.asked);
  assert(!status.queued&&!status.preview_ready&&!status.pairing&&!status.receipt[0]);
  nvdiag_shutdown();
  puts("PASS disabled diagnostics: no event collection, worker, files, consent, pairing or uploads");
  return 0;
}
