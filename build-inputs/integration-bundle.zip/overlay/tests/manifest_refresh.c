#include "descoberta.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static unsigned long long now=1000;
int refresh_clock_gettime(clockid_t id,struct timespec *t){(void)id;t->tv_sec=now/1000;t->tv_nsec=(now%1000)*1000000;return 0;}
static void expect(const char *wanted){char *s=desc_manifesto_cache_obter("https://synthetic/manifest.json",7);assert(s&&!strcmp(s,wanted));free(s);}
int main(void){
 const char *url="https://synthetic/manifest.json";
 desc_manifesto_cache_guardar(url,7,"{\"id\":\"old\"}");expect("{\"id\":\"old\"}");
 now+=299999;expect("{\"id\":\"old\"}");now++;
 assert(!desc_manifesto_cache_obter(url,7));
 char *s=desc_manifesto_cache_reserva(url,7);assert(s&&strstr(s,"old"));free(s);
 unsigned g=desc_manifesto_cache_geracao();desc_manifesto_cache_invalidar();
 desc_manifesto_cache_guardar_geracao(url,7,"late old response",g);
 assert(!desc_manifesto_cache_obter(url,7));
 s=desc_manifesto_cache_reserva(url,7);assert(s&&strstr(s,"old"));free(s);
 desc_manifesto_cache_guardar_geracao(url,7,"{\"id\":\"changed\"}",desc_manifesto_cache_geracao());
 expect("{\"id\":\"changed\"}");
 assert(!desc_manifesto_cache_reserva(url,8)); /* No cross-addon-list fallback. */
 unsigned fail=0,cached=0;desc_manifesto_cache_estado(&fail,&cached);assert(fail==2&&cached==1);
 puts("Manifest refresh: TTL, same-URL replacement, failure fallback and obsolete-request protection passed");
 return 0;
}
