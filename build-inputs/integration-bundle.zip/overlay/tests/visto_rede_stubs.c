// Weak fallbacks for tests/visto.sh. Since v2.0.7, src/trakt.c and src/simkl.c
// fetch through provedorhttp.h (rede_pedir with a rede_baixar_st_retry
// fallback), which tests/visto.c does not stub. The strict API reports itself
// unavailable so every request reaches the fixture's rede_baixar_st counter.
#include <stdlib.h>
#include <string.h>
#include "rede.h"
#define W __attribute__((weak))

W int rede_pedir(const RedePedido *p, RedeResposta *r) {
  (void)p; memset(r, 0, sizeof *r); r->erro = REDE_INDISPONIVEL; return 0;
}
W void rede_resposta_limpar(RedeResposta *r) {
  if (!r) return;
  free(r->corpo); free(r->cabecalhos); r->corpo = NULL; r->cabecalhos = NULL;
}
W char *rede_baixar_st_retry(const char *url, int segundos, const char *const *cabecalhos,
                             int *status, int *retry_after) {
  if (retry_after) *retry_after = 0;
  return rede_baixar_st(url, segundos, cabecalhos, status);
}
