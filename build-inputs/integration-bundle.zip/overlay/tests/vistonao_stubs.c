// Weak fallbacks for tests/vistonao.sh. The fork's account-history scope in
// src/contalib.c reads the catalog's history generation/revision and the
// library source setting, which live in catalogo.c and ajustes.c and are not
// linked here. A fixed scope (no catalog reloads) and the default library
// source match the fixture's single-profile run.
#define W __attribute__((weak))

W unsigned long long cat_historico_geracao(void) { return 1; }
W unsigned cat_historico_revisao(void) { return 0; }
W int ajustes_fonte_biblioteca(void) { return 0; }
