// Weak fallbacks for symbols that upstream descoberta.c/catalogo.c reference
// but the isolated discovery fixtures do not provide. Linux links tolerate the
// gaps; macOS does not. A fixture that defines one of these keeps its own.
#include <stddef.h>
#include <stdint.h>

#define W __attribute__((weak))

W int  addons_identidade_recebida(const char *b, unsigned v, uint64_t s, const char *c) {
  (void)b; (void)v; (void)s; (void)c; return 1; }
W int  addons_manifesto_recebido(const char *b, unsigned v, uint64_t s, const char *c) {
  (void)b; (void)v; (void)s; (void)c; return 1; }
W void addons_lista_travar(void) {}
W void addons_lista_destravar(void) {}
W int  ajustes_fonte_biblioteca(void) { return 0; }
W int  ajustes_nota_episodio(int fonte) { (void)fonte; return 0; }
W int  ajustes_ocultar_nao_lancados(void) { return 0; }
W int  ajustes_tmdb_elenco(void) { return 0; }
W int  cat_gravar_cache_se_sessao(const char *d, const char *dono, int perfil, uint64_t s) {
  (void)d; (void)dono; (void)perfil; (void)s; return 0; }
W int  cat_indice_por_imdb_tipo(const char *imdb, const char *tipo) {
  (void)imdb; (void)tipo; return -1; }
W char *rede_baixar_st(const char *url, int t, const char *const *cab, int *status) {
  (void)url; (void)t; (void)cab; if (status) *status = 0; return NULL; }
