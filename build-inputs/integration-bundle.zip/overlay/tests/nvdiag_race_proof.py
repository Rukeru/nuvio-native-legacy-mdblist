"""Negative control: the real fixture must reject the former unlocked reservation."""
from pathlib import Path
import json,signal,subprocess,sys,tempfile
root=Path(__file__).resolve().parent.parent
platform=sys.argv[1]
assert platform in ('NV_TPK','NV_WEBOS')
source=(root/'src/nvdiag.c').read_text()
fixed=""" queue[index].attempts++;queue[index].next=time(NULL)+nvdiag_backoff(queue[index].attempts,0);
 pthread_mutex_unlock(&mu);"""
assert source.count(fixed)==1
broken=source.replace(fixed,""" pthread_mutex_unlock(&mu);
 queue[index].attempts++;queue[index].next=time(NULL)+nvdiag_backoff(queue[index].attempts,0);""")
with tempfile.TemporaryDirectory() as temp:
    d=Path(temp);(d/'unlocked.c').write_text(broken)
    fixture=(root/'tests/nvdiag.c').read_text().replace('#include "../src/nvdiag.c"','#include '+json.dumps(str(d/'unlocked.c')))
    (d/'fixture.c').write_text(fixture)
    binary=d/'negative-control'
    subprocess.run(['cc','-std=gnu11','-O1','-UNDEBUG','-Isrc','-D'+platform,'-DNV_DIAG_VERIFIED=1',
                    '-DNV_VERSAO="2.0.4.64"','-DNV_DIAG_BUILD="0123456789abcdef0123456789abcdef01234567"',
                    str(d/'fixture.c'),'src/nvdiag_format.c','src/js.c','-pthread','-o',str(binary)],cwd=root,check=True)
    result=subprocess.run([str(binary)],capture_output=True,text=True)
    assert result.returncode == -signal.SIGABRT, result.stderr
    assert 'locked==EBUSY' in result.stderr.replace(' ',''), result.stderr
    print('PASS negative control: unlocked retry reservation is rejected ('+platform+')')
