// Weak fallbacks for the cwremover_home half of tests/cwremover.sh. Since
// v2.0.7, src/home.c and ajustes_aplicar_blob reach scale, provider, player
// and account modules that this isolated fixture does not link. -dead_strip
// cannot drop them because the fixture calls ajustes_aplicar_blob, and Mach-O
// rejects the undefined references. The values follow src/gfx.c's defaults
// (scale 1) and "nothing connected" everywhere else.
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#define W __attribute__((weak))

W float gfx_escala(void) { return 1.0f; }
W float gfx_escala_txt(void) { return 1.0f; }
W float gfx_escala_tela_txt(void) { return 1.0f; }
W float gfx_poster_k(void) { return 1.0f; }
W float gfx_escala_txt_entrar(void) { return 1.0f; }
W void  gfx_escala_sair(float anterior) { (void)anterior; }
W void  gfx_escala_txt_definir(float s) { (void)s; }
W void  gfx_escala_ui_definir(float s) { (void)s; }
W void  txt_definir_fonte_interface(int familia) { (void)familia; }

W const char *dados_dir(void) { const char *t = getenv("TMPDIR"); return t && *t ? t : "/tmp"; }
W const char *dados_aparelho_id(void) { return "cwremover-home"; }
W void dados_fs_travar(void) {}
W void dados_fs_liberar(void) {}
W const char *sessao_usuario(void) { return ""; }
W int  perfis_ativo_addons(void) { return 1; }
W int  contalib_tem_conta(void) { return 0; }
W int  trakt_ativo(void) { return 0; }
W int  simkl_ativo(void) { return 0; }
W void sync_proteger_ajustes_locais(void) {}
W int  nf_na_posicao_ord(int pos, int letterFirst) { (void)letterFirst; return pos; }

W void arte_fonte_chave_fanart(const char *chave) { (void)chave; }
W void audiomem_definir_perfil(int perfil) { (void)perfil; }
W void legmem_definir_perfil(int perfil) { (void)perfil; }
W void fontepref_definir_perfil(int perfil) { (void)perfil; }
W void ltv_pref_carregar(int perfil) { (void)perfil; }
W void ltv_urls_carregar(int perfil) { (void)perfil; }
W void ling_local_audio(const char *v) { (void)v; }
W void ling_local_audio2(const char *v) { (void)v; }
W void ling_local_legenda(const char *v) { (void)v; }
W void ling_local_legenda2(const char *v) { (void)v; }
W const char *ling_opcao_codigo(int i) { (void)i; return ""; }

W void debrid_conta_iniciar(void *conta) { (void)conta; }
W void debrid_conta_definir(void *conta, const char *servico, const char *chave) { (void)conta; (void)servico; (void)chave; }
W void debrid_aplicar_chaves_locais(const void *conta) { (void)conta; }
W void seekr_chave_propria(int propria) { (void)propria; }
W void seekr_definir_chave(const char *chave) { (void)chave; }
W void fontefalha_config_ler(void) {}
W int  fontefalha_addons(void) { return 0; }
W int  fontefalha_provedores(void) { return 0; }
W int  fontefalha_arquivo(const char *arquivo) { (void)arquivo; return 0; }
W int  fontefalha_addon_limite(const char *chave) { (void)chave; return 0; }
W int  fontefalha_provedor_limite(int servico) { (void)servico; return 0; }
W void fontefalha_filtro(void *saida) { (void)saida; }
W int  iptv_contas(void *out, int max) { (void)out; (void)max; return 0; }
W int  p2p_normalizar_url(const char *entrada, char *out, unsigned n) {
  if (!entrada || !out || !n || strlen(entrada) >= n) return 0;
  memcpy(out, entrada, strlen(entrada) + 1);
  return 1;
}

// The subtitle style is a struct this fixture never inspects; zeroed storage
// is enough for ajustes.c to read and write it.
static _Alignas(16) unsigned char legEstilo[4096];
W void *player_leg_estilo(void) { return legEstilo; }
W void  player_leg_estilo_carregar(void) {}
W int   player_leg_estilo_definir(const void *estilo, int tocou) { (void)estilo; (void)tocou; return 0; }
W void  player_dir(const char *dir) { (void)dir; }

W void stalker_carregar(void) {}
W void xtream_carregar(void) {}
W void jellyfin_carregar(void) {}
W void emby_carregar(void) {}
W void plex_carregar(void) {}
W void discord_recarregar(void) {}
W void selospacote_recarregar(void) {}
W void sorg_recarregar(void) {}
W void plugins_iniciar(void) {}
W void lst_iniciar(void) {}
