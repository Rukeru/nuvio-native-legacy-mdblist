// Weak fallbacks for isolated sync, manifest and Seekr fixtures. Since v2.0.7,
// sync.c toggles account add-ons, fileiras.c/descoberta.c guard the add-on
// list version, and gl_compat.h counts texture uploads. These fixtures do not
// link those modules. Linux tolerates the optional references; Mach-O rejects
// them at link time (functions) or at load time (data). The values match
// "nothing linked": no account reply, version 0, a list that cannot be locked,
// session 0 and performance counters off.
#include <stdint.h>
#include <stddef.h>
#define W __attribute__((weak))

W char *nuvem_addon_alternar(const char *consulta, int ativo, const char *bearer,
                             unsigned prazo_ms, int *status) {
  (void)consulta; (void)ativo; (void)bearer; (void)prazo_ms;
  if (status) *status = 0;
  return NULL;
}
W unsigned addons_versao(void) { return 0; }
W int  addons_travar_lista(unsigned versao, int perfil) { (void)versao; (void)perfil; return 0; }
W void addons_destravar_lista(void) {}
W int  addons_identidade_recebida(const char *base, unsigned versao, uint64_t sessao,
                                  const char *corpo) {
  (void)base; (void)versao; (void)sessao; (void)corpo;
  return 0;
}
W uint64_t perfis_sessao_geracao(void) { return 0; }

W int perftv_enabled = 0;
W int perftv_uploads = 0, perftv_blur = 0, perftv_glass = 0;
