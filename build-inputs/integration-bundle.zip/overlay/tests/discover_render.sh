#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="${1:-$PWD/build/discover-render}"
mkdir -p "$out"
out="$(cd "$out" && pwd)"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
sources=()
for source in src/*.c src/dts/*.c; do [ "$source" = src/main.c ] || sources+=("$source"); done
source tests/native_host_fixture.inc
cc -std=gnu11 -UNDEBUG -DNV_SHOT_HOOKS -O1 -Isrc "${sources[@]}" tests/discover_render.c "${host_flags[@]}" "${host_libs[@]}" -o "$tmp/render"
NUVIO_DADOS="$tmp" LIBGL_ALWAYS_SOFTWARE=1 "${run[@]}" "$tmp/render" "$out"
