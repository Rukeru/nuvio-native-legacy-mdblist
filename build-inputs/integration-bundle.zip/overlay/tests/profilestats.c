#include "profilestats.h"
#include "js.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
static long long stamp(int day){struct tm tm={0};tm.tm_year=126;tm.tm_mon=9;tm.tm_mday=day;tm.tm_hour=12;tm.tm_isdst=-1;return (long long)mktime(&tm)*1000;}
static void record(StatsRecord *r,const char *id,const char *type,int ep,int day,unsigned source){memset(r,0,sizeof *r);snprintf(r->watched.id,sizeof r->watched.id,"%s",id);snprintf(r->watched.tipo,sizeof r->watched.tipo,"%s",type);r->watched.temporada=ep?1:0;r->watched.episodio=ep;r->watched.vistoMs=day?stamp(day):0;r->source=source;}
static int meta(const char *id,const char *type,CatItem *out){memset(out,0,sizeof *out);snprintf(out->imdb,sizeof out->imdb,"%s",id);strcpy(out->titulo,"Known title");strcpy(out->genero,!strcmp(type,"movie")?"Filme · Drama":"Programa de TV · Comedy");return 1;}
int main(void){
 StatsRecord rows[9];record(rows,"tt1","movie",0,9,STATS_NUVIO);record(rows+1,"tt1","movie",0,13,STATS_MDBLIST);
 record(rows+2,"tt2","series",1,11,STATS_NUVIO);record(rows+3,"tt2","series",1,11,STATS_MDBLIST);record(rows+4,"tt2","series",2,12,STATS_MDBLIST);
 record(rows+5,"tt3","movie",0,0,STATS_NUVIO);record(rows+6,"tt3","movie",0,10,STATS_MDBLIST);record(rows+7,"tt4","series",0,12,STATS_NUVIO);
 record(rows+8,"tt5","movie",0,0,STATS_NUVIO);
 PerfilDados d;StatsProvenance p;assert(stats_build(rows,9,(time_t)(stamp(13)/1000),&d,&p,meta));
 assert(p.unique==5&&p.duplicates==3&&p.unknownDates==1&&p.sources==6);
 assert(d.filmesAno==2&&d.episodiosAno==2);
 assert(d.filmes==2&&d.episodios==2&&d.plays==4&&d.minutos==0&&d.timeUnknown&&d.uniqueItems);
 assert(d.atividade[d.primeiroDiaSemana+12]==0); // Nuvio date wins over later MDBList evidence
 assert(d.diasAtivosMes==4&&d.streakAtual==4&&d.parcial&&!d.anoCompleto&&!d.streakCompleto);
 assert(d.nDestaques==3&&d.destaques[0].plays==2&&d.nGeneros==2);
 record(rows,"tt1","movie",0,9,STATS_MDBLIST);assert(stats_build(rows,1,(time_t)(stamp(13)/1000),&d,&p,NULL));assert(d.filmes==1&&p.sources==4&&!d.nGeneros);
 assert(stats_build(NULL,0,(time_t)(stamp(13)/1000),&d,&p,NULL));assert(!d.plays&&d.parcial);
 const char *json="[{\"type\":\"movie\",\"watched_at\":\"2026-10-09T12:00:00Z\",\"movie\":{\"ids\":{\"imdb\":\"tt1\"}}},{\"type\":\"movie\",\"progress\":99,\"movie\":{\"ids\":{\"imdb\":\"tt2\"}}},{\"type\":\"show\",\"watched_at\":\"2026-10-10T12:00:00Z\",\"show\":{\"ids\":{\"imdb\":\"tt3\"}}}]";
 ContaVisto parsed[5];assert(stats_trakt_parse(json,parsed,5)==1);assert(!strcmp(parsed[0].id,"tt1")&&parsed[0].vistoMs>0);assert(stats_trakt_parse("{}",parsed,5)==-1);
 StatsScope requested={.generation=1,.mdbGeneration=4,.traktGeneration=5,.profile=1,.provider=STATS_AUTO};strcpy(requested.account,"account-one");StatsScope current=requested;
 assert(stats_scope_matches(&requested,&current));current.profile=2;assert(!stats_scope_matches(&requested,&current));current=requested;current.generation++;assert(!stats_scope_matches(&requested,&current));current=requested;current.provider=STATS_MDBLIST;assert(!stats_scope_matches(&requested,&current));current=requested;strcpy(current.account,"account-two");assert(!stats_scope_matches(&requested,&current));current=requested;current.mdbGeneration++;assert(!stats_scope_matches(&requested,&current));current=requested;current.traktGeneration++;assert(!stats_scope_matches(&requested,&current));
 requested.provider=STATS_NUVIO;current=requested;current.mdbGeneration++;assert(stats_scope_matches(&requested,&current));
 puts("Stats: Nuvio-only/MDBList-only, precedence, dedup/provenance, missing dates/duration, episode evidence, partial calendar and Trakt fallback parser passed");return 0;
}
