/* Replaced by the maintained integration with the exact builder identity.
 * Production remains disabled until live backend/auth/privacy verification. */
#ifndef NV_DIAG_BUILD
#define NV_DIAG_BUILD ""
#endif
#ifndef NV_DIAG_VERIFIED
#define NV_DIAG_VERIFIED 0
#endif
