#ifndef NV_PROFILESTATS_H
#define NV_PROFILESTATS_H
#include "perfil.h"
#include "contalib.h"
#include "catalogo.h"
#include <time.h>
enum { STATS_AUTO, STATS_NUVIO, STATS_MDBLIST, STATS_TRAKT };
typedef struct { ContaVisto watched; unsigned source; } StatsRecord;
typedef struct { unsigned sources; int unique,unknownDates,duplicates; } StatsProvenance;
/* Reduces immutable completed records on a worker. Sorted identity precedence:
   Nuvio, MDBList, Trakt; latest date within the same provider. Cross-provider
   duplicates count once. Undated primary records can use a corroborated date.
   Last-watch snapshots do not prove rewatches, total duration or full history. */
int stats_build(StatsRecord *records,int n,time_t now,PerfilDados *out,
                StatsProvenance *provenance,int (*metadata)(const char *,const char *,CatItem *));
typedef struct {unsigned generation,mdbGeneration,traktGeneration;int profile,provider;char account[96];} StatsScope;
int stats_scope_matches(const StatsScope *requested,const StatsScope *current);
int stats_trakt_parse(const char *json,ContaVisto *out,int max);
#endif
