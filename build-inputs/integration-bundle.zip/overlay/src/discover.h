/* Native Discover over published catalogue snapshots; no network on UI thread. */
#ifndef NV_DISCOVER_H
#define NV_DISCOVER_H
#include <SDL2/SDL.h>
void discover_iniciar(void);
void discover_esquecer(void);
void discover_evento(const SDL_Event *e);
void discover_atualizar(float dt, Uint32 agora);
void discover_desenhar(Uint32 agora);
int discover_quer_sair(void);
int discover_pediu_abrir(int *indice);
#ifdef NV_SHOT_HOOKS
#include "catalogo.h"
void discover_shot_seed(const CatItem *items,int n);
void discover_shot_focus(int index,float scroll);
#endif
#endif
