#include "discover_catalog.h"
#include "js.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
static pthread_mutex_t dcLock=PTHREAD_MUTEX_INITIALIZER;
static DiscoverCatalog *catalogs;
static int catalogCount,capacity;
static unsigned dcEpoch=1,dcVersion,dcRevision;
unsigned dc_catalog_epoch(void){pthread_mutex_lock(&dcLock);unsigned n=dcEpoch;pthread_mutex_unlock(&dcLock);return n;}
unsigned dc_catalog_revision(void){pthread_mutex_lock(&dcLock);unsigned n=dcRevision;pthread_mutex_unlock(&dcLock);return n;}
void dc_catalog_forget(void){pthread_mutex_lock(&dcLock);free(catalogs);catalogs=NULL;catalogCount=capacity=0;dcVersion=0;dcEpoch++;dcRevision++;pthread_mutex_unlock(&dcLock);}
static const char *nextString(const char *p){
 if(!p||*p!='"')return NULL;
 for(p++;*p;p++){if(*p=='\\'&&p[1]){p++;continue;}if(*p=='"')return js_prox(p+1);}return NULL;
}
/* Whole-manifest publication is atomic. Required unknown extras cannot be
   satisfied by Discover; exclude these and search-only catalogues. Options
   belong to this exact provider/type. URLs stay in the existing addon store. */
void dc_catalog_manifest(int addon,unsigned version,unsigned epoch,const char *json,int active){
 if(!json)return;
 pthread_mutex_lock(&dcLock);
 if(epoch!=dcEpoch){pthread_mutex_unlock(&dcLock);return;}
 if(version!=dcVersion){catalogCount=0;dcVersion=version;}
 if(!catalogs){capacity=64;catalogs=calloc((size_t)capacity,sizeof *catalogs);}
 if(!catalogs){pthread_mutex_unlock(&dcLock);return;}
 for(int i=0;i<catalogCount;)if(catalogs[i].addon==addon){memmove(catalogs+i,catalogs+i+1,(size_t)(--catalogCount-i)*sizeof *catalogs);}else i++;
 if(active)for(const char *p=js_array(json,NULL,"catalogs");p && catalogCount<DC_CATALOG_MAX;p=js_prox(js_fim(p))){
  const char *f=js_fim(p);DiscoverCatalog c={0};c.addon=addon;int blocked=0;
  js_texto(p,f,"type",c.type,sizeof c.type);js_texto(p,f,"id",c.id,sizeof c.id);js_texto_raiz_em(p,f,"name",c.name,sizeof c.name);
  if((strcmp(c.type,"movie")&&strcmp(c.type,"series"))||!c.id[0])continue;
  if(!c.name[0])snprintf(c.name,sizeof c.name,"%s",c.id);
  for(const char *e=js_array(p,f,"extra");e;e=js_prox(js_fim(e))){
   const char *ef=js_fim(e);char name[32]={0};js_texto(e,ef,"name",name,sizeof name);
   char required[16]={0};int req=js_bruto(e,ef,"isRequired",required,sizeof required)&&!strcmp(required,"true");
   if(!strcmp(name,"skip"))c.skip=1;
   else if(!strcmp(name,"genre")){
    c.requiresGenre=req;
    for(const char *g=js_array(e,ef,"options");g && c.nGenres<DC_CATALOG_GENRES;g=nextString(g)){
     char value[96]={0};if(js_cadeia(g,value,sizeof value)&&value[0]){
      size_t length=strlen(value);
      if(length<sizeof c.genres[0])memcpy(c.genres[c.nGenres++],value,length+1);
     }
    }
    if(req&&!c.nGenres)blocked=1;
   }else if(req)blocked=1;
  }
  for(const char *e=js_array(p,f,"extraSupported");e;e=nextString(e)){char name[32]={0};js_cadeia(e,name,sizeof name);if(!strcmp(name,"skip"))c.skip=1;}
  if(!blocked){
   if(catalogCount==capacity){int next=capacity+64;if(next>DC_CATALOG_MAX)next=DC_CATALOG_MAX;DiscoverCatalog *grown=realloc(catalogs,(size_t)next*sizeof *catalogs);if(!grown)break;catalogs=grown;capacity=next;}
   catalogs[catalogCount++]=c;
  }
 }
 dcRevision++;pthread_mutex_unlock(&dcLock);
}
int dc_catalog_count(const char *type,unsigned version){pthread_mutex_lock(&dcLock);int n=0;if(version==dcVersion)for(int i=0;i<catalogCount;i++)if(!strcmp(type,catalogs[i].type))n++;pthread_mutex_unlock(&dcLock);return n;}
int dc_catalog_item(const char *type,unsigned version,int index,DiscoverCatalog *out){pthread_mutex_lock(&dcLock);int ok=0;if(out&&index>=0&&version==dcVersion)for(int i=0;i<catalogCount;i++)if(!strcmp(type,catalogs[i].type)&&index--==0){*out=catalogs[i];ok=1;break;}pthread_mutex_unlock(&dcLock);return ok;}
