#include "profilestats.h"
#include "js.h"
#include "mdbformat.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
static int compare(const void *a,const void *b){
 const StatsRecord *x=a,*y=b;int c=strcmp(x->watched.id,y->watched.id);if(c)return c;
 c=strcmp(x->watched.tipo,y->watched.tipo);if(c)return c;
 if(x->watched.temporada!=y->watched.temporada)return x->watched.temporada<y->watched.temporada ? -1 : 1;
 if(x->watched.episodio!=y->watched.episodio)return x->watched.episodio<y->watched.episodio ? -1 : 1;
 if(x->source!=y->source)return x->source<y->source ? -1 : 1;
 return x->watched.vistoMs==y->watched.vistoMs ? 0 : x->watched.vistoMs>y->watched.vistoMs ? -1 : 1;
}
static int same(const StatsRecord *a,const StatsRecord *b){return !strcmp(a->watched.id,b->watched.id)&&!strcmp(a->watched.tipo,b->watched.tipo)&&a->watched.temporada==b->watched.temporada&&a->watched.episodio==b->watched.episodio;}
static int valid(const StatsRecord *r){return r->source>=STATS_NUVIO&&r->source<=STATS_TRAKT&&r->watched.id[0]&&(!strcmp(r->watched.tipo,"movie")||(!strcmp(r->watched.tipo,"series")&&r->watched.episodio>0));}
typedef struct {char name[40];int count;} StatGenre;
static void genres_add(StatGenre *g,int *n,const CatItem *item,int weight){
 if(!item||weight<1)return;
 for(const char *p=item->genero;*p;){
  const char *end=strstr(p," · ");size_t len=end ? (size_t)(end-p) : strlen(p);char name[40];
  if(len&&len<sizeof name){memcpy(name,p,len);name[len]=0;
   if(strcmp(name,"Filme")&&strcmp(name,"Série")&&strcmp(name,"Programa de TV")&&strcmp(name,"Movie")&&strcmp(name,"Series")){
    int i=0;while(i<*n&&strcmp(name,g[i].name))i++;
    if(i<64){if(i==*n){snprintf(g[i].name,sizeof g[i].name,"%s",name);(*n)++;}g[i].count+=weight;}
   }
  }
  if(!end)break;p=end+4;
 }
}
static void rank(PerfilDados *d,const CatItem *item,const char *id,int plays){
 if(plays<1)return;
 int pos=0;while(pos<d->nDestaques&&d->destaques[pos].plays>=plays)pos++;
 if(pos>=PERFIL_MAX_DESTAQUES)return;
 if(d->nDestaques<PERFIL_MAX_DESTAQUES)d->nDestaques++;
 for(int i=d->nDestaques-1;i>pos;i--)d->destaques[i]=d->destaques[i-1];
 PerfilDestaque *p=d->destaques+pos;memset(p,0,sizeof *p);p->plays=plays;
 snprintf(p->id,sizeof p->id,"%s",id);snprintf(p->titulo,sizeof p->titulo,"%.127s",item&&item->titulo[0] ? item->titulo : id);
 snprintf(p->detalhe,sizeof p->detalhe,"Unique completed items");
 if(item){snprintf(p->poster,sizeof p->poster,"%.767s",item->poster);snprintf(p->backdrop,sizeof p->backdrop,"%s",item->backdrop);}
}
int stats_build(StatsRecord *rows,int n,time_t now,PerfilDados *d,StatsProvenance *p,int (*metadata)(const char *,const char *,CatItem *)){
 if(!d||!p||n<0||n>20000||(!rows&&n))return 0;
 memset(d,0,sizeof *d);memset(p,0,sizeof *p);struct tm current;
 if(!localtime_r(&now,&current))return 0;
 struct tm first=current;first.tm_mday=1;first.tm_hour=first.tm_min=first.tm_sec=0;first.tm_isdst=-1;mktime(&first);
 d->primeiroDiaSemana=first.tm_wday;
 int year=current.tm_year+1900,month=current.tm_mon;
 static const int days[]={31,28,31,30,31,30,31,31,30,31,30,31};
 int monthDays=days[month]+(month==1&&year%4==0&&(year%100!=0||year%400==0));
 d->nDias=monthDays+d->primeiroDiaSemana;d->parcial=1;d->uniqueItems=1;d->timeUnknown=1;
 snprintf(d->periodo,sizeof d->periodo,"%04d-%02d · partial",year,month+1);
 if(n)qsort(rows,(size_t)n,sizeof *rows,compare);
 unsigned char observed[366]={0};int monthDay[32]={0};
 char group[24]="",groupType[8]="";int groupPlays=0;
 CatItem meta={0};StatGenre genres[64]={0};int nGenres=0;
 for(int i=0;i<n;){
  int end=i+1;while(end<n&&same(rows+i,rows+end))end++;
  if(!valid(rows+i)){i=end;continue;}
  StatsRecord chosen=rows[i];p->duplicates+=end-i-1;p->unique++;
  for(int j=i;j<end;j++){if(valid(rows+j))p->sources|=1u<<rows[j].source;if(chosen.watched.vistoMs<=0&&rows[j].watched.vistoMs>0)chosen.watched.vistoMs=rows[j].watched.vistoMs;}
  time_t when=(time_t)(chosen.watched.vistoMs/1000);struct tm date;
  if(chosen.watched.vistoMs<=0||chosen.watched.vistoMs/1000>(long long)now||!localtime_r(&when,&date)){p->unknownDates++;i=end;continue;}
  if(date.tm_year==current.tm_year&&date.tm_yday>=0&&date.tm_yday<366){observed[date.tm_yday]=1;if(!strcmp(chosen.watched.tipo,"movie"))d->filmesAno++;else d->episodiosAno++;}
  if(date.tm_year==current.tm_year&&date.tm_mon==month){
   d->plays++;if(!strcmp(chosen.watched.tipo,"movie"))d->filmes++;else d->episodios++;
   int cell=d->primeiroDiaSemana+date.tm_mday-1;
   if(cell>=0&&cell<PERFIL_MAX_DIAS&&d->atividade[cell]<USHRT_MAX)d->atividade[cell]++;
   monthDay[date.tm_mday]=1;
   if(strcmp(group,chosen.watched.id)||strcmp(groupType,chosen.watched.tipo)){
    genres_add(genres,&nGenres,meta.imdb[0] ? &meta : NULL,groupPlays);
    rank(d,meta.imdb[0] ? &meta : NULL,group,groupPlays);groupPlays=0;
    snprintf(group,sizeof group,"%s",chosen.watched.id);snprintf(groupType,sizeof groupType,"%s",chosen.watched.tipo);
    memset(&meta,0,sizeof meta);if(metadata)metadata(group,groupType,&meta);
   }
   groupPlays++;
  }
  i=end;
 }
 genres_add(genres,&nGenres,meta.imdb[0] ? &meta : NULL,groupPlays);
 rank(d,meta.imdb[0] ? &meta : NULL,group,groupPlays);
 for(int i=0;i<nGenres;i++){int pos=0;while(pos<d->nGeneros&&d->generos[pos].quantidade>=genres[i].count)pos++;if(pos>=PERFIL_MAX_GENEROS)continue;if(d->nGeneros<PERFIL_MAX_GENEROS)d->nGeneros++;for(int j=d->nGeneros-1;j>pos;j--)d->generos[j]=d->generos[j-1];snprintf(d->generos[pos].nome,sizeof d->generos[pos].nome,"%s",genres[i].name);d->generos[pos].quantidade=genres[i].count;}
 for(int i=0;i<366;i++)d->diasAtivosAno+=observed[i];
 for(int i=1;i<=monthDays;i++)d->diasAtivosMes+=monthDay[i];
 int last=current.tm_mday;if(!monthDay[last])last--;
 while(last>0&&monthDay[last]){d->streakAtual++;last--;}
 const char *source=p->sources==(1u<<STATS_NUVIO) ? "Nuvio" : p->sources==(1u<<STATS_MDBLIST) ? "MDBList" : p->sources==(1u<<STATS_TRAKT) ? "Trakt fallback" : "Nuvio / MDBList";
 d->sourcesMask=p->sources;
 snprintf(d->aviso,sizeof d->aviso,"%s · partial unique items; time/rewatches unknown. %d: %d movies, %d eps observed; %d undated, %d overlaps.",source,year,d->filmesAno,d->episodiosAno,p->unknownDates,p->duplicates);
 return 1;
}
int stats_trakt_parse(const char *json,ContaVisto *out,int max){
 if(!json||!out||max<1||*json!='[')return -1;const char *end=js_fim(json);if(!end||end[-1]!=']')return -1;
 int n=0;for(const char *p=js_raiz_array(json);p&&n<max;p=js_prox(js_fim(p))){
  const char *f=js_fim(p);char type[16]={0},date[64]={0};js_texto(p,f,"type",type,sizeof type);ContaVisto v={0};
  const char *item=NULL;
  if(!strcmp(type,"movie")){strcpy(v.tipo,"movie");item=mdb_object(p,f,"movie");}
  else if(!strcmp(type,"episode")){strcpy(v.tipo,"series");item=mdb_object(p,f,"show");const char *ep=mdb_object(p,f,"episode");if(!ep)continue;v.temporada=(int)js_num(ep,js_fim(ep),"season",0);v.episodio=(int)js_num(ep,js_fim(ep),"number",0);if(v.episodio<=0)continue;}
  if(!item)continue;const char *ids=mdb_object(item,js_fim(item),"ids");if(!ids||!js_texto(ids,js_fim(ids),"imdb",v.id,sizeof v.id))continue;
  if(!js_texto(p,f,"watched_at",date,sizeof date)||(v.vistoMs=js_ms_iso(date))<=0)continue;
  out[n++]=v;
 }return n;
}

int stats_scope_matches(const StatsScope *a,const StatsScope *b){
 if(!a||!b||a->generation!=b->generation||a->profile!=b->profile||a->provider!=b->provider||strcmp(a->account,b->account))return 0;
 if((a->provider==STATS_AUTO||a->provider==STATS_MDBLIST)&&a->mdbGeneration!=b->mdbGeneration)return 0;
 if((a->provider==STATS_AUTO||a->provider==STATS_TRAKT)&&a->traktGeneration!=b->traktGeneration)return 0;
 return 1;
}
