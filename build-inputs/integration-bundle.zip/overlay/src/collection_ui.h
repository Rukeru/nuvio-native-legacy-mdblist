/* Shared collection presentation. No catalogue, paging or account state. */
#ifndef NV_COLLECTION_UI_H
#define NV_COLLECTION_UI_H
#include "catalogo.h"
#include "gfx.h"
#include "text.h"
#include "tex_cache.h"
#include "posterprov.h"
#include "revela.h"
#include "focoprof.h"
#include "imdbnota.h"
#include "badges.h"
#include "idioma.h"
#include "ajustes.h"
#include "layout.h"
#include <stdio.h>
#include <string.h>
#define COLLECTION_CARD_W 248.0f
#define COLLECTION_CARD_H 372.0f
#define COLLECTION_GAP_X 16.0f
#define COLLECTION_ROW_H 432.0f
#define COLLECTION_PANEL_W 336.0f
static inline int collection_columns(float x,float panel) {
 int n=(int)((panel-24.0f-x+COLLECTION_GAP_X)/(COLLECTION_CARD_W+COLLECTION_GAP_X)+.001f);
 return n<1?1:n>5?5:n;
}
static inline void collection_panel(const CatItem *item,float px,float top,float width,float a,int ellipsis) {
  CatItem it = *item;
  float y = top;

  // O contexto lateral usa o cartaz, nunca repete a cena da timeline.
  // Mantém a geometria 2:3 mesmo sem arte para não deslocar os metadados.
  { GfxRect r = { px, y, 220.0f, 330.0f };
    const char *arte = it.poster[0] ? it.poster : it.backdrop;
    float raio = 12.0f / 220.0f;
    GLuint t = arte[0] ? tex_obter_larg(arte, 220.0f) : 0;
    gfx_cor(r, raio, 1, 1, 1, 0.05f * a);
    if (t) {
      gfx_tex_aspect_atual = tex_aspecto(arte);
      gfx_rect(r, t, GFX_CARD, 0, 0, 0, raio, 0, 0, 0, a);
      gfx_tex_aspect_atual = 0.0f;
    } else {
      TxtLinha falta = txt_linha_corta(TXT_HERO_META, "Sem pôster", 185, 191, 204, 255, r.w-24);
      txt_desenhar_alpha(falta, r.x+(r.w-falta.w)*.5f, r.y+(r.h-falta.h)*.5f, a);
    } }
  y += 330.0f + 18.0f;
  float badgeW=badges_desenhar(badges_provedor(it.provNome),px,y,width,28,a);
  if(badgeW>0)y+=40;

  // LOGO no lugar do titulo quando existe (max 264x82 no web); o nome escrito
  // com a fonte da interface so quando nao ha logo.
  { GLuint tl = it.logo[0] ? tex_obter_logo_larg(it.logo, 264.0f) : 0;
    float ap = it.logo[0] ? tex_aspecto(it.logo) : 0.0f;
    if (tl && ap > 0.0f) {
      float wL = 264.0f, hL = wL / ap;
      if (hL > 82.0f) { hL = 82.0f; wL = hL * ap; }
      { GfxRect rl = { px, y, wL, hL };
        GfxModo m = tex_marca_escura(it.logo) ? GFX_MARCA : GFX_TEXTO;
        gfx_tex_aspect_atual = 0.0f;
        gfx_rect(rl, tl, m, 0, 0, 0, 0.0f, 1, 1, 1, a); }
      y += hL + 4.0f;
    } else {
      TxtLinha t = txt_linha_corta(TXT_HEADLINE, it.titulo, 245, 245, 245, 255,
                                   width);
      txt_desenhar_alpha(t, px, y, a);
      y += t.h + 6.0f;
    } }

  if (it.genero[0]) {
    TxtLinha t = txt_linha_corta(TXT_CAPTION, it.genero, 220, 231, 244, 255,
                                 width);
    txt_desenhar_alpha(t, px, y, a * 0.72f);
    y += t.h + 6.0f;
  }
  // Pastilha da nota, no amarelo do IMDb que o web usa (245,197,24).
  int imdbRating = imdbnota_obter(it.imdb, it.nota, !strcmp(it.tipo,"series"));
  if (imdbRating > 0) {
    char n[16];
    snprintf(n, sizeof n, "%.1f", imdbRating / 10.0f); idioma_decimal_texto(n, ajustes_idioma());
    { TxtLinha t = txt_linha(TXT_CAPTION, n, 23, 19, 10, 255);
      GfxRect r = { px, y + 8.0f, t.w + 26.0f, t.h + 8.0f };
      gfx_cor(r, 8.0f / (t.h + 8.0f), 0.961f, 0.773f, 0.094f, 0.92f * a);
      txt_desenhar_alpha(t, px + 13.0f, y + 12.0f, a);
      y += r.h + 14.0f; }
  }
  if (it.meta[0]) {
    TxtLinha t = txt_linha_corta(TXT_DET_META2, it.meta, 240, 240, 240, 255,
                                 width);
    txt_desenhar_alpha(t, px, y, a * 0.92f);
    y += t.h + 12.0f;
  }
  if (it.sinopse[0]) {
    // Ate onde couber sem passar da base util (o web corta em
    // max-height: 100% - 210).
    int linhas = (int)((NV_TELA_H - 48.0f - y) / 34.0f);
    if (linhas > 8) linhas = 8;
    if (linhas > 0 && ellipsis)
      txt_bloco_corta(TXT_DET_META2,it.sinopse,236,236,236,px,y,width,34.0f,a*.86f,linhas);
    else if (linhas > 0)
      txt_bloco(TXT_DET_META2, it.sinopse, 236, 236, 236,
                px, y, width, 34.0f, a * 0.86f, linhas);
  }
}
static inline void collection_card(const CatItem *item,GfxRect r0,int sel,int focused,float ac,RevelaArte *reveal,Uint32 agora) {
 CatItem it=*item; float cx=r0.x,cy=r0.y,radius=ajustes_raio_poster_px()/r0.w;
 GLuint t; const char *arteCard;
    { GfxRect r = r0;

      // SEM ANEL: o foco e o crescimento (focoprof.h), como nas outras grades,
      // sem halo colorido. Antes o anel branco fixo ignorava os Ajustes.
      if (focused && !ajustes_borda_foco()) {
        r = foco_zoom(r0, 1.0f);
      }
      if (focused && ajustes_borda_foco()) {
        // O ANEL DO APP: no acento e so com "Foco no cartaz" ligado (era branco
        // fixo, a unica grade do app que nao seguia os Ajustes).
        GfxRect anel = { cx - NV_ANEL_FOCO, cy - NV_ANEL_FOCO,
                         r0.w + 2 * NV_ANEL_FOCO, r0.h + 2 * NV_ANEL_FOCO };
        float ar, ag, ab; ajustes_acento(&ar, &ag, &ab);
        if (ajustes_vidro()) gfx_vidro_cartao(r, ajustes_raio_poster_px() / r0.w, 1.0f, ac);
        else gfx_cor(anel, (ajustes_raio_poster_px() + NV_ANEL_FOCO) / (r0.w + 2 * NV_ANEL_FOCO), ar, ag, ab, ac);
      }
      { const char *pp = posterprov_card_addon(it.origem, it.imdb, it.tmdb, it.tipo, it.poster);
        arteCard = pp[0] ? pp : it.backdrop; }
      t = arteCard[0] ? tex_obter_larg(arteCard, r0.w) : 0;
      // Arte chegando esvanece sobre o esqueleto (revela.h), como na home.
      float aArte = reveal ? revela_arte(reveal, t != 0, agora) : 1.0f;
      if (!t || aArte < 0.999f)
        // Esqueleto enquanto a arte nao chega — a mesma cor do resto do app.
        gfx_cor(r, radius, NV_COR_ESQUELETO_R, NV_COR_ESQUELETO_G,
                NV_COR_ESQUELETO_B, ac);
      if (t) {
        gfx_tex_aspect_atual = tex_aspecto(arteCard);
        gfx_rect(r, t, GFX_CARD, sel ? 1.0f : 0.0f, 0, 0, radius, 0, 0, 0, ac * aArte);
        gfx_tex_aspect_atual = 0.0f;
      } }
    { int c = sel ? 255 : 214;
      TxtLinha l = txt_linha_corta(TXT_DET_META2, it.titulo, c, c, c, 255,
                                   r0.w);
      txt_desenhar_alpha(l, cx, cy + r0.h + 10.0f, ac * (sel ? 1.0f : 0.86f)); }
}
#endif

