/* Private diagnostics: numeric allowlist only. Never pass logs, URLs or keys. */
#ifndef NV_PRIVATE_DIAGNOSTICS_H
#define NV_PRIVATE_DIAGNOSTICS_H
#include <stddef.h>
#include <time.h>
#define NVD_EVENTS 32
#define NVD_QUEUE 8
#define NVD_PAYLOAD 8192
enum {
 NVD_MANUAL, NVD_PREVIOUS, NVD_SYNC_FAILED, NVD_SYNC_CACHED, NVD_SYNC_STALE,
 NVD_MANIFEST, NVD_MDB_FAILED, NVD_MDB_AUTH, NVD_TRAKT, NVD_RETRY,
 NVD_DUPLICATE, NVD_ACCOUNT_AUTH, NVD_PLAY_INIT, NVD_DECODER, NVD_INTERRUPTED,
 NVD_SLOW, NVD_MEMORY, NVD_SYNC_SLOW, NVD_EVENT_COUNT
};
typedef struct { int code, a, b; } NvDiagEvent;
typedef struct {
 char id[37], version[32], build[41];
 int n, automatic, attempts;
 time_t created, next;
 NvDiagEvent events[NVD_EVENTS];
} NvDiagReport;
typedef struct {
 int ready, paired, consent, asked, state, http, queued, preview_ready;
 int pairing; /* 0 idle, 1 pending, 2 paired, 3 rejected/local failure */
 time_t last_sent, next;
 char receipt[8];
} NvDiagStatus;
int nvdiag_event_valid(NvDiagEvent e);
int nvdiag_report_json(const NvDiagReport *r, const char *platform, char *out, size_t cap);
int nvdiag_uuid_valid(const char *s);
int nvdiag_hex_valid(const char *s, size_t n);
unsigned nvdiag_backoff(int attempts, int http);
void nvdiag_init(void);
void nvdiag_shutdown(void);
void nvdiag_event(int code, int a, int b);
void nvdiag_performance(unsigned frame_ms, unsigned memory_mb);
void nvdiag_preview(void); /* prepares an immutable snapshot; NEVER sends */
int nvdiag_preview_copy(char *out, size_t cap);
int nvdiag_send(void); /* explicit confirmation of the prepared snapshot */
void nvdiag_consent(int enabled); /* new recipient-specific consent */
int nvdiag_pair(const char *code); /* no network/IO on caller thread */
void nvdiag_status(NvDiagStatus *out);
#endif
