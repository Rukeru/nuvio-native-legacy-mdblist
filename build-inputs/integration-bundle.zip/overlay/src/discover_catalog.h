#ifndef NV_DISCOVER_CATALOG_H
#define NV_DISCOVER_CATALOG_H
#define DC_CATALOG_MAX 2048
#define DC_CATALOG_GENRES 32
typedef struct {
 int addon, nGenres, skip, requiresGenre;
 char type[8], id[96], name[96], genres[DC_CATALOG_GENRES][48];
} DiscoverCatalog;
unsigned dc_catalog_epoch(void);
void dc_catalog_forget(void);
void dc_catalog_manifest(int addon,unsigned version,unsigned epoch,const char *json,int active);
int dc_catalog_count(const char *type,unsigned version);
int dc_catalog_item(const char *type,unsigned version,int index,DiscoverCatalog *out);
unsigned dc_catalog_revision(void);
#endif
